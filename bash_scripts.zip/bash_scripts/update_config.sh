# This script updates the config.ini file within the archive.tar archive.
# It extracts the config.ini file, modifies it, and then updates the archive with the modified file.

# Define the archive name
archive_name="archive.tar"

# Define the file to update
file_to_update="config.ini"

# Create a temporary directory
tmp_dir=$(mktemp -d)

# Extract the file from the archive
tar -xf "$archive_name" -C "$tmp_dir" "$file_to_update"

# Check if the file was successfully extracted
if [ ! -f "$tmp_dir/$file_to_update" ]; then
  echo "Error: $file_to_update not found in $archive_name"
  rm -rf "$tmp_dir"
  exit 1
fi

# Modify the file (example: add a line to the file)
echo "# Added by update_config.sh" >> "$tmp_dir/$file_to_update"

# Update the archive with the modified file
tar -uf "$archive_name" -C "$tmp_dir" "$file_to_update"

# Check if the update was successful
if [ $? -ne 0 ]; then
  echo "Error: Failed to update $archive_name"
  rm -rf "$tmp_dir"
  exit 1
fi

# Clean up the temporary directory
rm -rf "$tmp_dir"

echo "Successfully updated $file_to_update in $archive_name"
exit 0
```