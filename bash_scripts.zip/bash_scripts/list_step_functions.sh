# This script lists all Step Functions state machines using the AWS CLI.
# It assumes that the AWS CLI is configured with appropriate credentials
# and region.

# Usage: ./list_step_functions.sh

aws stepfunctions list-state-machines
```