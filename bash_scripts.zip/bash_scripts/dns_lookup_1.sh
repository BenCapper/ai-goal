# This script performs a DNS lookup for the hostname mail.example.com
# and displays the A record (IP address).

# Use the 'dig' command to query the DNS for the A record of mail.example.com.
# The '+short' option suppresses verbose output, returning only the IP address.
dig +short mail.example.com A
```