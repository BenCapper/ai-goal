# This script uses sed to replace a string in a file.

# The script takes three arguments:
# 1. The file to modify.
# 2. The string to replace.
# 3. The replacement string.

# Check if the correct number of arguments is provided
if [ $# -ne 3 ]; then
  echo "Usage: ./replace_string.sh <file> <string_to_replace> <replacement_string>"
  exit 1
fi

# Assign arguments to variables
file="$1"
old_string="$2"
new_string="$3"

# Use sed to replace the string in the file
sed -i "s/$old_string/$new_string/g" "$file"

# Check if the sed command was successful
if [ $? -eq 0 ]; then
  echo "String '$old_string' replaced with '$new_string' in '$file'"
else
  echo "Error: String replacement failed."
  exit 1
fi

exit 0

# Example usage: ./replace_string.sh my_file.txt "old_text" "new_text"
```