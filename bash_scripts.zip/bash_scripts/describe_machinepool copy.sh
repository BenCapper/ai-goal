# This script describes a specific machine pool in OpenShift using `oc get machinepool`.
# It requires the machine pool name as an argument.
# If no argument is provided, it will print an error message and exit.

# Check if a machine pool name is provided as an argument
if [ -z "$1" ]; then
  echo "Error: Please provide the name of the machine pool as an argument."
  echo "Usage: $0 <machinepool_name>"
  exit 1
fi

MACHINEPOOL_NAME="$1"

# Get the machine pool information
oc get machinepool "$MACHINEPOOL_NAME" -o yaml

# Check the exit code of the oc command
if [ $? -ne 0 ]; then
  echo "Error: Failed to retrieve machine pool information for $MACHINEPOOL_NAME."
  exit 1
fi

exit 0
```