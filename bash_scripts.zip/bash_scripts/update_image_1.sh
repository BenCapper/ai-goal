#
# This script updates the image of a Kubernetes deployment or other workload.
# It takes the deployment name, container name, and new image as input.
# It uses kubectl set image to perform the update.
#
# Usage: ./update_image.sh <deployment_name> <container_name> <new_image>

# Check if the correct number of arguments is provided
if [ $# -ne 3 ]; then
  echo "Usage: $0 <deployment_name> <container_name> <new_image>"
  exit 1
fi

# Assign arguments to variables
DEPLOYMENT_NAME=$1
CONTAINER_NAME=$2
NEW_IMAGE=$3

# Update the image using kubectl set image
kubectl set image deployment/$DEPLOYMENT_NAME $CONTAINER_NAME=$NEW_IMAGE

# Check the exit status of the kubectl command
if [ $? -eq 0 ]; then
  echo "Image updated successfully for deployment '$DEPLOYMENT_NAME', container '$CONTAINER_NAME' to '$NEW_IMAGE'"
else
  echo "Failed to update image for deployment '$DEPLOYMENT_NAME', container '$CONTAINER_NAME'"
  exit 1
fi

exit 0
```