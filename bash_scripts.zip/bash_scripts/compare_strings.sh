# This script reads two strings from the user and stores them in variables STR1 and STR2.
# It then uses an if statement with the == operator to compare the two strings.
# If the strings are identical, it prints "Strings are equal".
# If the strings are not identical, it prints "Strings are not equal".

# Usage: ./compare_strings.sh

read -p "Enter the first string: " STR1
read -p "Enter the second string: " STR2

if [ "$STR1" == "$STR2" ]; then
  echo "Strings are equal"
else
  echo "Strings are not equal"
fi
```