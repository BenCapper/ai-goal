# This script demonstrates how to use the `route` and `ip route` commands
# to manage routing based on source and destination ports.
# Note: This requires root privileges.  Use with caution.
# It is critical to understand the implications of changing routing rules.

# Usage: sudo ./route_port_based.sh <interface> <source_port> <destination_port> <gateway_ip>

# Check if the script is run as root.
if [[ $EUID -ne 0 ]]; then
  echo "This script must be run as root."
  exit 1
fi

# Check for the correct number of arguments
if [ $# -ne 4 ]; then
  echo "Usage: sudo ./route_port_based.sh <interface> <source_port> <destination_port> <gateway_ip>"
  exit 1
fi

INTERFACE=$1
SOURCE_PORT=$2
DESTINATION_PORT=$3
GATEWAY_IP=$4


# Create a new routing table

TABLE_NAME="port_routing"
TABLE_ID=100 #Choose a table ID, make sure this doesn't conflict with anything else

# Add the routing table
echo "Adding routing table: $TABLE_NAME with ID: $TABLE_ID"

ip route add local 0.0.0.0/0 dev lo table $TABLE_ID

#Define the mark
MARK=10

# iptables rules to mark packets based on source and destination ports
echo "Adding iptables rules to mark packets."

iptables -t mangle -A OUTPUT -o $INTERFACE -p tcp --sport $SOURCE_PORT --dport $DESTINATION_PORT -j MARK --set-mark $MARK
iptables -t mangle -A PREROUTING -i $INTERFACE -p tcp --sport $SOURCE_PORT --dport $DESTINATION_PORT -j MARK --set-mark $MARK

# Define routing rule
echo "Adding routing rule to use table $TABLE_NAME for marked packets."
ip rule add fwmark $MARK table $TABLE_ID

# Add default route to the custom table
echo "Adding default route to table $TABLE_NAME via $GATEWAY_IP"
ip route add default via $GATEWAY_IP dev $INTERFACE table $TABLE_ID

echo "Routing rules added.  Packets from port $SOURCE_PORT to port $DESTINATION_PORT through interface $INTERFACE will be routed via $GATEWAY_IP."


# Cleanup function (optional, but good practice)
cleanup() {
  echo "Cleaning up routing rules and iptables rules..."
  ip rule del fwmark $MARK table $TABLE_ID 2>/dev/null
  iptables -t mangle -D OUTPUT -o $INTERFACE -p tcp --sport $SOURCE_PORT --dport $DESTINATION_PORT -j MARK --set-mark $MARK 2>/dev/null
  iptables -t mangle -D PREROUTING -i $INTERFACE -p tcp --sport $SOURCE_PORT --dport $DESTINATION_PORT -j MARK --set-mark $MARK 2>/dev/null
  ip route flush table $TABLE_ID 2>/dev/null
  ip route del local 0.0.0.0/0 dev lo table $TABLE_ID 2>/dev/null
  echo "Cleanup complete."
}

# Trap signals for cleanup
trap cleanup EXIT

# Example of checking the rules.  This is for demonstration purposes only.  Remove for production.
echo "Current iptables rules:"
iptables -t mangle -L -v

echo "Current routing rules:"
ip rule list

echo "Current routing table: $TABLE_ID"
ip route list table $TABLE_ID


#Example usage
# sudo ./route_port_based.sh eth0 8080 80 192.168.1.1
```