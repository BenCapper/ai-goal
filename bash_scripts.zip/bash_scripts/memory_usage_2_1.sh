# This script calculates and displays the percentage of used memory on the system.
# It uses the 'free' command to get memory information and calculates the percentage.

# Get total memory in kilobytes
total_memory=$(free | awk 'NR==2 {print $2}')

# Get used memory in kilobytes
used_memory=$(free | awk 'NR==2 {print $3}')

# Calculate the percentage of used memory
percentage=$(( (used_memory * 100) / total_memory ))

# Display the percentage
echo "Memory Usage: ${percentage}%"
```