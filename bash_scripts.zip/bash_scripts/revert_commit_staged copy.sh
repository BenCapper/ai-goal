# This script reverts a specific commit in a Git repository
# while keeping the changes in the working directory and staged.

# Usage: ./revert_commit_staged.sh <commit_hash>

# Check if a commit hash is provided.
if [ $# -ne 1 ]; then
  echo "Usage: ./revert_commit_staged.sh <commit_hash>"
  exit 1
fi

commit_hash="$1"

# Check if the commit hash is valid.
if ! git rev-parse --verify --quiet "$commit_hash" > /dev/null 2>&1; then
  echo "Error: Invalid commit hash: $commit_hash"
  exit 1
fi

# Revert the commit using --no-commit to prevent creating a commit immediately.
git revert --no-commit "$commit_hash"

# Add all the changes from the revert to the staging area.
git add .

echo "Commit '$commit_hash' reverted, changes staged."
```