# This script is a basic file compression tool that supports multiple compression algorithms.
# It allows users to select from gzip, bzip2, and xz.
# It compresses a given file using the selected algorithm.

# Usage: ./compress_tool.sh <algorithm> <input_file>

# Function to handle errors and exit
error_exit() {
  echo "Error: $1" >&2
  exit 1
}

# Check if the correct number of arguments is provided
if [ $# -ne 2 ]; then
  echo "Usage: ./compress_tool.sh <algorithm> <input_file>"
  echo "Available algorithms: gzip, bzip2, xz"
  exit 1
fi

# Get the algorithm and input file from the arguments
algorithm="$1"
input_file="$2"

# Check if the input file exists
if [ ! -f "$input_file" ]; then
  error_exit "Input file '$input_file' not found."
fi

# Determine the output file name based on the algorithm
case "$algorithm" in
  gzip)
    output_file="$input_file.gz"
    compression_command="gzip"
    ;;
  bzip2)
    output_file="$input_file.bz2"
    compression_command="bzip2"
    ;;
  xz)
    output_file="$input_file.xz"
    compression_command="xz"
    ;;
  *)
    error_exit "Invalid algorithm: '$algorithm'. Available algorithms: gzip, bzip2, xz"
    ;;
esac

# Perform the compression
echo "Compressing '$input_file' using $algorithm..."
if "$compression_command" "$input_file"; then
  echo "Successfully compressed '$input_file' to '$output_file'."
else
  error_exit "Compression failed."
fi

exit 0
```