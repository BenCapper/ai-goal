# This script demonstrates how to use perf report with the --call-graph=callee option.
# It first records performance data using perf record, then generates a report
# using perf report with --call-graph=callee to show the call graph in callee mode.

# Record performance data
perf record -g -- sleep 1

# Generate the perf report with call graph in callee mode
perf report --call-graph=callee

# Clean up the perf.data file (optional)
rm perf.data

# Usage: ./perf_report_callee.sh
```