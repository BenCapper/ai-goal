# This script reverts a specific merge commit in a Git repository.
# It takes the merge commit's SHA as an argument.

# Check if a merge commit SHA is provided.
if [ $# -eq 0 ]; then
  echo "Usage: $0 <merge_commit_sha>"
  exit 1
fi

MERGE_COMMIT=$1

# Revert the merge commit.  The '-m 1' option specifies which parent to use
# as the base for the revert.  Merge commits have multiple parents, and you
# must choose one to represent the "mainline" you want to keep. Typically
# it's '1' but might be '2' depending on the merge strategy.
git revert -m 1 $MERGE_COMMIT

echo "Successfully reverted merge commit $MERGE_COMMIT.  You need to push this change."
```