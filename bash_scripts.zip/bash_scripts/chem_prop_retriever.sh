# This script takes a list of chemical compound names as input,
# retrieves their properties from a chemistry database using the
# PubChem API via the curl command-line tool, and prints the results.

# Usage: ./chem_prop_retriever.sh compound1 compound2 ...

# Function to retrieve properties of a compound from PubChem
get_compound_properties() {
  local compound_name="$1"
  local pubchem_url="https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/$compound_name/property/MolecularFormula,MolecularWeight,IUPACName/JSON"

  # Use curl to fetch the JSON data from the PubChem API
  local json_data=$(curl -s "$pubchem_url")

  # Check if the curl request was successful
  if [[ $? -ne 0 ]]; then
    echo "Error: Failed to retrieve data for $compound_name"
    return 1
  fi

  # Extract the properties from the JSON data using jq
  local molecular_formula=$(echo "$json_data" | jq -r '.PropertyTable.Properties[0].MolecularFormula')
  local molecular_weight=$(echo "$json_data" | jq -r '.PropertyTable.Properties[0].MolecularWeight')
  local iupac_name=$(echo "$json_data" | jq -r '.PropertyTable.Properties[0].IUPACName')

  # Check if the properties exist
  if [[ -z "$molecular_formula" ]]; then
    molecular_formula="N/A"
  fi
  if [[ -z "$molecular_weight" ]]; then
    molecular_weight="N/A"
  fi
  if [[ -z "$iupac_name" ]]; then
    iupac_name="N/A"
  fi

  # Print the properties
  echo "Compound: $compound_name"
  echo "  Molecular Formula: $molecular_formula"
  echo "  Molecular Weight: $molecular_weight"
  echo "  IUPAC Name: $iupac_name"
}

# Main loop: iterate over the input compound names
if [[ $# -eq 0 ]]; then
  echo "Usage: ./chem_prop_retriever.sh compound1 compound2 ..."
  exit 1
fi

for compound_name in "$@"; do
  get_compound_properties "$compound_name"
  echo "" # Add an empty line between compounds
done

exit 0
```