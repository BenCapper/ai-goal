# This script configures and manages persistent storage for applications in OpenShift.
# It automates the creation of PersistentVolumes (PVs) and PersistentVolumeClaims (PVCs)
# and binds them together to provide persistent storage for applications.
# It also includes functionality for dynamic provisioning and expanding PVCs.

# Usage: ./openshift_persistent_storage.sh <action> <volume_name> <storage_size> <access_mode> <storage_class>
#        <action>: create_pv, create_pvc, delete_pv, delete_pvc, expand_pvc
#        <volume_name>: Name of the PV/PVC
#        <storage_size>: Size of the storage (e.g., 10Gi)
#        <access_mode>: Access mode (e.g., ReadWriteOnce, ReadOnlyMany, ReadWriteMany)
#        <storage_class>: StorageClass to use (optional, required for dynamic provisioning)

# Exit on first error
set -e

ACTION="$1"
VOLUME_NAME="$2"
STORAGE_SIZE="$3"
ACCESS_MODE="$4"
STORAGE_CLASS="$5"

# Check if oc is installed
if ! command -v oc &> /dev/null
then
  echo "Error: OpenShift CLI (oc) is not installed. Please install it and configure access to your OpenShift cluster."
  exit 1
fi

# Check if user is logged in to OpenShift
if ! oc whoami &> /dev/null
then
  echo "Error: Not logged in to OpenShift. Please log in using 'oc login'."
  exit 1
fi

create_pv() {
  if [ -z "$VOLUME_NAME" ] || [ -z "$STORAGE_SIZE" ] || [ -z "$ACCESS_MODE" ]; then
    echo "Error: Missing required parameters for create_pv."
    echo "Usage: ./openshift_persistent_storage.sh create_pv <volume_name> <storage_size> <access_mode>"
    exit 1
  fi

  cat <<EOF | oc create -f -
apiVersion: v1
kind: PersistentVolume
metadata:
  name: $VOLUME_NAME
spec:
  capacity:
    storage: $STORAGE_SIZE
  accessModes:
  - $ACCESS_MODE
  persistentVolumeReclaimPolicy: Retain
  #hostPath:
  #  path: /data/$VOLUME_NAME
  nfs:
    path: /data/$VOLUME_NAME
    server: nfs-server.example.com
EOF

  echo "PersistentVolume $VOLUME_NAME created."
}

create_pvc() {
  if [ -z "$VOLUME_NAME" ] || [ -z "$STORAGE_SIZE" ] || [ -z "$ACCESS_MODE" ]; then
    echo "Error: Missing required parameters for create_pvc."
    echo "Usage: ./openshift_persistent_storage.sh create_pvc <volume_name> <storage_size> <access_mode> [<storage_class>]"
    exit 1
  fi

  cat <<EOF | oc create -f -
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: $VOLUME_NAME
spec:
  accessModes:
  - $ACCESS_MODE
  resources:
    requests:
      storage: $STORAGE_SIZE
EOF
  if [ -n "$STORAGE_CLASS" ]; then
    cat <<EOF | oc patch pvc $VOLUME_NAME -p -
spec:
  storageClassName: $STORAGE_CLASS
EOF
  else
    cat <<EOF | oc patch pvc $VOLUME_NAME -p -
spec:
  volumeName: $VOLUME_NAME
EOF
  fi

  echo "PersistentVolumeClaim $VOLUME_NAME created."
}

delete_pv() {
  if [ -z "$VOLUME_NAME" ]; then
    echo "Error: Missing volume name for delete_pv."
    echo "Usage: ./openshift_persistent_storage.sh delete_pv <volume_name>"
    exit 1
  fi

  oc delete pv $VOLUME_NAME
  echo "PersistentVolume $VOLUME_NAME deleted."
}

delete_pvc() {
  if [ -z "$VOLUME_NAME" ]; then
    echo "Error: Missing volume name for delete_pvc."
    echo "Usage: ./openshift_persistent_storage.sh delete_pvc <volume_name>"
    exit 1
  fi

  oc delete pvc $VOLUME_NAME
  echo "PersistentVolumeClaim $VOLUME_NAME deleted."
}

expand_pvc() {
    if [ -z "$VOLUME_NAME" ] || [ -z "$STORAGE_SIZE" ]; then
        echo "Error: Missing required parameters for expand_pvc."
        echo "Usage: ./openshift_persistent_storage.sh expand_pvc <volume_name> <storage_size>"
        exit 1
    fi

    oc patch pvc $VOLUME_NAME -p "{\"spec\": {\"resources\": {\"requests\": {\"storage\": \"$STORAGE_SIZE\"}}}}"
    echo "PersistentVolumeClaim $VOLUME_NAME expansion requested to $STORAGE_SIZE.  Requires approval from storage provisioner."
}

case "$ACTION" in
  create_pv)
    create_pv
    ;;
  create_pvc)
    create_pvc
    ;;
  delete_pv)
    delete_pv
    ;;
  delete_pvc)
    delete_pvc
    ;;
  expand_pvc)
    expand_pvc
    ;;
  *)
    echo "Usage: ./openshift_persistent_storage.sh <action> <volume_name> <storage_size> <access_mode> [<storage_class>]"
    echo "  Actions: create_pv, create_pvc, delete_pv, delete_pvc, expand_pvc"
    exit 1
    ;;
esac

# End of script
# ./openshift_persistent_storage.sh create_pv my-pv 10Gi ReadWriteOnce
# ./openshift_persistent_storage.sh create_pvc my-pvc 5Gi ReadWriteOnce my-storage-class
# ./openshift_persistent_storage.sh delete_pv my-pv
# ./openshift_persistent_storage.sh delete_pvc my-pvc
# ./openshift_persistent_storage.sh expand_pvc my-pvc 20Gi
```