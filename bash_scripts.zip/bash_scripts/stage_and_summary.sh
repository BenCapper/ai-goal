# This script stages all modified and untracked files in the current Git repository.
# It then displays a summary of the changes that have been staged using git diff --staged.

# Usage: ./stage_and_summary.sh

# Stage all modified and untracked files.
git add .

# Display a summary of the staged changes.
git diff --staged
```