# This script uses Ansible to manage OpenShift routes with custom hostnames,
# TLS termination policies, path-based routing rules, and custom annotations.
# It requires an Ansible inventory file and a playbook to define the desired route configurations.

# Ensure Ansible is installed
if ! command -v ansible &> /dev/null
then
    echo "Ansible is not installed. Please install Ansible before running this script."
    exit 1
fi

# Define variables for Ansible execution
INVENTORY_FILE="inventory.ini"  # Path to your Ansible inventory file
PLAYBOOK_FILE="openshift_route.yml" # Path to your Ansible playbook
EXTRA_VARS="" # Optional: Extra variables to pass to Ansible playbook.  Example:  EXTRA_VARS="--extra-vars '{\"route_name\":\"my-route\"}'"

# Check if inventory file exists
if [ ! -f "$INVENTORY_FILE" ]; then
  echo "Error: Inventory file '$INVENTORY_FILE' not found."
  exit 1
fi

# Check if playbook file exists
if [ ! -f "$PLAYBOOK_FILE" ]; then
  echo "Error: Playbook file '$PLAYBOOK_FILE' not found."
  exit 1
fi

# Execute the Ansible playbook
echo "Running Ansible playbook '$PLAYBOOK_FILE' with inventory '$INVENTORY_FILE'..."
ansible-playbook -i "$INVENTORY_FILE" "$PLAYBOOK_FILE" $EXTRA_VARS

# Check the exit code of Ansible
if [ $? -eq 0 ]; then
    echo "Ansible playbook execution completed successfully."
else
    echo "Ansible playbook execution failed. Check the output for errors."
    exit 1
fi

exit 0
```