# This script checks if a specific port is open on a remote host.
# It takes two arguments: the hostname and the port number.
# It uses nc (netcat) to attempt a connection to the specified host and port.
# It returns 0 if the port is open, and 1 if the port is closed.

# Check if the correct number of arguments is provided.
if [ $# -ne 2 ]; then
  echo "Usage: $0 <hostname> <port>"
  exit 1
fi

# Assign arguments to variables.
HOST=$1
PORT=$2

# Check if the host is reachable by pinging it.
if ! ping -c 1 -W 1 "$HOST" > /dev/null 2>&1; then
    echo "Host $HOST is unreachable."
    exit 1
fi

# Attempt to connect to the host and port using nc.
# The -z option tells nc to scan for listening daemons without sending any data.
# The -w option sets a timeout of 1 second.
nc -z -w 1 "$HOST" "$PORT" > /dev/null 2>&1

# Check the return code of nc.
if [ $? -eq 0 ]; then
  echo "Port $PORT is open on $HOST."
  exit 0
else
  echo "Port $PORT is closed on $HOST."
  exit 1
fi
```