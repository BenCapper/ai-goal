# This script checks disk space and prints the filesystem and mount point for partitions with less than 5GB free.
# It uses df -h to get disk space information, grep to exclude the header, and awk to filter and format the output.

# Get disk space information, exclude the header, and filter for partitions with less than 5GB free.
df -h | grep -v "^Filesystem" | awk '{if ($4 + 0 < 5) print $1, $6}'

# Usage: ./disk_space_check.sh
```