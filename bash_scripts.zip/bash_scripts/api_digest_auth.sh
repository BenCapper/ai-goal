# This script interacts with an API that uses digest HTTP authentication.
# It uses curl to make the request and handles the authentication process.
# The script requires the API endpoint, username, and password as input.
# It attempts to dynamically determine the digest algorithm (MD5 or SHA) used by the server.

# Usage: ./api_digest_auth.sh <api_endpoint> <username> <password>

# Check if the correct number of arguments are provided
if [ $# -ne 3 ]; then
  echo "Usage: ./api_digest_auth.sh <api_endpoint> <username> <password>"
  exit 1
fi

API_ENDPOINT="$1"
USERNAME="$2"
PASSWORD="$3"

# Make an initial request to get the WWW-Authenticate header
RESPONSE=$(curl -s -I "$API_ENDPOINT" 2>&1)

# Extract the WWW-Authenticate header
AUTH_HEADER=$(echo "$RESPONSE" | grep "WWW-Authenticate" | awk '{print $2}')

# Check if the header is present
if [ -z "$AUTH_HEADER" ]; then
  echo "Error: WWW-Authenticate header not found. The API might not require authentication or may use a different scheme."
  exit 1
fi

# Determine the digest algorithm used by the server. Default to MD5 if can't determine.
ALGORITHM="MD5"
if echo "$AUTH_HEADER" | grep -q "algorithm=SHA"; then
    ALGORITHM="SHA"
fi

# Make the authenticated request using curl with digest authentication
RESPONSE=$(curl -s -u "$USERNAME:$PASSWORD" --digest "$API_ENDPOINT")

# Check the response
if [ $? -eq 0 ]; then
  echo "$RESPONSE"
else
  echo "Error: Authentication failed or API request failed."
  exit 1
fi
```