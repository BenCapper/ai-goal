# This script retrieves the default gateway of the system.
# It uses the 'ip route show default' command to display the routing table.
# The output is then piped to awk, which extracts the third field, representing the gateway IP address.

# Get the default gateway using ip route and awk.
ip route show default | awk '{print $3}'

# Usage: ./get_default_gateway.sh
```