# This script retrieves details of a specific OpenShift route using the oc command-line tool.
# It requires the 'oc' command to be installed and configured to access your OpenShift cluster.
# It takes the route name and optionally the namespace as input parameters.
# If no namespace is provided, it will try the current namespace.

# Check if the route name is provided as an argument
if [ -z "$1" ]; then
  echo "Usage: $0 <route_name> [namespace]"
  exit 1
fi

ROUTE_NAME="$1"
NAMESPACE="${2:-$(oc project -q)}" # Use provided namespace or default to current project

# Check if the namespace exists
if ! oc get namespace "$NAMESPACE" &>/dev/null; then
  echo "Error: Namespace '$NAMESPACE' does not exist."
  exit 1
fi


# Get the route details in YAML format
oc get route "$ROUTE_NAME" -n "$NAMESPACE" -o yaml

# Alternatively to outputting yaml
# You can use `oc describe` for a more human readable output like so:
# oc describe route "$ROUTE_NAME" -n "$NAMESPACE"

# Or even output to json:
# oc get route "$ROUTE_NAME" -n "$NAMESPACE" -o json
```