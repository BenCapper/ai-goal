# This script creates a new git branch and switches to it in one command.

# Check if a branch name is provided as an argument.
if [ $# -eq 0 ]; then
  echo "Usage: $0 <branch_name>"
  exit 1
fi

# The name of the new branch.
branch_name="$1"

# Create the new branch and switch to it.
git checkout -b "$branch_name"
```