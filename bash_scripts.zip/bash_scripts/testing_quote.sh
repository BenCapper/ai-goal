# This script displays a random quote about the importance of testing in software development.

quotes=(
  "\"Testing is not a cost; it is an investment.\""
  "\"Software testing is a responsibility, not an option.\""
  "\"The purpose of software testing is to discover errors in a program.\""
  "\"Test early, test often.\""
  "\"Without testing, you're just guessing.\""
  "\"Quality is never an accident; it is always the result of high intention, sincere effort, intelligent direction and skillful execution; it represents the wise choice of many alternatives.\""
  "\"The bitterness of poor quality remains long after the sweetness of low price is forgotten.\""
  "\"It's not enough to be good; you have to be good for something.\""
  "\"The only way to do great work is to love what you do.\""
  "\"Testing leads to failure, and failure leads to understanding.\""
)

num_quotes="${#quotes[@]}"
random_index=$((RANDOM % num_quotes))

echo "${quotes[$random_index]}"
```