# This script retrieves details of a specific Security Context Constraint (SCC) in OpenShift
# using `oc describe scc <name>`. It extracts the allowedUsers, allowedGroups,
# supplementalGroups, priority, and allowedUnsafeSysctls and prints them to the console.

#!/bin/bash

# Check if SCC name is provided as an argument
if [ -z "$1" ]; then
  echo "Usage: $0 <scc_name>"
  exit 1
fi

SCC_NAME="$1"

# Get the description of the SCC
SCC_DESCRIPTION=$(oc describe scc "$SCC_NAME")

# Extract allowedUsers
ALLOWED_USERS=$(echo "$SCC_DESCRIPTION" | grep -A1 "Allowed Users:" | tail -n 1)

# Extract allowedGroups
ALLOWED_GROUPS=$(echo "$SCC_DESCRIPTION" | grep -A1 "Allowed Groups:" | tail -n 1)

# Extract supplementalGroups
SUPPLEMENTAL_GROUPS=$(echo "$SCC_DESCRIPTION" | grep -A1 "Supplemental Groups:" | tail -n 1)

# Extract priority
PRIORITY=$(echo "$SCC_DESCRIPTION" | grep "Priority:" | awk '{print $2}')

# Extract allowedUnsafeSysctls
ALLOWED_UNSAFE_SYSCTLS=$(echo "$SCC_DESCRIPTION" | grep -A1 "Allowed Unsafe Sysctls:" | tail -n 1)

# Print the extracted information
echo "SCC Name: $SCC_NAME"
echo "Allowed Users: $ALLOWED_USERS"
echo "Allowed Groups: $ALLOWED_GROUPS"
echo "Supplemental Groups: $SUPPLEMENTAL_GROUPS"
echo "Priority: $PRIORITY"
echo "Allowed Unsafe Sysctls: $ALLOWED_UNSAFE_SYSCTLS"
```