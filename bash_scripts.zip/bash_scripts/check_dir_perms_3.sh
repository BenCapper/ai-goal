# This script checks if a directory exists, is readable, writable, and executable.
# It also verifies that only the owner has read, write, and execute permissions, and that the directory is owned by root.

CONFIG_DIR_READABLE_WRITABLE_EXECUTABLE_OTHER_NONE_PLUS="/opt/myconfigdir"

if [ -d "$CONFIG_DIR_READABLE_WRITABLE_EXECUTABLE_OTHER_NONE_PLUS" ] && [ -r "$CONFIG_DIR_READABLE_WRITABLE_EXECUTABLE_OTHER_NONE_PLUS" ] && [ -w "$CONFIG_DIR_READABLE_WRITABLE_EXECUTABLE_OTHER_NONE_PLUS" ] && [ -x "$CONFIG_DIR_READABLE_WRITABLE_EXECUTABLE_OTHER_NONE_PLUS" ] && ! [ -o "$CONFIG_DIR_READABLE_WRITABLE_EXECUTABLE_OTHER_NONE_PLUS" ] && [ "$(stat -c %U "$CONFIG_DIR_READABLE_WRITABLE_EXECUTABLE_OTHER_NONE_PLUS")" = "root" ]; then
  echo "Directory '$CONFIG_DIR_READABLE_WRITABLE_EXECUTABLE_OTHER_NONE_PLUS' exists, is readable, writable, and executable, only the owner has rwx permissions and is owned by root."
else
  echo "Directory '$CONFIG_DIR_READABLE_WRITABLE_EXECUTABLE_OTHER_NONE_PLUS' does not meet all the criteria."
fi

# Usage: ./check_dir_perms.sh
```