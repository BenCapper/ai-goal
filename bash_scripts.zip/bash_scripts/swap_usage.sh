# This script checks the swap space usage on a Linux system.
# It uses /proc/swaps to identify swap devices and their used space.
# It then uses awk to format the output for readability.

# Get swap device and used size.
cat /proc/swaps | grep "^/dev" | awk '{print $1, $3}'

# Usage: ./swap_usage.sh
```