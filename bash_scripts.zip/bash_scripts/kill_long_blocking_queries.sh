# This script connects to a PostgreSQL database, identifies queries
# that have been running for more than 5 minutes and are blocking other queries,
# logs the details of those queries to a log file, and then terminates them.
# It requires database credentials as input.

# Set variables
LOG_FILE="killed_queries.log"
THRESHOLD_SECONDS=300 # 5 minutes
DATABASE=""
USERNAME=""
PASSWORD=""
HOST=""
PORT=""

# Function to log messages
log() {
  echo "$(date) - $1" >> "$LOG_FILE"
}

# Function to kill queries
kill_queries() {
  # Construct the query to find long running blocking queries
  QUERY=$(cat <<EOF
SELECT pid,
       usename,
       datname,
       client_addr,
       application_name,
       state,
       query,
       age(clock_timestamp(), query_start) AS duration
FROM pg_stat_activity
WHERE datname = '$DATABASE'
  AND pid <> pg_backend_pid()
  AND state <> 'idle'
  AND wait_event_type = 'Lock'
  AND clock_timestamp() - query_start > interval '${THRESHOLD_SECONDS} seconds';
EOF
)

  # Execute the query and iterate over the results
  psql -h "$HOST" -p "$PORT" -U "$USERNAME" -d "$DATABASE" -w -At -c "$QUERY" | while IFS='|' read -r pid usename datname client_addr application_name state query duration; do
    if [ -n "$pid" ]; then
      log "Killing query PID: $pid, User: $usename, Database: $datname, Client: $client_addr, Application: $application_name, State: $state, Duration: $duration, Query: $query"
      pg_terminate_backend "$pid"
      log "Query PID: $pid terminated."
    fi
  done
}

# Check for necessary tools
if ! command -v psql &> /dev/null; then
  echo "psql command not found. Please install PostgreSQL client tools."
  exit 1
fi

if ! command -v pg_terminate_backend &> /dev/null; then
    echo "pg_terminate_backend command not found. This is usually part of the postgresql-client-common package. Please install it"
    exit 1
fi

# Prompt for database credentials if not provided as environment variables
if [ -z "$DATABASE" ]; then
  read -p "Enter database name: " DATABASE
fi

if [ -z "$USERNAME" ]; then
  read -p "Enter username: " USERNAME
fi

if [ -z "$PASSWORD" ]; then
  read -s -p "Enter password: " PASSWORD
  echo  # Move to the next line after password entry
fi

if [ -z "$HOST" ]; then
  read -p "Enter hostname (default: localhost): " HOST
  HOST="${HOST:-localhost}"
fi

if [ -z "$PORT" ]; then
  read -p "Enter port number (default: 5432): " PORT
  PORT="${PORT:-5432}"
fi

# Set the PGPASSWORD environment variable
export PGPASSWORD="$PASSWORD"

# Main script execution
log "Starting script to kill long running blocking queries."
kill_queries
log "Script finished."

# Unset the PGPASSWORD environment variable
unset PGPASSWORD
```