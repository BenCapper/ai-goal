# This script performs forensic analysis on a compromised Azure Container Instances (ACI) container.
# It gathers logs, network information, running processes, and file system snapshots to aid in incident response.

# --- Configuration ---
ACI_RESOURCE_GROUP="your_resource_group" # Replace with your ACI resource group
ACI_NAME="your_aci_name"         # Replace with your ACI instance name
CONTAINER_NAME="your_container_name" # Replace with the name of the compromised container
OUTPUT_DIR="/tmp/aci_forensics"   # Directory to store collected data
DATE=$(date +%Y%m%d_%H%M%S)
SNAPSHOT_DIR="$OUTPUT_DIR/$DATE"

# --- Create output directory ---
mkdir -p "$SNAPSHOT_DIR"

# --- Function to log actions ---
log() {
  echo "$(date +%Y-%m-%d %H:%M:%S) - $1"
}

# --- Function to execute az commands and handle errors ---
execute_az_command() {
  local command="$1"
  log "Executing: $command"
  az "$command" 2>&1 | tee "$SNAPSHOT_DIR/az_command.log"
  local exit_code=$?
  if [ $exit_code -ne 0 ]; then
    log "Error executing command: $command. Check $SNAPSHOT_DIR/az_command.log for details."
    return 1
  fi
  return 0
}

# --- Gather container logs ---
log "Gathering container logs..."
execute_az_command "container logs --resource-group $ACI_RESOURCE_GROUP --name $ACI_NAME --container-name $CONTAINER_NAME > $SNAPSHOT_DIR/container_logs.txt"
if [ $? -ne 0 ]; then
    log "Failed to retrieve container logs. Continuing anyway."
fi

# --- Get container instance properties ---
log "Gathering container instance properties..."
execute_az_command "container show --resource-group $ACI_RESOURCE_GROUP --name $ACI_NAME --output json > $SNAPSHOT_DIR/container_properties.json"
if [ $? -ne 0 ]; then
    log "Failed to retrieve container properties. Continuing anyway."
fi

# --- Execute commands inside the container to gather more information ---
log "Executing commands inside the container..."

# List running processes
log "Listing running processes..."
execute_az_command "container exec --resource-group $ACI_RESOURCE_GROUP --name $ACI_NAME --container-name $CONTAINER_NAME --exec-command \"ps aux\" > $SNAPSHOT_DIR/processes.txt"
if [ $? -ne 0 ]; then
    log "Failed to retrieve process list. Continuing anyway."
fi

# Network information (ifconfig or ip addr)
log "Gathering network information..."
execute_az_command "container exec --resource-group $ACI_RESOURCE_GROUP --name $ACI_NAME --container-name $CONTAINER_NAME --exec-command \"ip addr\" > $SNAPSHOT_DIR/network_info.txt"
if [ $? -ne 0 ]; then
    log "Failed to retrieve network information. Trying ifconfig..."
    execute_az_command "container exec --resource-group $ACI_RESOURCE_GROUP --name $ACI_NAME --container-name $CONTAINER_NAME --exec-command \"ifconfig\" > $SNAPSHOT_DIR/network_info.txt"
    if [ $? -ne 0 ]; then
        log "Failed to retrieve network information using ifconfig either. Continuing anyway."
    fi
fi


# List open ports (netstat or ss)
log "Listing open ports..."
execute_az_command "container exec --resource-group $ACI_RESOURCE_GROUP --name $ACI_NAME --container-name $CONTAINER_NAME --exec-command \"netstat -tulnp\" > $SNAPSHOT_DIR/open_ports.txt"
if [ $? -ne 0 ]; then
    log "Failed to retrieve open ports with netstat. Trying ss..."
    execute_az_command "container exec --resource-group $ACI_RESOURCE_GROUP --name $ACI_NAME --container-name $CONTAINER_NAME --exec-command \"ss -tulnp\" > $SNAPSHOT_DIR/open_ports.txt"
    if [ $? -ne 0 ]; then
      log "Failed to retrieve open ports with ss either. Continuing anyway."
    fi
fi

# Gather file system information (ls -l and/or find)
log "Gathering file system information..."
execute_az_command "container exec --resource-group $ACI_RESOURCE_GROUP --name $ACI_NAME --container-name $CONTAINER_NAME --exec-command \"find / -type f -print0 | xargs -0 ls -l\" > $SNAPSHOT_DIR/file_system.txt"
if [ $? -ne 0 ]; then
    log "Failed to retrieve file system information. Continuing anyway."
fi


# --- Create an archive of the collected data ---
log "Creating an archive of the collected data..."
tar -czvf "$OUTPUT_DIR/aci_forensics_$DATE.tar.gz" "$SNAPSHOT_DIR"

# --- Cleanup (optional) ---
# rm -rf "$SNAPSHOT_DIR"

log "Forensic analysis complete.  Data saved to $OUTPUT_DIR/aci_forensics_$DATE.tar.gz"
```