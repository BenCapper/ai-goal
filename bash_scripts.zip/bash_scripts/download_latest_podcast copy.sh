# This script takes a URL to a podcast feed as an argument
# and downloads the latest episode.

# Check if the user provided a URL
if [ -z "$1" ]; then
  echo "Usage: $0 <podcast_feed_url>"
  exit 1
fi

FEED_URL="$1"

# Get the XML content of the podcast feed
XML_CONTENT=$(curl -s "$FEED_URL")

# Extract the URL of the latest episode using XPath and xmllint
EPISODE_URL=$(echo "$XML_CONTENT" | xmllint --xpath 'string(//item[1]/enclosure/@url)' - 2>/dev/null)

# Check if we found an episode URL
if [ -z "$EPISODE_URL" ]; then
  echo "Error: Could not find episode URL in the feed."
  exit 1
fi

# Extract the filename from the URL
FILENAME=$(basename "$EPISODE_URL")

# Download the episode
echo "Downloading: $EPISODE_URL to $FILENAME"
curl -o "$FILENAME" "$EPISODE_URL"

echo "Download complete."
```