# This script iterates through the /etc/passwd file,
# extracts the user ID (UID) using the cut command, and
# identifies users with UIDs less than 1000.

# Usage: ./find_users.sh

while IFS= read -r PASSWD_LINE; do
  UID=$(echo "$PASSWD_LINE" | cut -d':' -f3)

  if (( UID < 1000 )); then
    USERNAME=$(echo "$PASSWD_LINE" | cut -d':' -f1)
    echo "User: $USERNAME, UID: $UID"
  fi
done < /etc/passwd
```