# This script automates the setup and management of a reverse proxy (Nginx or Apache).
 # It allows you to:
 # 1. Install the selected reverse proxy (Nginx or Apache).
 # 2. Configure the reverse proxy for a given domain and backend server.
 # 3. Enable/disable the site configuration.
 # 4. Restart/reload the reverse proxy service.

 #!/bin/bash

 # Configuration variables
 PROXY_TYPE="nginx"  # Default proxy type, can be changed to "apache"
 DOMAIN=""
 BACKEND_SERVER=""
 PORT="80"

 # Function to install Nginx
 install_nginx() {
  echo "Installing Nginx..."
  sudo apt update
  sudo apt install -y nginx
  if [ $? -eq 0 ]; then
   echo "Nginx installed successfully."
  else
   echo "Failed to install Nginx."
   exit 1
  fi
 }

 # Function to install Apache
 install_apache() {
  echo "Installing Apache..."
  sudo apt update
  sudo apt install -y apache2
  if [ $? -eq 0 ]; then
   echo "Apache installed successfully."
  else
   echo "Failed to install Apache."
   exit 1
  fi
 }

 # Function to configure Nginx
 configure_nginx() {
  if [ -z "$DOMAIN" ] || [ -z "$BACKEND_SERVER" ]; then
   echo "DOMAIN and BACKEND_SERVER must be set for Nginx configuration."
   return 1
  fi

  echo "Configuring Nginx for domain: $DOMAIN, backend: $BACKEND_SERVER:$PORT"

  # Create the Nginx configuration file
  CONFIG_FILE="/etc/nginx/sites-available/$DOMAIN"

  cat > "$CONFIG_FILE" <<EOL
 server {
  listen 80;
  listen [::]:80;

  server_name $DOMAIN;

  location / {
   proxy_pass http://$BACKEND_SERVER:$PORT;
   proxy_set_header Host \$host;
   proxy_set_header X-Real-IP \$remote_addr;
   proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
   proxy_set_header X-Forwarded-Proto \$scheme;
  }
 }
 EOL

  # Create symbolic link to enable the site
  sudo ln -s "$CONFIG_FILE" "/etc/nginx/sites-enabled/$DOMAIN"

  # Remove default config
  sudo rm -f /etc/nginx/sites-enabled/default

  echo "Nginx configuration created."
 }

 # Function to configure Apache
 configure_apache() {
  if [ -z "$DOMAIN" ] || [ -z "$BACKEND_SERVER" ]; then
   echo "DOMAIN and BACKEND_SERVER must be set for Apache configuration."
   return 1
  fi

  echo "Configuring Apache for domain: $DOMAIN, backend: $BACKEND_SERVER:$PORT"

  # Create the Apache configuration file
  CONFIG_FILE="/etc/apache2/sites-available/$DOMAIN.conf"

  cat > "$CONFIG_FILE" <<EOL
 <VirtualHost *:80>
  ServerName $DOMAIN

  ProxyPreserveHost On

  <Proxy *>
   Order deny,allow
   Allow from all
  </Proxy>

  ProxyPass / http://$BACKEND_SERVER:$PORT/
  ProxyPassReverse / http://$BACKEND_SERVER:$PORT/

  ErrorLog \${APACHE_LOG_DIR}/error.log
  CustomLog \${APACHE_LOG_DIR}/access.log combined
 </VirtualHost>
 EOL

  # Enable the site
  sudo a2ensite "$DOMAIN.conf"

  # Disable default config
  sudo a2dissite 000-default.conf

  echo "Apache configuration created."
 }

 # Function to enable a site (Nginx or Apache)
 enable_site() {
  SITE_NAME="$1"
  if [ -z "$SITE_NAME" ]; then
   echo "Please provide a site name to enable."
   return 1
  fi

  if [ "$PROXY_TYPE" == "nginx" ]; then
   sudo ln -sf "/etc/nginx/sites-available/$SITE_NAME" "/etc/nginx/sites-enabled/$SITE_NAME"
   echo "Nginx site $SITE_NAME enabled."
  elif [ "$PROXY_TYPE" == "apache" ]; then
   sudo a2ensite "$SITE_NAME.conf"
   echo "Apache site $SITE_NAME enabled."
  else
   echo "Invalid proxy type."
   return 1
  fi
 }

 # Function to disable a site (Nginx or Apache)
 disable_site() {
  SITE_NAME="$1"
  if [ -z "$SITE_NAME" ]; then
   echo "Please provide a site name to disable."
   return 1
  fi

  if [ "$PROXY_TYPE" == "nginx" ]; then
   sudo rm -f "/etc/nginx/sites-enabled/$SITE_NAME"
   echo "Nginx site $SITE_NAME disabled."
  elif [ "$PROXY_TYPE" == "apache" ]; then
   sudo a2dissite "$SITE_NAME.conf"
   echo "Apache site $SITE_NAME disabled."
  else
   echo "Invalid proxy type."
   return 1
  fi
 }

 # Function to restart the proxy service (Nginx or Apache)
 restart_proxy() {
  if [ "$PROXY_TYPE" == "nginx" ]; then
   sudo systemctl restart nginx
   if [ $? -eq 0 ]; then
    echo "Nginx restarted successfully."
   else
    echo "Failed to restart Nginx."
   fi
  elif [ "$PROXY_TYPE" == "apache" ]; then
   sudo systemctl restart apache2
   if [ $? -eq 0 ]; then
    echo "Apache restarted successfully."
   else
    echo "Failed to restart Apache."
   fi
  else
   echo "Invalid proxy type."
   return 1
  fi
 }

 # Function to reload the proxy service (Nginx or Apache)
 reload_proxy() {
  if [ "$PROXY_TYPE" == "nginx" ]; then
   sudo systemctl reload nginx
   if [ $? -eq 0 ]; then
    echo "Nginx reloaded successfully."
   else
    echo "Failed to reload Nginx."
   fi
  elif [ "$PROXY_TYPE" == "apache" ]; then
   sudo systemctl reload apache2
   if [ $? -eq 0 ]; then
    echo "Apache reloaded successfully."
   else
    echo "Failed to reload Apache."
   fi
  else
   echo "Invalid proxy type."
   return 1
  fi
 }

 # Function to check proxy status
 check_proxy_status() {
  if [ "$PROXY_TYPE" == "nginx" ]; then
   sudo systemctl status nginx
  elif [ "$PROXY_TYPE" == "apache" ]; then
   sudo systemctl status apache2
  else
   echo "Invalid proxy type."
   return 1
  fi
 }

 # Help function
 show_help() {
  echo "Usage: $0 [options]"
  echo "Options:"
  echo "  -i, --install         Install the selected proxy (Nginx or Apache)."
  echo "  -c, --configure       Configure the proxy with DOMAIN and BACKEND_SERVER."
  echo "  -e, --enable SITE     Enable a specific site."
  echo "  -d, --disable SITE    Disable a specific site."
  echo "  -r, --restart         Restart the proxy service."
  echo "  -l, --reload          Reload the proxy service."
  echo "  -s, --status          Check the status of the proxy service."
  echo "  -t, --type [nginx|apache]  Specify the proxy type (default: nginx)."
  echo "  --domain DOMAIN      Specify the domain name for the reverse proxy."
  echo "  --backend BACKEND    Specify the backend server address."
  echo "  --port PORT          Specify the backend server port (default: 80)."
  echo "  -h, --help            Show this help message."
  echo ""
  echo "Example:"
  echo "  $0 -i"
  echo "  $0 -c --domain example.com --backend 127.0.0.1"
  echo "  $0 -e example.com"
  echo "  $0 -r"
 }


 # Main script logic
 while [ "$#" -gt 0 ]; do
  case "$1" in
   -i|--install)
    if [ "$PROXY_TYPE" == "nginx" ]; then
     install_nginx
    elif [ "$PROXY_TYPE" == "apache" ]; then
     install_apache
    else
     echo "Invalid proxy type."
     exit 1
    fi
    ;;
   -c|--configure)
    if [ "$PROXY_TYPE" == "nginx" ]; then
     configure_nginx
    elif [ "$PROXY_TYPE" == "apache" ]; then
     configure_apache
    else
     echo "Invalid proxy type."
     exit 1
    fi
    ;;
   -e|--enable)
    if [ -n "$2" ]; then
     enable_site "$2"
     shift
    else
     echo "Error: Missing site name for enable."
     show_help
     exit 1
    fi
    ;;
   -d|--disable)
    if [ -n "$2" ]; then
     disable_site "$2"
     shift
    else
     echo "Error: Missing site name for disable."
     show_help
     exit 1
    fi
    ;;
   -r|--restart)
    restart_proxy
    ;;
   -l|--reload)
    reload_proxy
    ;;
   -s|--status)
    check_proxy_status
    ;;
   -t|--type)
    PROXY_TYPE="$2"
    shift
    ;;
   --domain)
    DOMAIN="$2"
    shift
    ;;
   --backend)
    BACKEND_SERVER="$2"
    shift
    ;;
   --port)
    PORT="$2"
    shift
    ;;
   -h|--help)
    show_help
    exit 0
    ;;
   *)
    echo "Invalid option: $1"
    show_help
    exit 1
    ;;
  esac
  shift
 done

 # Example Usage (Uncomment to test specific functions)
 # To use, uncomment and set the correct variables before running the script.

 #PROXY_TYPE="apache"
 #DOMAIN="example.com"
 #BACKEND_SERVER="127.0.0.1"
 #PORT="8080"

 #install_apache
 #configure_apache

 #enable_site "example.com"
 #disable_site "example.com"

 #restart_proxy
 #reload_proxy

 #check_proxy_status
```