# This script demonstrates how to use the tar utility to create an archive,
# excluding specific files and directories.

# Define the source directory to archive.
SOURCE_DIR="my_source_directory"

# Define the archive filename.
ARCHIVE_FILE="my_archive.tar.gz"

# Define the files/directories to exclude.
EXCLUDE_FILES=(
    "file_to_exclude.txt"
    "another_file.log"
)
EXCLUDE_DIRS=(
    "directory_to_exclude"
    "another_directory"
)

# Create the source directory and some files/directories for testing.
mkdir -p "$SOURCE_DIR"
touch "$SOURCE_DIR/file1.txt" "$SOURCE_DIR/file2.txt" "$SOURCE_DIR/file_to_exclude.txt" "$SOURCE_DIR/another_file.log"
mkdir -p "$SOURCE_DIR/directory1" "$SOURCE_DIR/directory2" "$SOURCE_DIR/directory_to_exclude" "$SOURCE_DIR/another_directory"
touch "$SOURCE_DIR/directory1/file_in_dir.txt"

# Build the exclude options for tar.
EXCLUDE_OPTIONS=""
for file in "${EXCLUDE_FILES[@]}"; do
  EXCLUDE_OPTIONS+=" --exclude='$SOURCE_DIR/$file'"
done

for dir in "${EXCLUDE_DIRS[@]}"; do
  EXCLUDE_OPTIONS+=" --exclude='$SOURCE_DIR/$dir'"
done

# Create the archive, excluding the specified files and directories.
tar -czvf "$ARCHIVE_FILE" $EXCLUDE_OPTIONS "$SOURCE_DIR"

# Verify that the archive was created.
if [ -f "$ARCHIVE_FILE" ]; then
  echo "Archive '$ARCHIVE_FILE' created successfully with exclusions."
else
  echo "Error: Archive creation failed."
fi

# Cleanup the test directory and files.
rm -rf "$SOURCE_DIR"

# file usage: bash archive_with_exclusions.sh
```