# This script automates the setup and management of a basic CNI configuration.
# It creates a CNI configuration file, installs necessary CNI plugins,
# and configures Docker or Podman to use the CNI network.

# Usage: ./cni_setup.sh <network_name> <subnet> <gateway>

# Define variables
NETWORK_NAME="$1"
SUBNET="$2"
GATEWAY="$3"
CNI_CONFIG_DIR="/etc/cni/net.d"
CNI_PLUGIN_DIR="/opt/cni/bin"
CNI_VERSION="1.3.0" # Specify the desired CNI plugins version
BRIDGE_NAME="cni0" # Name of the bridge interface

# Check if required arguments are provided
if [ -z "$NETWORK_NAME" ] || [ -z "$SUBNET" ] || [ -z "$GATEWAY" ]; then
  echo "Error: Network name, subnet, and gateway must be provided."
  echo "Usage: ./cni_setup.sh <network_name> <subnet> <gateway>"
  exit 1
fi

# Create CNI configuration directory if it doesn't exist
if [ ! -d "$CNI_CONFIG_DIR" ]; then
  echo "Creating CNI configuration directory: $CNI_CONFIG_DIR"
  sudo mkdir -p "$CNI_CONFIG_DIR"
fi

# Create CNI plugin directory if it doesn't exist
if [ ! -d "$CNI_PLUGIN_DIR" ]; then
  echo "Creating CNI plugin directory: $CNI_PLUGIN_DIR"
  sudo mkdir -p "$CNI_PLUGIN_DIR"
fi

# Download CNI plugins (if they don't exist)
if [ ! -f "$CNI_PLUGIN_DIR/bridge" ]; then
  echo "Downloading CNI plugins version: $CNI_VERSION"
  CNI_ARCH=$(uname -m)

  PLUGIN_URL="https://github.com/containernetworking/plugins/releases/download/v${CNI_VERSION}/cni-plugins-linux-${CNI_ARCH}-v${CNI_VERSION}.tgz"

  curl -LO "$PLUGIN_URL"
  sudo tar -xzf "cni-plugins-linux-${CNI_ARCH}-v${CNI_VERSION}.tgz" -C "$CNI_PLUGIN_DIR"
  rm "cni-plugins-linux-${CNI_ARCH}-v${CNI_VERSION}.tgz"

  if [ ! -f "$CNI_PLUGIN_DIR/bridge" ]; then
    echo "Error: Failed to download or extract CNI plugins."
    exit 1
  fi
fi

# Create CNI configuration file
CNI_CONFIG_FILE="$CNI_CONFIG_DIR/$NETWORK_NAME.conflist"
echo "Creating CNI configuration file: $CNI_CONFIG_FILE"

cat > "$CNI_CONFIG_FILE" <<EOF
{
  "cniVersion": "1.0.0",
  "name": "$NETWORK_NAME",
  "plugins": [
    {
      "type": "bridge",
      "bridge": "$BRIDGE_NAME",
      "isGateway": true,
      "ipam": {
        "type": "host-local",
        "subnet": "$SUBNET",
        "routes": [
          { "dst": "0.0.0.0/0", "gw": "$GATEWAY" }
        ]
      }
    },
    {
      "type": "portmap",
      "capabilities": { "portMappings": true }
    },
    {
      "type": "firewall"
    }
  ]
}
EOF

# Restart Docker/Podman (optional)
# This step may be necessary for the changes to take effect.
# echo "Restarting Docker (optional)..."
# sudo systemctl restart docker

#echo "Restarting Podman (optional)..."
#sudo systemctl restart podman

echo "CNI configuration complete.  You can now use the '$NETWORK_NAME' network with Docker or Podman."
echo "Example: docker run --net=$NETWORK_NAME ..."
```