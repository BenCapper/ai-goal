# This script uses git to show the changes introduced by a specific tag
# for a specific file, showing only the removed lines with context.

# Check if the correct number of arguments is provided
if [ $# -ne 2 ]; then
  echo "Usage: $0 <tag_name> <file_path>"
  exit 1
fi

# Assign arguments to variables
tag_name="$1"
file_path="$2"

# Use git log to show the changes introduced by the tag for the specific file,
# filtering for removed lines with context.  The -U option specifies unified diff context.
# The -- unified=X (where X is a number) can also be used instead of -U X, but this syntax is deprecated.
git log -U5 -p -S"" --diff-filter=d -- "$file_path" | \
  grep '^\-' | \
  grep -v '^\---'
```