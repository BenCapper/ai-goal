# This script retrieves the last 10 lines from the syslog
# and filters the output to display only lines containing a specified hostname.

# Define the hostname to search for
HOSTNAME="your_hostname_here"

# Attempt to use tail to read the syslog and filter for the hostname
if [ -f /var/log/syslog ]; then
  tail -n 10 /var/log/syslog | grep "$HOSTNAME"
else
  # If /var/log/syslog doesn't exist, use journalctl
  journalctl -n 10 | grep "$HOSTNAME"
fi

# Usage: ./syslog_grep.sh
```