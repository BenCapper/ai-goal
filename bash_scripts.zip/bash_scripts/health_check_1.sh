# This script performs a basic system health check and reports the status.
# It checks CPU load, disk usage, memory usage, and network connectivity.

# Check CPU load
cpu_load=$(uptime | awk '{print $(NF-2)}')

# Check disk usage
disk_usage=$(df -h / | awk 'NR==2{print $5}')

# Check memory usage
memory_usage=$(free -m | awk 'NR==2{printf "%.2f%%", $3/$2 * 100}')

# Check network connectivity to Google DNS
ping_result=$(ping -c 1 8.8.8.8 > /dev/null 2>&1 && echo "OK" || echo "FAILED")

# Output the results
echo "System Health Check Report:"
echo "--------------------------"
echo "CPU Load: $cpu_load"
echo "Disk Usage: $disk_usage"
echo "Memory Usage: $memory_usage"
echo "Network Connectivity (8.8.8.8): $ping_result"

# Add logic for alerts/warnings based on thresholds, example

CPU_THRESHOLD=2.0
MEMORY_THRESHOLD=80.0
DISK_THRESHOLD=90

cpu_load_val=$(echo $cpu_load | tr -d ',')

if (( $(echo "$cpu_load_val > $CPU_THRESHOLD" | bc -l) )); then
  echo "WARNING: CPU load is high ($cpu_load_val)"
fi

memory_usage_val=$(echo $memory_usage | tr -d '%')

if (( $(echo "$memory_usage_val > $MEMORY_THRESHOLD" | bc -l) )); then
  echo "WARNING: Memory usage is high ($memory_usage_val%)"
fi

disk_usage_val=$(echo $disk_usage | tr -d '%')
if [[ ${disk_usage_val::-1} -gt $DISK_THRESHOLD ]]; then
  echo "WARNING: Disk usage is high ($disk_usage_val%)"
fi
```