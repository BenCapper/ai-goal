# This script kills all Java processes that have been running for more than 1 hour.
# It uses ps to find the processes, awk to filter by name and start time,
# and kill to terminate the identified processes.

# Find all Java processes and their start times.
ps -eo pid,comm,etime | awk '$2 == "java" && $3 ~ /:/{
  # Calculate the runtime in minutes.  Check for days in etime.
  split($3, time_parts, ":");
  if (length(time_parts) == 3) {
      hours = time_parts[1];
      minutes = time_parts[2];
      seconds = time_parts[3];
  } else {
      minutes = time_parts[1];
      seconds = time_parts[2];
      hours = 0;  # default to 0 hours if only minutes and seconds are present
  }
  runtime_minutes = hours * 60 + minutes;

  # Check if the runtime is greater than 60 minutes (1 hour).
  if (runtime_minutes > 60) {
    print $1; # Print the PID
  }
}' | while read pid; do
  # Kill the process if a PID was found.
  if [ -n "$pid" ]; then
    echo "Killing Java process with PID: $pid"
    kill -9 "$pid"
  fi
done
```