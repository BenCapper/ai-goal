# This script analyzes system logs for security-related events
# using journalctl and regular expressions. It sends real-time
# alerts via email for specific events like failed SSH logins
# or privilege escalations.

# Usage: ./security_log_analyzer.sh
# Configuration
EMAIL="your_email@example.com"
SSH_FAILURE_REGEX="Failed password for invalid user|Invalid user|Disconnected from invalid user"
SU_FAILURE_REGEX="authentication failure"
SUDO_FAILURE_REGEX="authentication failure"
SUDO_SUCCESS_REGEX="COMMAND"
ALERT_PREFIX="[Security Alert]"

# Function to send email alert
send_alert() {
  subject="$ALERT_PREFIX: $1"
  body="$2"
  echo "$body" | mail -s "$subject" "$EMAIL"
}

# Monitor journalctl for SSH login failures
monitor_ssh_failures() {
  journalctl -f -t sshd | while read -r line; do
    if [[ "$line" =~ $SSH_FAILURE_REGEX ]]; then
      message="Possible SSH login failure: $line"
      send_alert "SSH Login Failure" "$message"
    fi
  done
}

# Monitor journalctl for su failures
monitor_su_failures() {
  journalctl -f -t su | while read -r line; do
    if [[ "$line" =~ $SU_FAILURE_REGEX ]]; then
      message="Possible su failure: $line"
      send_alert "SU Failure" "$message"
    fi
  done
}

# Monitor journalctl for sudo failures
monitor_sudo_failures() {
  journalctl -f -t sudo | while read -r line; do
    if [[ "$line" =~ $SUDO_FAILURE_REGEX ]]; then
      message="Possible sudo failure: $line"
      send_alert "Sudo Failure" "$message"
    fi
  done
}

# Monitor journalctl for successful sudo commands
monitor_sudo_successes() {
  journalctl -f -t sudo | while read -r line; do
    if [[ "$line" =~ $SUDO_SUCCESS_REGEX ]]; then
      message="Successful sudo command executed: $line"
      send_alert "Sudo Command Executed" "$message"
    fi
  done
}


# Main function to start monitoring processes
main() {
  monitor_ssh_failures &
  monitor_su_failures &
  monitor_sudo_failures &
  monitor_sudo_successes &

  wait
}

main
```