# This script replaces a resourcequota in OpenShift using oc replace -f.

# Check if a file path is provided as an argument
if [ -z "$1" ]; then
  echo "Usage: $0 <resourcequota_file>"
  exit 1
fi

# ResourceQuota file path
RESOURCEQUOTA_FILE="$1"

# Check if the file exists
if [ ! -f "$RESOURCEQUOTA_FILE" ]; then
  echo "Error: File '$RESOURCEQUOTA_FILE' not found."
  exit 1
fi

# Replace the resourcequota
echo "Replacing resourcequota using file: $RESOURCEQUOTA_FILE"
oc replace -f "$RESOURCEQUOTA_FILE"

# Check the exit code to determine success or failure
if [ $? -eq 0 ]; then
  echo "Resourcequota replaced successfully."
else
  echo "Error: Failed to replace resourcequota."
  exit 1
fi
```