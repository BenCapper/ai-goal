# This script creates a new cluster role with specific permissions using oc create clusterrole.

# Define the cluster role name
CLUSTER_ROLE_NAME="my-custom-clusterrole"

# Define the verbs allowed
VERBS="get, list, watch"

# Define the resources the role has access to
RESOURCES="pods, deployments, services"

# Define the API groups the role has access to
API_GROUPS=""

# Create the cluster role using oc create clusterrole
oc create clusterrole "${CLUSTER_ROLE_NAME}" \
  --verb="${VERBS}" \
  --resource="${RESOURCES}" \
  --api-group="${API_GROUPS}"

echo "Cluster role '${CLUSTER_ROLE_NAME}' created successfully."
```