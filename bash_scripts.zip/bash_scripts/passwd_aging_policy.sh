# This script demonstrates how to use the passwd command with options
# for password aging and policy enforcement.

# Set user name
USER="testuser"

# Set password aging parameters
MIN_DAYS=7    # Minimum number of days before password change is allowed
MAX_DAYS=90   # Maximum number of days a password is valid
WARN_DAYS=14  # Number of days before password expiry to warn user
INACTIVE_DAYS=30 # Number of days after password expiry before account is disabled

# Create user if it doesn't exist.  Don't set a password initially.
id $USER >/dev/null 2>&1 || sudo useradd $USER

# Change password aging parameters for the user
sudo chage -m $MIN_DAYS -M $MAX_DAYS -W $WARN_DAYS -I $INACTIVE_DAYS $USER

# Force user to change password on next login
sudo chage -d 0 $USER

# Display current password aging information for the user
sudo chage -l $USER

# File usage:
# ./passwd_aging_policy.sh
```