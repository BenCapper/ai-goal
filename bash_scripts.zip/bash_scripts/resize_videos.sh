# This script takes a directory of video files and converts them
# to a specified resolution using ffmpeg.

# Usage: ./resize_videos.sh <input_directory> <output_directory> <width> <height>

# Check if ffmpeg is installed
if ! command -v ffmpeg &> /dev/null
then
    echo "ffmpeg could not be found. Please install it."
    exit 1
fi

# Check if the correct number of arguments are provided
if [ $# -ne 4 ]; then
    echo "Usage: ./resize_videos.sh <input_directory> <output_directory> <width> <height>"
    exit 1
fi

# Set input and output directories, width, and height
input_dir="$1"
output_dir="$2"
width="$3"
height="$4"

# Check if the input directory exists
if [ ! -d "$input_dir" ]; then
    echo "Input directory '$input_dir' does not exist."
    exit 1
fi

# Create the output directory if it doesn't exist
if [ ! -d "$output_dir" ]; then
    mkdir -p "$output_dir"
fi

# Loop through all video files in the input directory
find "$input_dir" -type f \( -name "*.mp4" -o -name "*.avi" -o -name "*.mkv" \) -print0 | while IFS= read -r -d $'\0' input_file; do
    # Get the filename without the extension
    filename=$(basename "$input_file")
    filename_without_ext="${filename%.*}"

    # Create the output file name
    output_file="$output_dir/${filename_without_ext}_resized.mp4"

    # Resize the video using ffmpeg
    ffmpeg -i "$input_file" -vf scale="$width:$height" -c:a copy "$output_file"

    # Check if the conversion was successful
    if [ $? -eq 0 ]; then
        echo "Successfully resized '$filename' to ${width}x${height} and saved to '$output_file'"
    else
        echo "Error resizing '$filename'"
    fi
done

echo "Video resizing complete."
exit 0
```