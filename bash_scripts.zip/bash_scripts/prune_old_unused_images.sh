# This script removes all Docker and Podman container images that are older than a specified date
# and not currently used by any running containers or pods.

# Set the age threshold (in days).  Images older than this will be removed.
AGE_THRESHOLD=30

# Get the current date and subtract the age threshold to get the cutoff date.
CUTOFF_DATE=$(date -d "$AGE_THRESHOLD days ago" +%Y-%m-%dT%H:%M:%S)

# Function to prune Docker images
prune_docker_images() {
  echo "Pruning Docker images older than $CUTOFF_DATE..."

  # Get a list of all Docker images that are older than the cutoff date and not currently in use.
  # The --format option is used to output the image ID and the created date in ISO 8601 format.
  # The grep command filters out images created before the cutoff date.
  # The awk command extracts the image ID.
  # The docker inspect command retrieves information about each image, including whether it is referenced by any containers.
  # The grep -v command filters out images that are currently referenced by containers.
  # The xargs command executes the docker rmi command to remove the images.
  docker images --all --format "{{.ID}} {{.Created}}" |
    grep "^[a-f0-9]\{12,\} $CUTOFF_DATE" |
    awk '{print $1}' |
    xargs -r -I {} bash -c 'if ! docker inspect -f "{{.Containers}}" {} >/dev/null 2>&1; then docker rmi {}; fi'

  echo "Docker image pruning complete."
}

# Function to prune Podman images
prune_podman_images() {
  echo "Pruning Podman images older than $CUTOFF_DATE..."

  # Similar logic as Docker, but uses Podman commands.
  # The podman inspect command retrieves information about each image, including whether it is referenced by any containers or pods.
  podman images --all --format "{{.ID}} {{.Created}}" |
    grep "^[a-f0-9]\{12,\} $CUTOFF_DATE" |
    awk '{print $1}' |
    xargs -r -I {} bash -c 'if ! podman inspect -f "{{.Containers}}" {} >/dev/null 2>&1; then podman rmi {}; fi'

  echo "Podman image pruning complete."
}

# Run the pruning functions for Docker and Podman.
prune_docker_images
prune_podman_images

echo "Image pruning process complete."
```