# This script connects to a database (MySQL/MariaDB assumed) and
# retrieves a list of users along with their privileges and roles.
# It then formats and displays the information in a human-readable way.

# Database connection details - CHANGE THESE TO YOUR ACTUAL VALUES
DB_HOST="localhost"
DB_USER="root"
DB_PASSWORD="your_root_password"
DB_NAME="mysql"  # System database for user information

# Function to fetch user privileges
get_user_privileges() {
  local user=$1
  local host=$2

  mysql -h "$DB_HOST" -u "$DB_USER" -p"$DB_PASSWORD" -D "$DB_NAME" -N -s -e "SHOW GRANTS FOR '$user'@'$host';" | grep -v "^GRANT USAGE"
}

# Main script execution
echo "Database User Privilege Report"
echo "-----------------------------"

mysql -h "$DB_HOST" -u "$DB_USER" -p"$DB_PASSWORD" -D "$DB_NAME" -N -s -e "SELECT User, Host FROM user WHERE User != ''" | while IFS=$'\t' read -r user host; do
  echo "User: $user@$host"
  echo "---------------------"
  get_user_privileges "$user" "$host"
  echo ""
done

echo "Report Generation Complete."
```