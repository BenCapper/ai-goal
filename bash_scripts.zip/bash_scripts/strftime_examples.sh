# This script demonstrates how to use the strftime utility to format dates and times.
# strftime takes a format string and a timestamp (optional) as input and outputs the formatted date/time.

# Get the current date and time in the default format
current_date=$(date)
echo "Current date and time (default): $current_date"

# Use strftime to format the current date in YYYY-MM-DD format
formatted_date=$(date +%Y-%m-%d)
echo "Formatted date (YYYY-MM-DD): $formatted_date"

# Use strftime to format the current time in HH:MM:SS format
formatted_time=$(date +%H:%M:%S)
echo "Formatted time (HH:MM:SS): $formatted_time"

# Combine date and time formats
formatted_datetime=$(date +%Y-%m-%d_%H:%M:%S)
echo "Formatted date and time (YYYY-MM-DD_HH:MM:SS): $formatted_datetime"

# Get the day of the week
day_of_week=$(date +%A)
echo "Day of the week: $day_of_week"

# Get the month name
month_name=$(date +%B)
echo "Month name: $month_name"

# Get the year
year=$(date +%Y)
echo "Year: $year"

# Get the Unix timestamp (seconds since epoch)
timestamp=$(date +%s)
echo "Unix timestamp: $timestamp"

# Format a specific date and time using a timestamp
# Example: January 1, 2024 00:00:00 UTC (timestamp: 1704067200)
specific_date=$(date -d @1704067200 +%Y-%m-%d_%H:%M:%S)
echo "Specific date (YYYY-MM-DD_HH:MM:SS): $specific_date"

# Use different separators
date_with_slashes=$(date +%Y/%m/%d)
echo "Date with slashes (YYYY/MM/DD): $date_with_slashes"

# Use custom format
custom_format=$(date "+Today is %A, %B %d, %Y")
echo "Custom format: $custom_format"

# File usage: ./strftime_examples.sh
```