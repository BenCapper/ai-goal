# This script takes a directory of astronomical data files
# and performs basic analysis, such as plotting light curves.
# It requires the following tools:
# - gnuplot (for plotting)
# - awk (for data manipulation)

# Usage: ./analyze_astro_data.sh <directory>

# Check if the correct number of arguments is provided
if [ $# -ne 1 ]; then
  echo "Usage: ./analyze_astro_data.sh <directory>"
  exit 1
fi

directory="$1"

# Check if the directory exists
if [ ! -d "$directory" ]; then
  echo "Error: Directory '$directory' does not exist."
  exit 1
fi

# Iterate through each file in the directory
for file in "$directory"/*; do
  # Check if it is a regular file
  if [ -f "$file" ]; then
    echo "Processing file: $file"

    # Extract filename without extension for plot title
    filename=$(basename "$file")
    filename_no_ext="${filename%.*}"

    # Create a temporary data file for gnuplot
    temp_data_file=$(mktemp)

    # Assuming the data files are in a format where the first column is time and the second column is magnitude
    # and you want to plot magnitude vs time.
    # Adjust the awk command accordingly if your data format is different.
    awk '{print $1, $2}' "$file" > "$temp_data_file"

    # Generate a gnuplot script
    gnuplot_script=$(cat <<EOF
    set terminal png size 800,600
    set output "${filename_no_ext}.png"
    set title "Light Curve for ${filename_no_ext}"
    set xlabel "Time"
    set ylabel "Magnitude"
    plot "$temp_data_file" with lines title "Data"
EOF
)

    # Run gnuplot with the generated script
    gnuplot -e "$gnuplot_script"

    # Clean up the temporary data file
    rm "$temp_data_file"

    echo "Generated plot: ${filename_no_ext}.png"
  fi
done

echo "Analysis complete."

exit 0
```