# This script uses git to show the differences between the working directory and the staging area.
# It displays unstaged changes that have been made to tracked files.

git diff
```