# This script demonstrates how to use the `route` and `ip route` commands
# to manage routing based on source IP addresses. It shows how to add,
# delete, and list routing rules for specific source IPs.

# Usage: ./source_routing.sh

# Define variables for source and destination IPs, and gateway
SOURCE_IP="192.168.1.100"
DEST_IP="8.8.8.8"
GATEWAY="192.168.1.1"
INTERFACE="eth0"


# Add a route for packets originating from SOURCE_IP to DEST_IP via GATEWAY
echo "Adding route for source IP $SOURCE_IP to $DEST_IP via $GATEWAY..."
sudo ip route add from $SOURCE_IP to $DEST_IP via $GATEWAY dev $INTERFACE

# Verify the route has been added
echo "Listing routing table..."
ip route show table all | grep "$SOURCE_IP"

# Optionally, add a default route based on source IP. This example uses a separate routing table
# and policy routing with 'ip rule'. Remove this section if it's not needed.
# Note: Using policy routing requires careful consideration of your network setup.
echo "Adding default route for source IP $SOURCE_IP to table 100..."
sudo ip route add default via $GATEWAY dev $INTERFACE table 100
echo "Adding rule to route packets from $SOURCE_IP to table 100..."
sudo ip rule add from $SOURCE_IP table 100
echo "Listing ip rules..."
ip rule list | grep "$SOURCE_IP"


# Delete the source-based route we added earlier
echo "Deleting route for source IP $SOURCE_IP to $DEST_IP via $GATEWAY..."
sudo ip route del from $SOURCE_IP to $DEST_IP via $GATEWAY dev $INTERFACE

# Verify the route has been deleted
echo "Listing routing table again..."
ip route show table all | grep "$SOURCE_IP"

# Delete policy routing rules and table if previously added.
echo "Deleting rule to route packets from $SOURCE_IP to table 100..."
sudo ip rule del from $SOURCE_IP table 100
echo "Deleting default route from table 100..."
sudo ip route del default via $GATEWAY dev $INTERFACE table 100

exit 0
```