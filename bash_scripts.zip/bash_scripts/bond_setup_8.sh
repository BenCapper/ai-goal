# This script automates the process of setting up a basic network bonding
# with balance-rr mode on a Linux system. It assumes you have two network
# interfaces available for bonding (e.g., eth0 and eth1).  It will:
# 1. Identify the interfaces to bond.
# 2. Create a bonding interface (bond0).
# 3. Configure the bonding interface with balance-rr mode.
# 4. Configure the physical interfaces as slaves to the bond.
# 5. Restart the networking service.
#
# Usage: sudo ./bond_setup.sh <interface1> <interface2> <bond_name> <ip_address> <netmask> <gateway>
# Example: sudo ./bond_setup.sh eth0 eth1 bond0 192.168.1.100 255.255.255.0 192.168.1.1

# Set the variables based on command-line arguments
INTERFACE1=$1
INTERFACE2=$2
BOND_NAME=$3
IP_ADDRESS=$4
NETMASK=$5
GATEWAY=$6
BOND_FILE="/etc/network/interfaces.d/${BOND_NAME}"

# Check if all required arguments are provided
if [ -z "$INTERFACE1" ] || [ -z "$INTERFACE2" ] || [ -z "$BOND_NAME" ] || [ -z "$IP_ADDRESS" ] || [ -z "$NETMASK" ] || [ -z "$GATEWAY" ]; then
  echo "Error: Missing arguments."
  echo "Usage: sudo ./bond_setup.sh <interface1> <interface2> <bond_name> <ip_address> <netmask> <gateway>"
  exit 1
fi

# Ensure the /etc/network/interfaces.d directory exists
if [ ! -d /etc/network/interfaces.d ]; then
  echo "Creating /etc/network/interfaces.d directory"
  mkdir -p /etc/network/interfaces.d
fi

# Create the bonding configuration file
cat > "$BOND_FILE" <<EOL
# Bonding interface configuration
auto $BOND_NAME
iface $BOND_NAME inet static
    address $IP_ADDRESS
    netmask $NETMASK
    gateway $GATEWAY
    bond-mode balance-rr
    bond-miimon 100
    bond-lacp-rate fast
    bond-slaves $INTERFACE1 $INTERFACE2

# Configure the physical interfaces
auto $INTERFACE1
iface $INTERFACE1 inet manual
    bond-master $BOND_NAME

auto $INTERFACE2
iface $INTERFACE2 inet manual
    bond-master $BOND_NAME
EOL

# Bring down the interfaces
ifconfig "$INTERFACE1" down
ifconfig "$INTERFACE2" down

# Restart the networking service
echo "Restarting networking service..."
systemctl restart networking

echo "Bonding setup complete."
echo "Verify bonding status with: cat /proc/net/bonding/$BOND_NAME"
```