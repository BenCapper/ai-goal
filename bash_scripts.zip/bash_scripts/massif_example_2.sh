# This script demonstrates how to use valgrind's massif tool with stack tracing enabled.
# It creates a simple C program that allocates memory on the heap and stack.
# The massif tool is used to analyze the memory usage of the program, with the stack=yes option
# to enable tracking of memory allocated on the stack.

# Create a simple C program for demonstration.
cat <<EOF > mem_alloc.c
#include <stdio.h>
#include <stdlib.h>

#define SIZE 1024 * 1024  // 1MB

void stack_alloc(int n) {
    int arr[n]; // Allocate on the stack.
    for (int i = 0; i < n; i++) {
        arr[i] = i; // Fill with some data to prevent compiler optimization
    }
    printf("Allocated %d bytes on the stack\n", n * sizeof(int));

}

int main() {
    // Allocate memory on the heap
    char *heap_mem = (char *)malloc(SIZE);
    if (heap_mem == NULL) {
        perror("malloc failed");
        return 1;
    }

    printf("Allocated %d bytes on the heap\n", SIZE);

    stack_alloc(10000);

    // Do something with the memory (e.g., write to it) to prevent optimization.
    for (int i = 0; i < SIZE; ++i) {
        heap_mem[i] = 'A';
    }

    // Free the allocated memory
    free(heap_mem);
    printf("Freed heap memory\n");

    return 0;
}
EOF

# Compile the C program.
gcc -g -o mem_alloc mem_alloc.c

# Run the program with valgrind's massif tool and enable stack tracing.
valgrind --tool=massif --stacks=yes ./mem_alloc

# Optional: create a massif output file
# valgrind --tool=massif --stacks=yes --log-file=massif.out ./mem_alloc

# Generate the massif output graph
# ms_print massif.out > massif.txt

# Cleanup the executable
rm -f mem_alloc mem_alloc.c
```