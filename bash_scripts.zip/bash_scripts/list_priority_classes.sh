# This script lists all priority classes in the OpenShift cluster.
# It uses the `oc` command-line tool to retrieve the priority classes.

oc get priorityclass
```