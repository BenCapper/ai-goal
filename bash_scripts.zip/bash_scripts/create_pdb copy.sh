# This script creates a Pod Disruption Budget (PDB) for a given deployment in OpenShift.
# It uses `oc create -f` to apply the PDB configuration from a YAML file.

# Define variables
DEPLOYMENT_NAME="my-deployment" # Replace with your deployment name
PDB_NAME="my-pdb" # Replace with your desired PDB name
NAMESPACE="my-project" # Replace with your project/namespace
MIN_AVAILABLE=1  # Minimum number of pods that must be available

# Create a PDB YAML file
cat <<EOF > pdb.yaml
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: ${PDB_NAME}
  namespace: ${NAMESPACE}
spec:
  minAvailable: ${MIN_AVAILABLE}
  selector:
    matchLabels:
      app: ${DEPLOYMENT_NAME} # Assuming your deployment pods have this label
EOF

# Apply the PDB using oc create
oc create -f pdb.yaml -n ${NAMESPACE}

# Optional: Clean up the temporary file
rm pdb.yaml

echo "Pod Disruption Budget ${PDB_NAME} created for deployment ${DEPLOYMENT_NAME} in namespace ${NAMESPACE}."
```