# This script converts temperatures between Celsius and Fahrenheit.
# It takes a temperature value and a unit to convert from as input.
# It then outputs the converted temperature value in the other unit.

# Function to convert Celsius to Fahrenheit
celsius_to_fahrenheit() {
  local celsius=$1
  local fahrenheit=$(echo "scale=2; (9/5) * $celsius + 32" | bc)
  echo "$fahrenheit"
}

# Function to convert Fahrenheit to Celsius
fahrenheit_to_celsius() {
  local fahrenheit=$1
  local celsius=$(echo "scale=2; (5/9) * ($fahrenheit - 32)" | bc)
  echo "$celsius"
}

# Check if the correct number of arguments are provided
if [ $# -ne 2 ]; then
  echo "Usage: $0 <temperature> <unit (C or F)>"
  exit 1
fi

temperature=$1
unit=$(echo "$2" | tr '[:upper:]' '[:lower:]') # Convert unit to lowercase for case-insensitive comparison

# Validate the unit
if [[ "$unit" != "c" && "$unit" != "f" ]]; then
  echo "Error: Invalid unit.  Must be C or F."
  exit 1
fi

# Convert the temperature based on the unit
case "$unit" in
  "c")
    converted_temperature=$(celsius_to_fahrenheit "$temperature")
    converted_unit="F"
    ;;
  "f")
    converted_temperature=$(fahrenheit_to_celsius "$temperature")
    converted_unit="C"
    ;;
  *)
    echo "Error:  Invalid unit."  # This should be unreachable due to earlier validation.
    exit 1
    ;;
esac

# Output the result
echo "$temperature $unit is equal to $converted_temperature $converted_unit"
```