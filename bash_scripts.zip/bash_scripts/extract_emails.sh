# This script takes a URL as an argument, downloads the webpage,
# and extracts all email addresses from the HTML content using grep.

# Check if a URL is provided as an argument
if [ -z "$1" ]; then
  echo "Usage: $0 <URL>"
  exit 1
fi

URL="$1"

# Download the webpage content using curl
CONTENT=$(curl -s "$URL")

# Extract email addresses using grep and regular expression
EMAIL_ADDRESSES=$(echo "$CONTENT" | grep -oE "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")

# Print the extracted email addresses
if [ -z "$EMAIL_ADDRESSES" ]; then
  echo "No email addresses found on $URL"
else
  echo "$EMAIL_ADDRESSES"
fi

exit 0
```