# This script retrieves the last 50 kernel log lines 
# and searches for lines containing a specific hardware error.

# Define the hardware error string to search for.
ERROR_STRING="Hardware Error"

# Retrieve the last 50 kernel log lines using tail or journalctl, depending on availability.
if command -v tail >/dev/null 2>&1 && [ -f /var/log/kern.log ]; then
    KERNEL_LOG=$(tail -n 50 /var/log/kern.log)
elif command -v journalctl >/dev/null 2>&1; then
    KERNEL_LOG=$(journalctl -k -n 50)
else
    echo "Error: Neither tail nor journalctl are available."
    exit 1
fi

# Search for the error string in the kernel log output.
ERROR_LINES=$(echo "$KERNEL_LOG" | grep "$ERROR_STRING")

# Check if any errors were found.
if [ -n "$ERROR_LINES" ]; then
  echo "Hardware errors found in the kernel log:"
  echo "$ERROR_LINES"
else
  echo "No hardware errors found in the last 50 kernel log lines."
fi

# Usage: ./check_kernel_errors.sh
```