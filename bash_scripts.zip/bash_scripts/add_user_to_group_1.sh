#
# This script adds the user "john" to the "developers" group.
# It checks if the user exists before attempting to add them to the group.
# It also checks if the group exists before attempting to add the user.

USER="john"
GROUP="developers"

# Check if the user exists
if id -u "$USER" > /dev/null 2>&1; then
  # Check if the group exists
  if getent group "$GROUP" > /dev/null; then
    # Add the user to the group
    sudo usermod -a -G "$GROUP" "$USER"
    echo "User '$USER' added to group '$GROUP'."
  else
    echo "Group '$GROUP' does not exist."
  fi
else
  echo "User '$USER' does not exist."
fi
```