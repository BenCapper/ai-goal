# This script takes a directory and recursively finds all files
# that have a size within a specified range.

# Usage: ./find_files_by_size.sh <directory> <min_size_kb> <max_size_kb>

# Check if the correct number of arguments is provided
if [ $# -ne 3 ]; then
  echo "Usage: $0 <directory> <min_size_kb> <max_size_kb>"
  exit 1
fi

# Assign arguments to variables
directory="$1"
min_size_kb="$2"
max_size_kb="$3"

# Check if the directory exists
if [ ! -d "$directory" ]; then
  echo "Error: Directory '$directory' does not exist."
  exit 1
fi

# Check if min and max sizes are valid numbers
if ! [[ "$min_size_kb" =~ ^[0-9]+$ ]]; then
  echo "Error: Minimum size must be a non-negative integer (in KB)."
  exit 1
fi

if ! [[ "$max_size_kb" =~ ^[0-9]+$ ]]; then
  echo "Error: Maximum size must be a non-negative integer (in KB)."
  exit 1
fi

# Check if min size is less than or equal to max size
if [ "$min_size_kb" -gt "$max_size_kb" ]; then
  echo "Error: Minimum size must be less than or equal to maximum size."
  exit 1
fi

# Find files recursively within the size range
find "$directory" -type f -size +"$(($min_size_kb - 1))k" -size -"$(($max_size_kb + 1))k" -print
```