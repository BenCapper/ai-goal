# This script analyzes a text file and counts the frequency of each letter.
# It ignores case and only counts alphabetic characters.
# The script takes the filename as a command-line argument.

if [ $# -ne 1 ]; then
  echo "Usage: $0 <filename>"
  exit 1
fi

filename="$1"

if [ ! -f "$filename" ]; then
  echo "Error: File '$filename' not found."
  exit 1
fi

# Initialize an associative array to store letter frequencies.
declare -A letter_counts

# Loop through each character in the file, converting to lowercase.
while IFS= read -r -n 1 char; do
  char_lower=$(echo "$char" | tr '[:upper:]' '[:lower:]')

  # Check if the character is a letter.
  if [[ "$char_lower" =~ [a-z] ]]; then
    # Increment the count for the letter.
    ((letter_counts["$char_lower"]++))
  fi
done < "$filename"

# Print the letter frequencies, sorted alphabetically.
for letter in $(printf '%s\n' "${!letter_counts[@]}" | sort); do
  echo "$letter: ${letter_counts[$letter]}"
done
```