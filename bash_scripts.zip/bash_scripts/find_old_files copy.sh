# This script uses the find command to locate all files
# in a specified directory that are older than a given number of days.

# Set the directory to search in.  Defaults to current directory if not provided.
directory="${1:-.}"

# Set the age of the files (in days). Defaults to 30 days if not provided.
age="${2:-30}"

# Find files older than the specified number of days.
find "$directory" -type f -mtime +"$age"

# Explanation of the find command:
#   find:  The find command.
#   "$directory":  The directory to search in.  Quoting handles spaces.
#   -type f:  Specifies to only find files (not directories, links, etc.).
#   -mtime +"$age":  Specifies to find files modified more than $age days ago. Quoting handles variables.
```