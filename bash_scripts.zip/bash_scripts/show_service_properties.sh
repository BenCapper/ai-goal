# This script uses systemctl show to display the properties of a specified service.
# It takes the service name as a command-line argument.
# If no argument is provided, it prints a usage message and exits.

# Usage: ./show_service_properties.sh <service_name>

# Check if a service name is provided as an argument.
if [ $# -eq 0 ]; then
  echo "Usage: $0 <service_name>"
  exit 1
fi

# The name of the service to inspect.
SERVICE_NAME="$1"

# Use systemctl show to display the properties of the service.
systemctl show "$SERVICE_NAME"
```