# This script lists all environment variables that contain the word "PATH".
# It iterates through all environment variables and checks if the variable name
# contains the string "PATH". If it does, it prints the variable name and value.

set -o allexport # Export all variables
set +o allexport # Stop exporting variables, but keep the variables set in the environment
for var in $(env | cut -d'=' -f1); do
  if [[ "$var" == *PATH* ]]; then
    echo "$var=${!var}"
  fi
done
```