# This script uses cat and grep to find groups in /etc/group that have exactly eight members.
# It assumes the group members are listed as comma-separated values after the group ID.

# Usage: ./find_groups_with_eight_members.sh

cat /etc/group | grep -E "^\w+:[^:]*:\d+:\w+,\w+,\w+,\w+,\w+,\w+,\w+,\w+$"
```