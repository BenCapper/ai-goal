# This script iterates through a sequence of numbers and prints a message if the number is not equal to 0, 1, 2, 3, 4, 5, 6, 7, and 8.
# It uses a for loop, an if statement, logical AND, and numerical comparison.

# Usage: ./check_numbers.sh

for i in {0..10}
do
  if [[ $i -ne 0 && $i -ne 1 && $i -ne 2 && $i -ne 3 && $i -ne 4 && $i -ne 5 && $i -ne 6 && $i -ne 7 && $i -ne 8 ]]; then
    echo "$i is not equal to 0 and also not equal to 1 and also not equal to 2 and also not equal to 3 and also not equal to 4 and also not equal to 5 and also not equal to 6 and also not equal to 7 and also not equal to 8"
  fi
done
```