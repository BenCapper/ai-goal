# This script generates a simple YAML list of strings.
# It takes a variable number of arguments, each of which
# becomes an item in the YAML list.

# Usage: ./generate_yaml_list.sh item1 item2 item3

echo "---"
for item in "$@"; do
  echo "- \"$item\""
done
```