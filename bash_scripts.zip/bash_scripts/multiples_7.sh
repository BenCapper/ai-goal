# This script iterates through a sequence of numbers from 1 to 100 and
# checks if each number is a multiple of 3 and 4 but not 6.
# If the number satisfies the condition, it prints the number and a message.

# Usage: ./multiples.sh

for i in $(seq 1 100); do
  if (( (i % 3 == 0) && (i % 4 == 0) && (i % 6 != 0) )); then
    echo "$i is a multiple of 3 and also a multiple of 4 but not a multiple of 6"
  fi
done
# Usage: ./multiples.sh
```