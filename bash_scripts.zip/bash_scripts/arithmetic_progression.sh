# This script checks if a sequence of space-separated numbers forms an arithmetic progression.
# It reads the sequence from a variable, splits it using IFS and a for loop,
# and then uses an if statement with arithmetic expansion to check the condition.

# Usage: ./arithmetic_progression.sh

NUM_SEQUENCE_MATH="2 4 6 8 10"

# Set the internal field separator to space
IFS=' '

# Convert the string into an array
read -ra NUM_ARRAY <<< "$NUM_SEQUENCE_MATH"

# Get the number of elements in the array
ARRAY_LENGTH=${#NUM_ARRAY[@]}

# Check if the sequence has at least three numbers
if [[ $ARRAY_LENGTH -lt 3 ]]; then
  echo "Sequence must contain at least three numbers to check for arithmetic progression."
  exit 1
fi

# Calculate the common difference between the first two elements
COMMON_DIFF=$((NUM_ARRAY[1] - NUM_ARRAY[0]))

# Iterate through the rest of the sequence and check if the difference is consistent
IS_ARITHMETIC=true
for ((i=2; i<$ARRAY_LENGTH; i++)); do
  DIFF=$((NUM_ARRAY[$i] - NUM_ARRAY[$((i-1))]))
  if [[ $DIFF -ne $COMMON_DIFF ]]; then
    IS_ARITHMETIC=false
    break
  fi
done

# Output the result
if $IS_ARITHMETIC; then
  echo "The sequence '$NUM_SEQUENCE_MATH' forms an arithmetic progression."
else
  echo "The sequence '$NUM_SEQUENCE_MATH' does not form an arithmetic progression."
fi

#End of script
# ./arithmetic_progression.sh
```