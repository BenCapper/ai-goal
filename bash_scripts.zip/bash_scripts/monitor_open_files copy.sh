# This script monitors the number of open files for a specific user.
# It takes the username as an argument.
# It periodically checks the number of open files and prints the current count.

# Check if a username is provided
if [ -z "$1" ]; then
  echo "Usage: $0 <username>"
  exit 1
fi

username="$1"

# Function to count the number of open files for the user
count_open_files() {
  lsof -u "$username" | wc -l
}

# Main loop
while true; do
  open_files=$(count_open_files)
  echo "User $username has $open_files open files."
  sleep 5 # Check every 5 seconds
done
```