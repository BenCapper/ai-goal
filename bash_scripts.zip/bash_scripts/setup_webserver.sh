# This script automates the setup of a basic web server with user authentication using htpasswd.
# It installs Apache2, creates a directory for the website, sets up htpasswd authentication,
# and configures Apache to require authentication for the website directory.

# Update package list
sudo apt update

# Install Apache2
sudo apt install apache2 -y

# Create a directory for the website
WEBSITE_DIR="/var/www/mywebsite"
sudo mkdir -p "$WEBSITE_DIR"

# Create a simple index.html file
echo "<h1>Welcome to my website!</h1>" | sudo tee "$WEBSITE_DIR/index.html"

# Create an htpasswd file
HTPASSWD_FILE="/etc/apache2/.htpasswd"
sudo htpasswd -c "$HTPASSWD_FILE" myuser

# Enable .htaccess file usage in website directory
sudo sed -i "s/AllowOverride None/AllowOverride All/g" /etc/apache2/apache2.conf

# Configure Apache to require authentication for the website directory
echo "<Directory \"$WEBSITE_DIR\">" | sudo tee /etc/apache2/conf-available/mywebsite.conf
echo "    AuthType Basic" | sudo tee -a /etc/apache2/conf-available/mywebsite.conf
echo "    AuthName \"Restricted Area\"" | sudo tee -a /etc/apache2/conf-available/mywebsite.conf
echo "    AuthUserFile $HTPASSWD_FILE" | sudo tee -a /etc/apache2/conf-available/mywebsite.conf
echo "    Require valid-user" | sudo tee -a /etc/apache2/conf-available/mywebsite.conf
echo "</Directory>" | sudo tee -a /etc/apache2/conf-available/mywebsite.conf

# Enable the configuration
sudo a2enconf mywebsite

# Create a virtual host file for the website
echo "<VirtualHost *:80>" | sudo tee /etc/apache2/sites-available/mywebsite.conf
echo "    ServerAdmin webmaster@localhost" | sudo tee -a /etc/apache2/sites-available/mywebsite.conf
echo "    DocumentRoot $WEBSITE_DIR" | sudo tee -a /etc/apache2/sites-available/mywebsite.conf
echo "    <Directory \"$WEBSITE_DIR\">" | sudo tee -a /etc/apache2/sites-available/mywebsite.conf
echo "        Options Indexes FollowSymLinks" | sudo tee -a /etc/apache2/sites-available/mywebsite.conf
echo "        AllowOverride All" | sudo tee -a /etc/apache2/sites-available/mywebsite.conf
echo "        Require all granted" | sudo tee -a /etc/apache2/sites-available/mywebsite.conf
echo "    </Directory>" | sudo tee -a /etc/apache2/sites-available/mywebsite.conf
echo "    ErrorLog \${APACHE_LOG_DIR}/error.log" | sudo tee -a /etc/apache2/sites-available/mywebsite.conf
echo "    CustomLog \${APACHE_LOG_DIR}/access.log combined" | sudo tee -a /etc/apache2/sites-available/mywebsite.conf
echo "</VirtualHost>" | sudo tee -a /etc/apache2/sites-available/mywebsite.conf

# Disable the default site
sudo a2dissite 000-default.conf

# Enable the website
sudo a2ensite mywebsite.conf

# Restart Apache
sudo systemctl restart apache2

echo "Web server setup complete!"
echo "Access your website at http://localhost (or your server's IP address)."
echo "You will be prompted for a username and password."
echo "Username: myuser"
echo "You will be prompted to enter a password."
```