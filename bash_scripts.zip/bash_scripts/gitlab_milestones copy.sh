#!/bin/bash

# This script fetches GitLab milestones, filters by title,
# and displays their due dates and completion percentage.

# --- Configuration ---
GITLAB_URL="https://gitlab.com" # Replace with your GitLab instance URL
PROJECT_ID="your_project_id"   # Replace with your project ID (e.g., 12345)
GITLAB_TOKEN="your_private_token" # Replace with your private token
SEARCH_STRING="Release"        # Replace with the string to search for in the milestone title
DUE_DATE_FORMAT="%Y-%m-%d"     # Desired due date format

# --- Script Logic ---

# Check if jq is installed
if ! command -v jq &> /dev/null; then
  echo "Error: jq is not installed. Please install it."
  exit 1
fi

# Fetch milestones from GitLab API
MILESTONE_DATA=$(curl --header "PRIVATE-TOKEN: ${GITLAB_TOKEN}" \
                  "${GITLAB_URL}/api/v4/projects/${PROJECT_ID}/milestones")

# Check if the curl command was successful
if [[ $? -ne 0 ]]; then
  echo "Error: Failed to fetch milestones from GitLab API."
  exit 1
fi

# Filter milestones using jq, extract relevant information, and print
echo "$MILESTONE_DATA" | jq -r --arg search "$SEARCH_STRING" --arg format "$DUE_DATE_FORMAT" \
  '.[] | select(.title | contains($search)) |
   "Title: " + .title +
   ", Due Date: " + (.due_date | strftime($format)) +
   ", Completion: " + (.progress.percentage | tostring) + "%"'
```