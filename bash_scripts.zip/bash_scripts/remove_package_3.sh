# This script removes a specified package using pacman on Arch Linux.
# It prompts the user for the package name to remove and then executes
# the pacman command with the -R flag. It also confirms the action
# before proceeding.

# Prompt the user for the package name
read -p "Enter the name of the package to remove: " package_name

# Confirm the removal
read -p "Are you sure you want to remove '$package_name'? (y/n): " confirm

# Check the confirmation
if [[ "$confirm" == "y" ]]; then
  # Remove the package using pacman
  sudo pacman -R "$package_name"

  # Check the exit code
  if [ $? -eq 0 ]; then
    echo "Package '$package_name' removed successfully."
  else
    echo "Failed to remove package '$package_name'."
  fi
else
  echo "Removal cancelled."
fi
```