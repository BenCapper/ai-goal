# This script removes a specific firewall rule that allows traffic on port 22 (SSH).
# It uses iptables to delete the rule.

# Usage: ./remove_ssh_firewall_rule.sh

# Delete the rule allowing SSH traffic on port 22
iptables -D INPUT -p tcp --dport 22 -j ACCEPT

# Save the iptables configuration (if necessary for your system)
# iptables-save > /etc/iptables/rules.v4 # Debian/Ubuntu
# service iptables save # CentOS/RHEL/Fedora - May vary depending on the service name.
```