# This script creates a TCP route in OpenShift using the oc command.
# It requires the OpenShift CLI (oc) to be installed and configured to connect to a cluster.
#
# The script takes two arguments:
# 1. The name of the route to create.
# 2. The name of the service to route traffic to.
#
# The script creates a TCP route that forwards traffic on port 80 to the specified service.
#
# Usage: ./create_tcp_route.sh <route_name> <service_name>

# Check if the correct number of arguments are provided.
if [ $# -ne 2 ]; then
  echo "Usage: ./create_tcp_route.sh <route_name> <service_name>"
  exit 1
fi

# Assign the arguments to variables.
route_name=$1
service_name=$2

# Create the TCP route.
oc create route --tcp "$route_name" --service="$service_name"

# Check the exit code of the oc command.
if [ $? -eq 0 ]; then
  echo "TCP route '$route_name' created successfully, routing to service '$service_name'."
else
  echo "Failed to create TCP route '$route_name'."
  exit 1
fi

# Example Usage:
# ./create_tcp_route.sh my-tcp-route my-service
```