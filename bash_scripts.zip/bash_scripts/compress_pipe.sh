# This script demonstrates how to use gzip, bzip2, and xz utilities
# with the --stdout option and piping to another command.
# It creates a sample file, compresses it using each utility,
# and then pipes the output to the 'wc -c' command to count the number of bytes.

# Create a sample file
echo "This is a sample text file." > sample.txt

# Compress using gzip and pipe to wc -c
echo "gzip:"
gzip --stdout sample.txt | wc -c

# Compress using bzip2 and pipe to wc -c
echo "bzip2:"
bzip2 --stdout sample.txt | wc -c

# Compress using xz and pipe to wc -c
echo "xz:"
xz --stdout sample.txt | wc -c

# Clean up the sample file
rm sample.txt

# Usage: ./compress_pipe.sh
```