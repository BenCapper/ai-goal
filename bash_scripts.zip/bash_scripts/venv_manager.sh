# This script automates the creation and management of Python virtual environments.
# It provides functions to create, activate, deactivate, and remove virtual environments.

# Usage: ./venv_manager.sh <command> <venv_name> [python_version]
# Available commands:
#   create <venv_name> [python_version]: Creates a new virtual environment.  If python_version is not specified, uses the default system python.
#   activate <venv_name>: Activates an existing virtual environment.
#   deactivate: Deactivates the currently active virtual environment.
#   remove <venv_name>: Removes an existing virtual environment.
#   list: Lists all virtual environments in the VENV_DIR
#   help: Displays this help message.

# Configuration
VENV_DIR="$HOME/.venvs"  # Directory to store virtual environments
DEFAULT_PYTHON_VERSION="python3"  # Default python version

# Function to display help message
help() {
  echo "Usage: ./venv_manager.sh <command> <venv_name> [python_version]"
  echo "Available commands:"
  echo "  create <venv_name> [python_version]: Creates a new virtual environment."
  echo "                                       If python_version is not specified, uses the default system python."
  echo "  activate <venv_name>: Activates an existing virtual environment."
  echo "  deactivate: Deactivates the currently active virtual environment."
  echo "  remove <venv_name>: Removes an existing virtual environment."
  echo "  list: Lists all virtual environments in the VENV_DIR"
  echo "  help: Displays this help message."
}

# Function to create a virtual environment
create_venv() {
  local venv_name="$1"
  local python_version="${2:-$DEFAULT_PYTHON_VERSION}"
  local venv_path="$VENV_DIR/$venv_name"

  # Check if virtualenv is installed, and install if necessary.
  if ! command -v virtualenv &> /dev/null
  then
    echo "virtualenv not found. Installing..."
    sudo yum install -y python3-virtualenv
  fi

  if [ -d "$venv_path" ]; then
    echo "Virtual environment '$venv_name' already exists."
    return 1
  fi

  mkdir -p "$VENV_DIR"

  echo "Creating virtual environment '$venv_name' using $python_version..."
  virtualenv -p "$python_version" "$venv_path"
  if [ $? -eq 0 ]; then
    echo "Virtual environment '$venv_name' created successfully."
  else
    echo "Failed to create virtual environment '$venv_name'."
  fi
}

# Function to activate a virtual environment
activate_venv() {
  local venv_name="$1"
  local venv_path="$VENV_DIR/$venv_name"

  if [ ! -d "$venv_path" ]; then
    echo "Virtual environment '$venv_name' does not exist."
    return 1
  fi

  source "$venv_path/bin/activate"
  echo "Activated virtual environment '$venv_name'."
}

# Function to deactivate the current virtual environment
deactivate_venv() {
  if [ -n "$VIRTUAL_ENV" ]; then
    deactivate
    echo "Deactivated virtual environment."
  else
    echo "No virtual environment is currently active."
  fi
}

# Function to remove a virtual environment
remove_venv() {
  local venv_name="$1"
  local venv_path="$VENV_DIR/$venv_name"

  if [ ! -d "$venv_path" ]; then
    echo "Virtual environment '$venv_name' does not exist."
    return 1
  fi

  echo "Removing virtual environment '$venv_name'..."
  rm -rf "$venv_path"
  if [ $? -eq 0 ]; then
    echo "Virtual environment '$venv_name' removed successfully."
  else
    echo "Failed to remove virtual environment '$venv_name'."
  fi
}

# Function to list all virtual environments
list_venvs() {
  if [ ! -d "$VENV_DIR" ]; then
    echo "No virtual environments found."
    return
  fi

  echo "Virtual environments:"
  find "$VENV_DIR" -maxdepth 1 -type d -not -path "$VENV_DIR" -printf '%P\n'
}

# Main script logic
case "$1" in
  create)
    if [ -z "$2" ]; then
      echo "Error: Virtual environment name is required for the 'create' command."
      help
      exit 1
    fi
    create_venv "$2" "$3"
    ;;
  activate)
    if [ -z "$2" ]; then
      echo "Error: Virtual environment name is required for the 'activate' command."
      help
      exit 1
    fi
    activate_venv "$2"
    ;;
  deactivate)
    deactivate_venv
    ;;
  remove)
    if [ -z "$2" ]; then
      echo "Error: Virtual environment name is required for the 'remove' command."
      help
      exit 1
    fi
    remove_venv "$2"
    ;;
  list)
    list_venvs
    ;;
  help)
    help
    ;;
  *)
    echo "Error: Invalid command '$1'."
    help
    exit 1
    ;;
esac

# End of script
# ./venv_manager.sh create myenv python3.8
```