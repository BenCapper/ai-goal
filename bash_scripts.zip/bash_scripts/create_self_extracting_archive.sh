# This script demonstrates how to create a self-extracting archive using the zip utility.
# A self-extracting archive is a single file that contains both the compressed data and the code needed to extract it.
# When executed, the archive will automatically extract its contents to a specified directory.

# Define the archive name
ARCHIVE_NAME="my_archive.sh"

# Define the directory to be archived
SOURCE_DIRECTORY="my_directory"

# Define the directory where the contents will be extracted by default
EXTRACT_DIRECTORY="extracted_files"

# Create a directory with some dummy files for testing.
mkdir -p "$SOURCE_DIRECTORY"
touch "$SOURCE_DIRECTORY/file1.txt"
echo "This is file1." > "$SOURCE_DIRECTORY/file1.txt"
touch "$SOURCE_DIRECTORY/file2.txt"
echo "This is file2." > "$SOURCE_DIRECTORY/file2.txt"

# Create a self-extracting archive using zip
(
  echo '#!/bin/bash'
  echo "echo 'Extracting files...'"
  echo "mkdir -p \"$EXTRACT_DIRECTORY\""
  echo "tail -n +\$(( \$LINENO + 2 )) \"\$0\" | zcat | tar -xf - -C \"$EXTRACT_DIRECTORY\""
  echo "echo 'Extraction complete! Files are located in the $EXTRACT_DIRECTORY directory.'"
  echo "exit 0"
  echo '#### Archive follows ####'
  zip -r - . | gzip
) > "$ARCHIVE_NAME"

# Make the archive executable
chmod +x "$ARCHIVE_NAME"

# Optional: Clean up dummy directory after demonstrating
# rm -rf "$SOURCE_DIRECTORY"

# file usage: ./create_self_extracting_archive.sh && ./my_archive.sh
```