# This script checks if TCP port 80 is open on the remote host "example.com".
# It uses the 'nc' (netcat) command to attempt a connection to the specified host and port.
# If the connection is successful, it prints "Port 80 is open".
# If the connection fails, it prints "Port 80 is closed".

host="example.com"
port=80

if nc -z "$host" "$port" > /dev/null 2>&1; then
  echo "Port 80 is open"
else
  echo "Port 80 is closed"
fi
```