# This script fetches a specific issue from the GitHub API
# and displays the issue title and body using curl and jq.

# Usage: ./get_github_issue.sh <owner> <repo> <issue_number>

# Example: ./get_github_issue.sh torvalds linux 123

owner="$1"
repo="$2"
issue_number="$3"

if [ -z "$owner" ] || [ -z "$repo" ] || [ -z "$issue_number" ]; then
  echo "Usage: ./get_github_issue.sh <owner> <repo> <issue_number>"
  exit 1
fi

api_url="https://api.github.com/repos/$owner/$repo/issues/$issue_number"

# Fetch the issue data using curl and jq
curl -s "$api_url" | jq '.title, .body'
```