# This script monitors the system's thermal zone temperatures.
# It reads the temperature from the thermal zones and displays them in a user-friendly format.
# It sleeps for a specified interval and repeats the process.

# Usage: ./thermal_monitor.sh [interval] [thermal_zone_path_prefix]
# Example: ./thermal_monitor.sh 5 /sys/class/thermal/thermal_zone
# If no arguments are provided, it defaults to an interval of 1 second and a path prefix of /sys/class/thermal/thermal_zone.

# Default values
INTERVAL=1
THERMAL_ZONE_PREFIX="/sys/class/thermal/thermal_zone"

# Check if arguments are provided
if [ $# -ge 1 ]; then
  INTERVAL=$1
fi

if [ $# -ge 2 ]; then
  THERMAL_ZONE_PREFIX=$2
fi

# Function to read the temperature from a thermal zone
get_temperature() {
  local zone=$1
  local temp_file="${THERMAL_ZONE_PREFIX}${zone}/temp"

  if [ -f "$temp_file" ]; then
    local temp=$(cat "$temp_file")
    # Convert temperature from milli-degrees Celsius to degrees Celsius
    echo "$((temp / 1000))"
  else
    echo "N/A"
  fi
}

# Function to get the thermal zone type
get_thermal_zone_type() {
  local zone=$1
  local type_file="${THERMAL_ZONE_PREFIX}${zone}/type"

  if [ -f "$type_file" ]; then
    cat "$type_file"
  else
    echo "Unknown"
  fi
}

# Main loop
while true; do
  clear
  echo "Thermal Zone Temperatures:"
  echo "-------------------------"

  # Find all thermal zones
  zones=($(ls ${THERMAL_ZONE_PREFIX}))

  # Iterate over each thermal zone
  for zone in "${zones[@]}"; do
    if [[ "$zone" =~ ^[0-9]+$ ]]; then # Check if the zone name is a number
      temperature=$(get_temperature "$zone")
      zone_type=$(get_thermal_zone_type "$zone")

      if [ "$temperature" != "N/A" ]; then
        echo "Zone ${zone}: Type: ${zone_type}, Temperature: ${temperature}°C"
      else
        echo "Zone ${zone}: Type: ${zone_type}, Temperature: N/A"
      fi
    fi
  done

  sleep "$INTERVAL"
done
```