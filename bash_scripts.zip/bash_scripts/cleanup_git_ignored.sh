# This script cleans up a Git repository by:
# 1. Performing a dry run to show what would be removed.
# 2. Removing ignored files and directories, including those in subdirectories.
# 3. Removing empty directories.

# Perform a dry run of git clean
echo "Dry run: Showing files/directories that would be removed:"
git clean -fdn -X

# Ask for confirmation before proceeding with actual deletion
read -p "Proceed with removing ignored files and directories? (y/n): " confirm

if [[ "$confirm" == "y" ]]; then
  echo "Removing ignored files and directories..."
  git clean -fdX

  echo "Removing empty directories..."
  find . -type d -empty -print0 | xargs -0 rmdir 2>/dev/null

  echo "Cleanup complete."
else
  echo "Aborted."
fi
```