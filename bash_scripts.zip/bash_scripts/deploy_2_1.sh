# This script automates the deployment of a simple Flask application.
# It copies the application files from the user's home directory to /opt/flask_app
# and then starts the application in the background using python.

# Define source and destination directories
SOURCE_DIR="$HOME/my_flask_app"
DEST_DIR="/opt/flask_app"

# Check if the source directory exists
if [ ! -d "$SOURCE_DIR" ]; then
  echo "Error: Source directory '$SOURCE_DIR' does not exist."
  exit 1
fi

# Create the destination directory if it doesn't exist
if [ ! -d "$DEST_DIR" ]; then
  sudo mkdir -p "$DEST_DIR"
  sudo chown "$USER:$USER" "$DEST_DIR" #give current user ownership
fi

# Copy the application files to the destination directory
echo "Copying files from '$SOURCE_DIR' to '$DEST_DIR'..."
cp -r "$SOURCE_DIR"/* "$DEST_DIR"/

# Start the Flask application in the background
echo "Starting the Flask application..."
cd "$DEST_DIR"
nohup python app.py > app.log 2>&1 &

echo "Flask application deployed and running in the background."
```