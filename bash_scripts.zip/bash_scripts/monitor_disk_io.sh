# This script monitors the system's block device I/O statistics per device
# It uses 'iostat' to gather the I/O statistics and displays them in a user-friendly format.
# It includes error handling for cases where iostat is not available.
# The script outputs the Device: tps, kB_read/s, kB_wrtn/s, kB_dscd/s, kB_read, kB_wrtn, kB_dscd

# Check if iostat is installed
if ! command -v iostat &> /dev/null
then
  echo "iostat is not installed. Please install sysstat package."
  exit 1
fi

# Define the interval and count for iostat. Set interval to 1 second
interval=1
count=0 # Run indefinitely

# Function to display the I/O statistics
display_io_stats() {
  iostat -dkx "$interval" "$count" | awk '/^sd[a-z]|nvme/{
    printf "%s: ", $1;
    printf "tps=%.2f, ", $NF;
    printf "kB_read/s=%.2f, ", $11;
    printf "kB_wrtn/s=%.2f, ", $12;
    printf "kB_dscd/s=%.2f, ", $13;
    printf "kB_read=%s, ", $6;
    printf "kB_wrtn=%s, ", $7;
    printf "kB_dscd=%s\n", $8;
  }'
}

# Main loop to continuously monitor I/O statistics
while true; do
  clear
  echo "Monitoring disk I/O statistics..."
  display_io_stats
  sleep "$interval"
done
```