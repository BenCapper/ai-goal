# This script automates the setup and management of a basic NFS share with encryption.
# It covers:
# 1. Installing necessary packages (NFS server, OpenSSL).
# 2. Generating an encryption key.
# 3. Creating the shared directory.
# 4. Configuring NFS export settings with encryption options.
# 5. Starting and enabling the NFS server.
# 6. Setting up a client-side mount point (example).
# 7. Providing instructions on how to securely transfer the encryption key to the client.
# 8. Configuring the client to use the key for mounting the share.

# Set variables
SHARE_DIR="/mnt/nfs_share"
CLIENT_IP="192.168.1.100" # Replace with your client IP
KEY_FILE="/etc/nfs_encryption.key"

# Update package lists
sudo apt update

# Install NFS server and OpenSSL
sudo apt install -y nfs-kernel-server openssl

# Generate encryption key
echo "Generating encryption key..."
openssl rand -base64 32 > $KEY_FILE
chmod 400 $KEY_FILE # Secure the key file

# Create shared directory
echo "Creating shared directory..."
sudo mkdir -p $SHARE_DIR
sudo chown nobody:nogroup $SHARE_DIR
sudo chmod 777 $SHARE_DIR # Adjust permissions as needed. This is permissive!

# Configure NFS export settings
echo "Configuring NFS export..."
echo "$SHARE_DIR  $CLIENT_IP(rw,sync,no_subtree_check,no_root_squash,sec=krb5p)" | sudo tee -a /etc/exports

# Start and enable NFS server
echo "Starting and enabling NFS server..."
sudo systemctl enable --now nfs-kernel-server

# Show key location and emphasize secure transfer
echo "NFS share setup complete."
echo "The encryption key is located at: $KEY_FILE"
echo "IMPORTANT:  Securely transfer this key to the client using a secure method like scp/sftp/etc.  DO NOT email it or use an insecure method."
echo "Example secure key transfer: scp $KEY_FILE user@$CLIENT_IP:/path/to/client/key"

# Example Client-Side Setup (Informational - Requires Client-Side Execution)
echo ""
echo "Client-Side Setup (Run on the client machine):"
echo "# 1. Install nfs-common: sudo apt update && sudo apt install -y nfs-common"
echo "# 2. Create a mount point: sudo mkdir -p /mnt/nfs_client"
echo "# 3. Securely copy the key to the client (e.g., /etc/nfs_client.key).  Set permissions: chmod 400 /etc/nfs_client.key"
echo "# 4. Mount the NFS share (replace <server_ip> with your server's IP):"
echo "#    sudo mount -t nfs -o sec=krb5p,nfsvers=4.2,key=/etc/nfs_client.key <server_ip>:$SHARE_DIR /mnt/nfs_client"
echo "#    (You might need to configure Kerberos on both server and client if krb5p fails. Consider using 'sec=sys' if encryption isn't mandatory.)"
echo ""
echo "Don't forget to adjust permissions as needed and consider using more restrictive options for production environments."

```