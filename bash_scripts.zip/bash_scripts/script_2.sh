```bash
#!/bin/bash

# This script plays a sound using aplay.
# It requires a sound file and the aplay utility.
# It checks if the sound file exists before attempting to play it.

SOUND_FILE="/usr/share/sounds/alsa/Front_Center.wav" # Replace with your sound file

if [ -f "$SOUND_FILE" ]; then
  aplay "$SOUND_FILE"
else
  echo "Error: Sound file not found: $SOUND_FILE"
  exit 1
fi

exit 0
```