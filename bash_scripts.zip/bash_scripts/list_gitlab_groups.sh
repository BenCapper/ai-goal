# This script retrieves a list of all groups from a GitLab instance using the GitLab API.
# It requires a personal access token with read access to the API.

# Usage: ./list_gitlab_groups.sh <GITLAB_URL> <PRIVATE_TOKEN>

# Set variables from command line arguments
GITLAB_URL=$1
PRIVATE_TOKEN=$2

# Check if the required parameters are provided
if [ -z "$GITLAB_URL" ] || [ -z "$PRIVATE_TOKEN" ]; then
  echo "Usage: ./list_gitlab_groups.sh <GITLAB_URL> <PRIVATE_TOKEN>"
  exit 1
fi

# API endpoint for listing groups
API_ENDPOINT="$GITLAB_URL/api/v4/groups"

# Function to handle API requests and error checking
get_gitlab_data() {
  local url="$1"
  curl --header "PRIVATE-TOKEN: $PRIVATE_TOKEN" "$url"
}

# Get the initial list of groups
response=$(get_gitlab_data "$API_ENDPOINT")

# Check for errors in the response
if [[ "$response" == *"error"* ]]; then
  echo "Error retrieving groups: $response"
  exit 1
fi

# Parse the JSON response using jq and print the group names
echo "$response" | jq -r '.[].name'

# Handle pagination to get all groups (if the initial response is truncated)
while true; do
  # Extract the 'next' page link from the response headers
  next_page_link=$(echo "$response" | jq -r '.[].@next' 2>/dev/null) #jq: error (at <stdin>:1): Cannot index array with string "@next"
  #Check to see if the headers have been provided
  if [ -z "$next_page_link" ] || [ "$next_page_link" == "null" ]; then
    break # No more pages
  fi

  # Get the next page of groups
  response=$(get_gitlab_data "$next_page_link")

  # Check for errors in the response
  if [[ "$response" == *"error"* ]]; then
    echo "Error retrieving groups: $response"
    exit 1
  fi

  # Parse the JSON response and print the group names
  echo "$response" | jq -r '.[].name'
done

# exit 0
# ./list_gitlab_groups.sh <GITLAB_URL> <PRIVATE_TOKEN>
```