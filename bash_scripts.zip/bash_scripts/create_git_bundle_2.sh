#
# This script automates the creation of a Git bundle containing a specified range of commits.
# It takes two commit identifiers as arguments: the starting commit and the ending commit.
# The script will create a bundle file containing all commits reachable from the ending commit
# but not reachable from the starting commit.
#
# Usage: ./create_git_bundle.sh <start_commit> <end_commit> <bundle_filename>

# Check if the correct number of arguments is provided
if [ $# -ne 3 ]; then
  echo "Usage: ./create_git_bundle.sh <start_commit> <end_commit> <bundle_filename>"
  exit 1
fi

# Assign arguments to variables
start_commit="$1"
end_commit="$2"
bundle_filename="$3"

# Check if the commits exist
if ! git rev-parse --quiet --verify "$start_commit" > /dev/null 2>&1; then
  echo "Error: Start commit '$start_commit' does not exist."
  exit 1
fi

if ! git rev-parse --quiet --verify "$end_commit" > /dev/null 2>&1; then
  echo "Error: End commit '$end_commit' does not exist."
  exit 1
fi

# Create the Git bundle
git bundle create "$bundle_filename" "$start_commit..$end_commit"

# Check if the bundle creation was successful
if [ $? -eq 0 ]; then
  echo "Git bundle '$bundle_filename' created successfully."
else
  echo "Error: Failed to create Git bundle '$bundle_filename'."
  exit 1
fi

exit 0

# Example Usage:
# ./create_git_bundle.sh commit1 commit2 my_bundle.bundle
```