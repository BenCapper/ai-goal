# This script automates the setup and management of a basic IP-in-IP tunnel with a specified TTL.
# It allows you to create, destroy, and check the status of the tunnel.

# Usage: ./ipip_tunnel.sh <action> <local_ip> <remote_ip> <tunnel_name> <ttl>
#        where:
#          <action>      : create | destroy | status
#          <local_ip>    : Local IP address of the tunnel endpoint.
#          <remote_ip>   : Remote IP address of the tunnel endpoint.
#          <tunnel_name> : Name of the tunnel interface (e.g., tun1).
#          <ttl>         : Time-To-Live value for the tunnel.

# Check if the user is root
if [[ $EUID -ne 0 ]]; then
  echo "This script must be run as root."
  exit 1
fi

# Function to create the tunnel
create_tunnel() {
  local local_ip=$2
  local remote_ip=$3
  local tunnel_name=$4
  local ttl=$5

  echo "Creating tunnel $tunnel_name..."

  # Create the tunnel interface
  ip tunnel add $tunnel_name mode ipip local $local_ip remote $remote_ip ttl $ttl

  # Bring up the tunnel interface
  ip link set $tunnel_name up

  echo "Tunnel $tunnel_name created successfully."
}

# Function to destroy the tunnel
destroy_tunnel() {
  local tunnel_name=$4

  echo "Destroying tunnel $tunnel_name..."

  # Destroy the tunnel interface
  ip link delete $tunnel_name

  echo "Tunnel $tunnel_name destroyed successfully."
}

# Function to check the tunnel status
check_tunnel_status() {
  local tunnel_name=$4

  echo "Checking status of tunnel $tunnel_name..."

  # Check if the tunnel interface exists
  ip link show $tunnel_name > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    echo "Tunnel $tunnel_name exists."
    ip addr show $tunnel_name
  else
    echo "Tunnel $tunnel_name does not exist."
  fi
}

# Main script logic
case "$1" in
  create)
    if [ -z "$2" ] || [ -z "$3" ] || [ -z "$4" ] || [ -z "$5" ]; then
      echo "Usage: ./ipip_tunnel.sh create <local_ip> <remote_ip> <tunnel_name> <ttl>"
      exit 1
    fi
    create_tunnel "$@"
    ;;
  destroy)
    if [ -z "$4" ]; then
      echo "Usage: ./ipip_tunnel.sh destroy <local_ip> <remote_ip> <tunnel_name> <ttl>"
      exit 1
    fi
    destroy_tunnel "$@"
    ;;
  status)
    if [ -z "$4" ]; then
      echo "Usage: ./ipip_tunnel.sh status <local_ip> <remote_ip> <tunnel_name> <ttl>"
      exit 1
    fi
    check_tunnel_status "$@"
    ;;
  *)
    echo "Usage: ./ipip_tunnel.sh <action> <local_ip> <remote_ip> <tunnel_name> <ttl>"
    echo "  where <action> is create, destroy, or status"
    exit 1
    ;;
esac

exit 0
```