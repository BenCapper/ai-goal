# This script monitors network interface errors and logs them to a file.
# It checks for dropped packets, errors, and collisions on a specified interface.
# It logs the timestamp and error statistics to a log file.
# The script can be configured to run periodically using cron.
#
# usage: ./monitor_network_errors.sh <interface> <log_file> <interval_seconds>

INTERFACE="$1"
LOG_FILE="$2"
INTERVAL="$3"

if [ -z "$INTERFACE" ] || [ -z "$LOG_FILE" ] || [ -z "$INTERVAL" ]; then
  echo "Usage: ./monitor_network_errors.sh <interface> <log_file> <interval_seconds>"
  exit 1
fi

if ! ip link show "$INTERFACE" > /dev/null 2>&1; then
    echo "Error: Interface '$INTERFACE' not found."
    exit 1
fi


while true; do
  TIMESTAMP=$(date +%Y-%m-%d_%H:%M:%S)

  # Get interface statistics
  STATS=$(ip -s link show "$INTERFACE")

  # Extract relevant statistics
  RX_ERRORS=$(echo "$STATS" | grep "RX errors" | awk '{print $3}')
  TX_ERRORS=$(echo "$STATS" | grep "TX errors" | awk '{print $3}')
  RX_DROPPED=$(echo "$STATS" | grep "RX dropped" | awk '{print $5}')
  TX_DROPPED=$(echo "$STATS" | grep "TX dropped" | awk '{print $5}')
  COLLISIONS=$(echo "$STATS" | grep "collisions" | awk '{print $2}')


  # Log the statistics to the log file
  echo "$TIMESTAMP - Interface: $INTERFACE, RX errors: $RX_ERRORS, TX errors: $TX_ERRORS, RX dropped: $RX_DROPPED, TX dropped: $TX_DROPPED, Collisions: $COLLISIONS" >> "$LOG_FILE"

  # Wait for the specified interval
  sleep "$INTERVAL"
done

# crontab -e
# * * * * * /path/to/monitor_network_errors.sh eth0 /var/log/network_errors.log 60
```