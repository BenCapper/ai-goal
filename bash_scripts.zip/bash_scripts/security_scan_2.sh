# This script performs a basic security scan of a remote host using nmap's NSE scripts.
# It checks for common vulnerabilities, such as weak SSH ciphers, SSL/TLS vulnerabilities, and other common issues.
# The script requires nmap to be installed.
# The target host IP address or hostname must be provided as a command-line argument.

# Check if the target host is provided
if [ -z "$1" ]; then
  echo "Usage: $0 <target_host>"
  exit 1
fi

TARGET_HOST="$1"

# Update Nmap script database. This can be slow.
# echo "Updating Nmap script database..."
# nmap --script-updatedb

# Run common vulnerability checks
echo "Starting vulnerability scan of $TARGET_HOST..."

nmap -sV --script vuln $TARGET_HOST

echo "Scan complete."

# Example of specific SSH check (disabled due to redundancy as the 'vuln' script already includes it)
# echo "Checking SSH for weak ciphers..."
# nmap -p 22 --script ssh2-enum-algos $TARGET_HOST

# Example of SSL/TLS check (disabled due to redundancy as the 'vuln' script already includes it)
# echo "Checking SSL/TLS vulnerabilities..."
# nmap -p 443 --script ssl-enum-ciphers $TARGET_HOST
```