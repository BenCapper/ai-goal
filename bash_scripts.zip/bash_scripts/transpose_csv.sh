# This script reads a CSV file and transposes the rows and columns.
# It uses awk to split the lines into fields and rearrange them.

# Usage: ./transpose_csv.sh input.csv > output.csv

# Check if an input file is provided.
if [ -z "$1" ]; then
  echo "Usage: $0 input.csv > output.csv"
  exit 1
fi

# Transpose the CSV file using awk.
awk '
{
  # Read the first line to determine the number of columns.
  if (NR == 1) {
    num_cols = split($0, header, ",")
  }
  
  # Store each field in a temporary array.
  for (i = 1; i <= num_cols; i++) {
    fields[i, NR] = $i;
  }
}

END {
  # Iterate through the columns and print each row.
  for (i = 1; i <= num_cols; i++) {
    for (j = 1; j <= NR; j++) {
      printf "%s", fields[i, j];
      if (j < NR) {
        printf ",";
      }
    }
    printf "\n";
  }
}
' "$1"
```