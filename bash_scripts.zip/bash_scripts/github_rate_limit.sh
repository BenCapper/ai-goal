# This script uses curl to fetch the rate limits for the authenticated user on GitHub's API
# and uses jq to display the remaining requests.

# Set your GitHub token as an environment variable:
# export GITHUB_TOKEN="YOUR_GITHUB_TOKEN"

# Check if the GITHUB_TOKEN environment variable is set
if [ -z "$GITHUB_TOKEN" ]; then
  echo "Error: GITHUB_TOKEN environment variable not set."
  echo "Please set it before running this script."
  exit 1
fi

# Fetch the rate limits using curl
rate_limit_json=$(curl -s -H "Authorization: token $GITHUB_TOKEN" https://api.github.com/rate_limit)

# Extract the remaining requests using jq
remaining_requests=$(echo "$rate_limit_json" | jq '.resources.core.remaining')

# Display the remaining requests
echo "Remaining requests: $remaining_requests"
```