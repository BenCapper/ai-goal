# This script upgrades all installed packages on a Debian/Ubuntu system using apt.
# It first updates the package lists and then upgrades the packages.
# It also handles any potential errors during the upgrade process.

# Update the package lists
apt update

# Check if the update command was successful
if [ $? -ne 0 ]; then
  echo "Error: Failed to update package lists."
  exit 1
fi

# Upgrade the installed packages
apt upgrade -y

# Check if the upgrade command was successful
if [ $? -ne 0 ]; then
  echo "Error: Failed to upgrade packages."
  exit 1
fi

# Clean up obsolete packages
apt autoremove -y

# Check if the autoremove command was successful
if [ $? -ne 0 ]; then
  echo "Error: Failed to autoremove obsolete packages."
  exit 1
fi

echo "Package upgrade complete."

exit 0
```