# This script finds inactive (DOWN) network interfaces that are not loopback interfaces.
# It uses the 'ip' command to list interfaces, filters for DOWN and non-loopback interfaces,
# and then extracts the interface names using awk.

# ip -c -br addr show: Shows network interfaces in a brief format with color.
# grep -v UP: Filters out interfaces that are UP.
# grep -v LOOPBACK: Filters out loopback interfaces.
# awk '{print $1}': Prints the first field (interface name).

# Usage: ./find_inactive_interfaces.sh
ip -c -br addr show | grep -v UP | grep -v LOOPBACK | awk '{print $1}'
```