# This script sets up a basic Intrusion Prevention System (IPS) using iptables
# and automatically blocks malicious traffic based on simple rules.

# Usage: ./basic_ips.sh

# Define variables
LOG_FILE="/var/log/ips.log"
IPTABLES="/sbin/iptables"
ALLOWED_PORTS="22,80,443"  # SSH, HTTP, HTTPS

# Function to log events
log_event() {
  echo "$(date) - $1" >> "$LOG_FILE"
}

# Function to block an IP address
block_ip() {
  IP_ADDRESS="$1"
  if [[ -n "$IP_ADDRESS" ]]; then
    $IPTABLES -A INPUT -s "$IP_ADDRESS" -j DROP
    $IPTABLES -A FORWARD -s "$IP_ADDRESS" -j DROP
    log_event "Blocked IP address: $IP_ADDRESS"
    echo "Blocked IP address: $IP_ADDRESS"
  fi
}

# Function to unblock an IP address
unblock_ip() {
  IP_ADDRESS="$1"
  if [[ -n "$IP_ADDRESS" ]]; then
    $IPTABLES -D INPUT -s "$IP_ADDRESS" -j DROP
    $IPTABLES -D FORWARD -s "$IP_ADDRESS" -j DROP
    log_event "Unblocked IP address: $IP_ADDRESS"
    echo "Unblocked IP address: $IP_ADDRESS"
  fi
}

# Function to set up basic firewall rules
setup_firewall() {
  echo "Setting up basic firewall rules..."
  # Set default policies
  $IPTABLES -P INPUT DROP
  $IPTABLES -P FORWARD DROP
  $IPTABLES -P OUTPUT ACCEPT

  # Allow established and related connections
  $IPTABLES -A INPUT -m state --state RELATED,ESTABLISHED -j ACCEPT
  $IPTABLES -A FORWARD -m state --state RELATED,ESTABLISHED -j ACCEPT

  # Allow loopback traffic
  $IPTABLES -A INPUT -i lo -j ACCEPT
  $IPTABLES -A OUTPUT -o lo -j ACCEPT

  # Allow specific ports
  for port in $(echo $ALLOWED_PORTS | tr "," " "); do
    $IPTABLES -A INPUT -p tcp --dport "$port" -j ACCEPT
    $IPTABLES -A INPUT -p udp --dport "$port" -j ACCEPT
  done

  # Example rule: Block SYN flood attacks (adapt to your needs)
  $IPTABLES -A INPUT -p tcp --syn -m limit --limit 1/s --limit-burst 1 -j ACCEPT
  $IPTABLES -A INPUT -p tcp --syn -j DROP
  echo "Firewall rules set up."
}

# Example function to detect and block suspicious activity (modify to suit your needs)
detect_and_block() {
  echo "Detecting and blocking suspicious activity (example)..."
  # This is a placeholder - implement your actual detection logic here
  # For example, analyze logs for failed login attempts, port scans, etc.

  # Example: Simulate detection and blocking of an IP
  SUSPICIOUS_IP="192.168.1.100"
  block_ip "$SUSPICIOUS_IP"
  echo "Finished detecting and blocking (example)."
}

# Main script execution
echo "Starting basic IPS setup..."

# Setup firewall
setup_firewall

# Detect and block suspicious activity
detect_and_block

echo "Basic IPS setup complete."

# Example usage of unblock_ip (e.g., after investigation)
# unblock_ip "192.168.1.100"

#To use this script, make it executable and run it:
#chmod +x basic_ips.sh
#./basic_ips.sh
```