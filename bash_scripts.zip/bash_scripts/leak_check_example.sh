# This script demonstrates how to use Valgrind's --leak-check option
# to detect memory leaks in a C program.

# First, we compile a simple C program that has a memory leak.
# The C program allocates memory but never frees it.
cat <<EOF > leak.c
#include <stdio.h>
#include <stdlib.h>

int main() {
  int *ptr = (int *)malloc(sizeof(int));
  *ptr = 10;
  // Memory allocated to ptr is never freed, creating a leak.
  return 0;
}
EOF

gcc -g -o leak leak.c

# Now, we run the compiled program using Valgrind with the --leak-check=full option.
# This option instructs Valgrind to perform a detailed memory leak analysis.
valgrind --leak-check=full ./leak

# To clean up the compiled executable, uncomment the following line to remove the file.
# rm leak

# Usage: ./leak_check_example.sh
```