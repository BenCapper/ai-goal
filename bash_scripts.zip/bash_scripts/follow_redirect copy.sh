# This script uses curl to interact with an API that returns a 307 Temporary Redirect response and follows the redirect with the original method and body.
# It limits the number of redirects and logs the redirect chain and the status code at each step.

# Set the initial URL
URL=$1

# Set the maximum number of redirects to follow
MAX_REDIRECTS=5

# Initialize an empty array to store the redirect chain
REDIRECT_CHAIN=()

# Function to follow redirects and log the chain
follow_redirects() {
  local url="$1"
  local method="$2"
  local data="$3"
  local redirects=0

  while true; do
    # Check if the maximum number of redirects has been reached
    if [[ $redirects -ge $MAX_REDIRECTS ]]; then
      echo "Maximum number of redirects ($MAX_REDIRECTS) reached. Exiting."
      exit 1
    fi

    # Make the curl request, capturing the response headers
    response=$(curl -s -w "%{http_code}\n%{redirect_url}" \
                  -X "$method" \
                  -d "$data" \
                  "$url" )

    # Extract the HTTP status code
    status_code=$(echo "$response" | head -n 1)

    # Extract the redirect URL (if any)
    redirect_url=$(echo "$response" | tail -n 1)

    # Add the current URL and status code to the redirect chain
    REDIRECT_CHAIN+=("$url ($status_code)")

    # Check the status code
    if [[ "$status_code" == "307" ]]; then
      # Follow the redirect if the status code is 307
      url="$redirect_url"
      redirects=$((redirects + 1))
      echo "Redirecting to: $url"
    else
      # Break out of the loop if the status code is not 307
      break
    fi
  done

  # Print the final URL and status code
  REDIRECT_CHAIN+=("$url ($status_code)")
  echo "Final URL: $url"
  echo "Final Status Code: $status_code"
}

# Set the request method (e.g., POST, GET, PUT, DELETE)
METHOD="POST" # Change to GET if the API requires GET

# Set the request body (if any)
DATA='{"key": "value"}' # Example data

# Follow the redirects and log the chain
follow_redirects "$URL" "$METHOD" "$DATA"

# Print the redirect chain
echo "Redirect Chain:"
for item in "${REDIRECT_CHAIN[@]}"; do
  echo "$item"
done
```