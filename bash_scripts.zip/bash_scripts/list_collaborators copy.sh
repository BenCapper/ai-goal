# This script uses curl to fetch the list of collaborators for a GitHub repository
# and uses jq to list their usernames.

# Set the GitHub repository owner and name
OWNER="octocat"
REPO="Spoon-Knife"

# Set the GitHub API endpoint
API_ENDPOINT="https://api.github.com/repos/$OWNER/$REPO/collaborators"

# Fetch the list of collaborators using curl
# -s: silent mode (suppress progress meter and error messages)
# -H: add a header to the request (Authorization for authentication if needed)
# -H: add a header to specify the Accept type (JSON)
# -u: username:password (for authentication if needed; consider using a personal access token)
# Note: Replace YOUR_USERNAME and YOUR_TOKEN with your GitHub username and personal access token for increased rate limits.
COLLABORATORS=$(curl -s -H "Accept: application/vnd.github+json" -H "Authorization: Bearer YOUR_TOKEN" "$API_ENDPOINT")

# Extract the usernames using jq
# .[]: iterate through the array
# .login: extract the 'login' field (which contains the username)
# | @tsv: format the output as tab-separated values
USERNAMES=$(echo "$COLLABORATORS" | jq -r '.[].login | @tsv')

# Print the usernames
echo "$USERNAMES"
```