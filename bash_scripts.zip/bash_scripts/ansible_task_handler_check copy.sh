#
# This script parses an Ansible playbook and lists all tasks, indicating whether they have "changed_when" handlers.
# It iterates through the playbook, identifies tasks, and checks if each task has a corresponding "changed_when" directive.

# Function to parse a single playbook file
parse_playbook() {
  local playbook_file="$1"
  local indent_level=2 # Initial indent level for tasks

  echo "Playbook: $playbook_file"

  # Use yq to parse the YAML and find tasks.  This avoids fragile parsing with grep/sed.
  yq '.. | .tasks // empty | .[] | .name as $name | .changed_when as $changed_when | {name: $name, changed_when: $changed_when}' "$playbook_file" | while IFS= read -r line; do

    if [[ "$line" == *"name:"* ]]; then
      task_name=$(echo "$line" | sed -E 's/^.*name: //g' | sed 's/ //g')
    elif [[ "$line" == *"changed_when:"* ]]; then
      changed_when_value=$(echo "$line" | sed -E 's/^.*changed_when: //g' | sed 's/ //g')

      if [[ -z "$changed_when_value" ]]; then
        echo "  Task: \"$task_name\" - No handlers attached."
      else
        echo "  Task: \"$task_name\" - Handlers attached (changed_when)."
      fi
    fi
  done
  echo ""
}

# Main script logic
if [ $# -eq 0 ]; then
  echo "Usage: $0 <playbook1.yml> [playbook2.yml] ..."
  exit 1
fi

# Iterate through each playbook file provided as an argument
for playbook in "$@"; do
  if [ -f "$playbook" ]; then
    parse_playbook "$playbook"
  else
    echo "Error: Playbook file '$playbook' not found."
  fi
done

exit 0
```