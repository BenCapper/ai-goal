# This script generates a random linked list coding challenge for daily practice.
# The challenge will be about common linked list operations.

# Function to choose a random challenge
choose_challenge() {
  local challenges=(
    "Implement a function to reverse a singly linked list."
    "Implement a function to detect if a linked list has a cycle."
    "Implement a function to find the middle element of a linked list."
    "Implement a function to merge two sorted linked lists."
    "Implement a function to remove the nth node from the end of a linked list."
    "Implement a function to check if a linked list is a palindrome."
    "Implement a function to find the intersection point of two linked lists."
  )

  local num_challenges=${#challenges[@]}
  local random_index=$((RANDOM % num_challenges))
  echo "${challenges[$random_index]}"
}

# Generate the daily challenge
generate_challenge() {
  local challenge=$(choose_challenge)
  echo "Daily Linked List Challenge:"
  echo "---------------------------"
  echo "$challenge"
  echo "---------------------------"
  echo "Good luck!"
}

# Main execution
generate_challenge
```