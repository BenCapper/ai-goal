#
# This script interacts with the GitLab API to list all project members
# with their access level for a given project.
#
# Requires:
#   - jq (for parsing JSON responses)
#   - GitLab API token with appropriate permissions (e.g., read_api)
#
# Usage: ./gitlab_project_members.sh <gitlab_url> <project_id> <private_token>

# Set variables
GITLAB_URL="$1"
PROJECT_ID="$2"
PRIVATE_TOKEN="$3"

# Check if required arguments are provided
if [ -z "$GITLAB_URL" ] || [ -z "$PROJECT_ID" ] || [ -z "$PRIVATE_TOKEN" ]; then
  echo "Usage: ./gitlab_project_members.sh <gitlab_url> <project_id> <private_token>"
  exit 1
fi

# Function to get the access level string from the numeric access level value
get_access_level_string() {
  case "$1" in
    10) echo "Guest";;
    20) echo "Reporter";;
    30) echo "Developer";;
    40) echo "Maintainer";;
    50) echo "Owner";;
    *) echo "Unknown";;
  esac
}

# API endpoint to list project members
API_ENDPOINT="$GITLAB_URL/api/v4/projects/$PROJECT_ID/members/all"

# Fetch project members using the GitLab API
response=$(curl --header "PRIVATE-TOKEN: $PRIVATE_TOKEN" "$API_ENDPOINT")

# Check if the API request was successful
if [[ $(echo "$response" | jq -r ".message") != "null" ]]; then
  echo "Error: $(echo "$response" | jq -r ".message")"
  exit 1
fi

# Parse the JSON response and print the member information
echo "$response" | jq -r '.[] | "\(.username) - \(.name) - Access Level: \(.access_level | tostring) (\( .access_level | tonumber | get_access_level_string ))"'

# file usage: ./gitlab_project_members.sh <gitlab_url> <project_id> <private_token>
```