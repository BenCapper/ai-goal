# This script unlocks a user account in Linux by removing the lock from the /etc/shadow file.
# It requires root privileges (sudo) to modify the shadow file.

# Check if a username is provided as an argument.
if [ -z "$1" ]; then
  echo "Usage: sudo ./unlock_user.sh <username>"
  exit 1
fi

# The username to unlock.
USERNAME="$1"

# Use usermod to unlock the user account.
sudo usermod -U "$USERNAME"

# Check the exit status of the usermod command
if [ $? -eq 0 ]; then
  echo "User $USERNAME has been unlocked."
else
  echo "Failed to unlock user $USERNAME."
  exit 1
fi

exit 0

# Usage: sudo ./unlock_user.sh <username>
```