# This script automates the process of backing up all MySQL databases on a server.
# It uses mysqldump to create a separate dump file for each database.
# It assumes you have the necessary MySQL client tools installed and configured.

# Usage: ./backup_mysql_databases.sh <mysql_user> <mysql_password> <backup_directory>

# Set variables
MYSQL_USER=$1
MYSQL_PASSWORD=$2
BACKUP_DIR=$3
DATE=$(date +%Y%m%d_%H%M%S)

# Check if required arguments are provided
if [ -z "$MYSQL_USER" ] || [ -z "$MYSQL_PASSWORD" ] || [ -z "$BACKUP_DIR" ]; then
  echo "Error: Missing required arguments."
  echo "Usage: ./backup_mysql_databases.sh <mysql_user> <mysql_password> <backup_directory>"
  exit 1
fi

# Create backup directory if it doesn't exist
if [ ! -d "$BACKUP_DIR" ]; then
  mkdir -p "$BACKUP_DIR"
fi

# Get list of databases
DATABASES=$(mysql -u "$MYSQL_USER" -p"$MYSQL_PASSWORD" -e "SHOW DATABASES;" | grep -v "Database" | grep -v "information_schema" | grep -v "performance_schema" | grep -v "mysql" | grep -v "sys")

# Loop through each database and create a backup
for DB in $DATABASES; do
  BACKUP_FILE="$BACKUP_DIR/${DB}_${DATE}.sql"
  echo "Backing up database: $DB to $BACKUP_FILE"
  mysqldump -u "$MYSQL_USER" -p"$MYSQL_PASSWORD" --databases "$DB" > "$BACKUP_FILE"
  if [ $? -eq 0 ]; then
    echo "Successfully backed up database: $DB"
  else
    echo "Error backing up database: $DB"
  fi
done

echo "Backup process completed."
```