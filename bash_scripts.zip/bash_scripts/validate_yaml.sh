# This script reads a YAML file stored in a variable,
# iterates through the lines, extracts values using yq,
# and checks if the extracted values match expected values using an if statement.

YAML_CONTENT="
users:
  - name: Alice
    age: 30
    city: New York
  - name: Bob
    age: 25
    city: London
  - name: Charlie
    age: 35
    city: Paris
"

# Iterate through the users in the YAML content.
for i in $(seq 0 $(yq e '.users | length - 1' <<< "$YAML_CONTENT")); do
  # Extract the name of the user.
  name=$(yq e ".users[$i].name" <<< "$YAML_CONTENT")

  # Extract the age of the user.
  age=$(yq e ".users[$i].age" <<< "$YAML_CONTENT")

  # Extract the city of the user.
  city=$(yq e ".users[$i].city" <<< "$YAML_CONTENT")

  # Check if the user's age is greater than 28.
  if [[ "$age" -gt 28 ]]; then
    echo "User $name from $city is older than 28."
  fi

  # Check if the user's city is New York.
  if [[ "$city" == "New York" ]]; then
    echo "User $name lives in New York."
  fi
done

# Usage: ./validate_yaml.sh
```