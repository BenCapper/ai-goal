#
# This script analyzes web server logs (e.g., Apache or Nginx)
# and generates a timeline showing website traffic patterns
# hour by hour, highlighting peak usage times and potential
# anomalies.  It assumes a common log format with date/time in the
# format "DD/MMM/YYYY:HH:MM:SS".  Adjust the date/time extraction
# if your log format is different.

# Usage: ./analyze_logs.sh access.log

# Input log file (passed as an argument)
LOG_FILE="$1"

# Check if log file exists
if [ ! -f "$LOG_FILE" ]; then
  echo "Error: Log file '$LOG_FILE' not found."
  exit 1
fi

# Function to extract the hour from the log line
extract_hour() {
  awk '{print substr($4, 14, 2)}'
}

# Function to calculate and display the hourly traffic
analyze_traffic() {
  # Create an associative array to store hourly counts
  declare -A hourly_counts

  # Extract the hour from each log entry and increment the count
  while IFS= read -r line; do
    hour=$($extract_hour <<< "$line")
    hourly_counts[$hour]=$((hourly_counts[$hour]+1))
  done < "$LOG_FILE"

  # Find the maximum traffic count for scaling the graph
  max_traffic=0
  for hour in "${!hourly_counts[@]}"; do
    if [ "${hourly_counts[$hour]}" -gt "$max_traffic" ]; then
      max_traffic="${hourly_counts[$hour]}"
    fi
  done

  # Set a scaling factor for the histogram (adjust for terminal width)
  scale_factor=$(echo "scale=2; 50 / $max_traffic" | bc)

  # Display the hourly traffic in a timeline format
  echo "Hourly Traffic Timeline:"
  echo "-------------------------"

  for hour in $(seq 0 23); do
    # Pad the hour with a leading zero if needed
    hour_padded=$(printf "%02d" "$hour")

    # Get the traffic count for the hour
    traffic_count=${hourly_counts[$hour_padded]:-0}

    # Calculate the number of bars to display
    num_bars=$(echo "$traffic_count * $scale_factor" | bc | awk '{print int($1)}')

    # Generate the bar string
    bar_string=""
    for i in $(seq 1 "$num_bars"); do
      bar_string+="|"
    done

    #Highlight Peak Usage - more than 80% of max
    peak_threshold=$((max_traffic * 8 / 10))

    if [ "$traffic_count" -ge "$peak_threshold" ] && [ "$max_traffic" -gt 0 ]; then
      color_start="\e[1;31m" # Bold Red
      color_end="\e[0m" # Reset
    else
      color_start=""
      color_end=""
    fi

    # Display the hour and the traffic count
    printf "%s%02d:00 - %02d:59: %5d %s%s\n" "$color_start" "$hour" "$hour" "$traffic_count" "$bar_string" "$color_end"
  done
  echo "-------------------------"

  #Anomaly Detection:  Identify hours with traffic significantly lower than the average.
  #Calculate average traffic

  total_traffic=0
  for hour in "${!hourly_counts[@]}"; do
    total_traffic=$((total_traffic + hourly_counts[$hour]))
  done

  num_hours=${#hourly_counts[@]}

  if [ "$num_hours" -gt 0 ]; then
    average_traffic=$((total_traffic / num_hours))
  else
    average_traffic=0
  fi

  # Identify potential anomalies (hours with significantly lower traffic than average)
  anomaly_threshold=$((average_traffic / 2))  # Adjust this threshold as needed

  echo "Potential Anomalies (Traffic < 50% of Average):"

  anomalies_found=0
  for hour in $(seq 0 23); do
    hour_padded=$(printf "%02d" "$hour")
    traffic_count=${hourly_counts[$hour_padded]:-0}

    if [ "$traffic_count" -lt "$anomaly_threshold" ] && [ "$traffic_count" -gt 0 ]; then
      echo "  $hour_padded:00 - $hour_padded:59: $traffic_count requests"
      anomalies_found=1
    fi
  done
  if [ "$anomalies_found" -eq 0 ]; then
      echo "  None detected"
  fi
}

# Run the analysis
analyze_traffic
```