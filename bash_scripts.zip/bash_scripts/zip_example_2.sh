# This script demonstrates how to use the zip utility with password protection and different compression levels.
# It creates a zip archive, adds files to it, and protects it with a password.
# It also demonstrates different compression levels.

# Create some dummy files
echo "This is file1." > file1.txt
echo "This is file2." > file2.txt
echo "This is file3." > file3.txt

# Set a password for the zip archive
PASSWORD="mysecretpassword"

# Create a zip archive with maximum compression (-9) and password protection
zip -P "$PASSWORD" -9 archive_max.zip file1.txt file2.txt

# Create a zip archive with no compression (-0) and password protection
zip -P "$PASSWORD" -0 archive_none.zip file1.txt file2.txt

# Create a zip archive with default compression and password protection, including file3.txt
zip -P "$PASSWORD" archive_default.zip file1.txt file2.txt file3.txt

# You can then unzip the archive using the following command:
# unzip -P mysecretpassword archive.zip
```