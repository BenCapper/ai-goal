# This script fetches details of a GitLab repository using the API
# and extracts the default branch name.

# Usage: ./get_gitlab_default_branch.sh <gitlab_url> <private_token> <project_id>

# Get GitLab URL, private token, and project ID from command line arguments
GITLAB_URL="$1"
PRIVATE_TOKEN="$2"
PROJECT_ID="$3"

# Check if all required arguments are provided
if [ -z "$GITLAB_URL" ] || [ -z "$PRIVATE_TOKEN" ] || [ -z "$PROJECT_ID" ]; then
  echo "Usage: ./get_gitlab_default_branch.sh <gitlab_url> <private_token> <project_id>"
  exit 1
fi

# Construct the API endpoint URL
API_ENDPOINT="$GITLAB_URL/api/v4/projects/$PROJECT_ID"

# Fetch the repository details using curl
RESPONSE=$(curl --header "PRIVATE-TOKEN: $PRIVATE_TOKEN" "$API_ENDPOINT")

# Check if the curl request was successful
if [ $? -ne 0 ]; then
  echo "Error: Failed to fetch repository details."
  exit 1
fi

# Extract the default branch name using jq
DEFAULT_BRANCH=$(echo "$RESPONSE" | jq -r .default_branch)

# Check if jq is installed and the default branch was successfully extracted
if [ -z "$DEFAULT_BRANCH" ]; then
  echo "Error: Failed to extract default branch. Ensure jq is installed and the project ID is correct."
  exit 1
fi

# Print the default branch name
echo "Default branch: $DEFAULT_BRANCH"

# example usage: ./get_gitlab_default_branch.sh "https://gitlab.example.com" "YOUR_PRIVATE_TOKEN" "12345"
```