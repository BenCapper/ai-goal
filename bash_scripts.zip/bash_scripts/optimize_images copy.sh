# This script takes a directory of image files and optimizes them for web use.
# It uses optipng for PNG files and jpegoptim for JPEG files.
# Make sure you have these tools installed before running the script.

# Usage: ./optimize_images.sh <directory>

# Check if the directory argument is provided
if [ $# -ne 1 ]; then
  echo "Usage: ./optimize_images.sh <directory>"
  exit 1
fi

# Set the directory to optimize
directory="$1"

# Check if the directory exists
if [ ! -d "$directory" ]; then
  echo "Error: Directory '$directory' not found."
  exit 1
fi

# Find all PNG files in the directory and optimize them with optipng
find "$directory" -type f -name "*.png" -print0 | while IFS= read -r -d $'\0' file; do
  echo "Optimizing PNG: $file"
  optipng -o7 "$file"
done

# Find all JPEG files in the directory and optimize them with jpegoptim
find "$directory" -type f -name "*.jpg" -print0 | while IFS= read -r -d $'\0' file; do
  echo "Optimizing JPEG: $file"
  jpegoptim --strip-all "$file"
done

find "$directory" -type f -name "*.jpeg" -print0 | while IFS= read -r -d $'\0' file; do
  echo "Optimizing JPEG: $file"
  jpegoptim --strip-all "$file"
done

echo "Image optimization complete."
```