# This script automates the process of creating and managing encrypted file systems on a RHEL server using LUKS.
# It allows creating an encrypted volume, opening it, creating a filesystem on it, mounting it, and closing it.
#
# Usage: ./luks_manager.sh <device> <mount_point> <action>
#        <device>: The block device to use for LUKS (e.g., /dev/sdb1)
#        <mount_point>: The directory to mount the decrypted volume (e.g., /mnt/encrypted)
#        <action>: create | open | close | mount | unmount

# Check if the script is run as root
if [[ $EUID -ne 0 ]]; then
  echo "This script must be run as root."
  exit 1
fi

# Check if the required arguments are provided
if [[ $# -ne 3 ]]; then
  echo "Usage: ./luks_manager.sh <device> <mount_point> <action>"
  echo "  <device>: The block device to use for LUKS (e.g., /dev/sdb1)"
  echo "  <mount_point>: The directory to mount the decrypted volume (e.g., /mnt/encrypted)"
  echo "  <action>: create | open | close | mount | unmount"
  exit 1
fi

DEVICE="$1"
MOUNT_POINT="$2"
ACTION="$3"
VOLUME_NAME="encrypted_volume"

# Function to create an encrypted volume
create_volume() {
  echo "Creating encrypted volume on $DEVICE..."
  yes | cryptsetup luksFormat "$DEVICE"
  if [[ $? -ne 0 ]]; then
    echo "Error creating encrypted volume."
    exit 1
  fi
  echo "Encrypted volume created successfully."
}

# Function to open the encrypted volume
open_volume() {
  echo "Opening encrypted volume $DEVICE..."
  cryptsetup luksOpen "$DEVICE" "$VOLUME_NAME"
  if [[ $? -ne 0 ]]; then
    echo "Error opening encrypted volume."
    exit 1
  fi
  echo "Encrypted volume opened as /dev/mapper/$VOLUME_NAME."
}

# Function to close the encrypted volume
close_volume() {
  echo "Closing encrypted volume $DEVICE..."
  cryptsetup luksClose "$VOLUME_NAME"
  if [[ $? -ne 0 ]]; then
    echo "Error closing encrypted volume."
    exit 1
  fi
  echo "Encrypted volume closed."
}

# Function to create a filesystem on the decrypted volume
create_filesystem() {
  echo "Creating ext4 filesystem on /dev/mapper/$VOLUME_NAME..."
  mkfs.ext4 "/dev/mapper/$VOLUME_NAME"
  if [[ $? -ne 0 ]]; then
    echo "Error creating filesystem."
    exit 1
  fi
  echo "Filesystem created successfully."
}

# Function to mount the decrypted volume
mount_volume() {
  echo "Mounting /dev/mapper/$VOLUME_NAME to $MOUNT_POINT..."

  # Check if the mount point exists
  if [[ ! -d "$MOUNT_POINT" ]]; then
    echo "Mount point $MOUNT_POINT does not exist. Creating it..."
    mkdir -p "$MOUNT_POINT"
    if [[ $? -ne 0 ]]; then
      echo "Error creating mount point."
      exit 1
    fi
  fi

  mount "/dev/mapper/$VOLUME_NAME" "$MOUNT_POINT"
  if [[ $? -ne 0 ]]; then
    echo "Error mounting volume."
    exit 1
  fi
  echo "Volume mounted successfully."
}

# Function to unmount the decrypted volume
unmount_volume() {
  echo "Unmounting $MOUNT_POINT..."
  umount "$MOUNT_POINT"
  if [[ $? -ne 0 ]]; then
    echo "Error unmounting volume."
    exit 1
  fi
  echo "Volume unmounted successfully."
}

# Main script logic based on the provided action
case "$ACTION" in
  create)
    create_volume
    ;;
  open)
    open_volume
    create_filesystem # Added creation after opening for common workflow
    ;;
  close)
    close_volume
    ;;
  mount)
    mount_volume
    ;;
  unmount)
    unmount_volume
    ;;
  *)
    echo "Invalid action: $ACTION"
    echo "Valid actions are: create, open, close, mount, unmount"
    exit 1
    ;;
esac

exit 0

# Usage: ./luks_manager.sh <device> <mount_point> <action>
```