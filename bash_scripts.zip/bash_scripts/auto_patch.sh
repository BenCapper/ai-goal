# This script automates the process of patching security vulnerabilities on a Linux system.
# It checks for available updates, installs them non-interactively, and reboots the system if necessary.

# Update package lists
apt update

# Upgrade packages, answering 'yes' to all prompts
apt upgrade -y

# Check if a reboot is required
if [ -f /var/run/reboot-required ]; then
  echo "Reboot required after updates. Rebooting now..."
  reboot
else
  echo "No reboot required."
fi

echo "Patching process complete."
```