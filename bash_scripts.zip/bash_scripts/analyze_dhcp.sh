# This script demonstrates how to use Wireshark (tshark)
# from the command line to capture and analyze DHCP traffic.

# First, it captures DHCP packets on the specified interface.
# Then, it filters and displays the DHCP information.

# Usage: sudo ./analyze_dhcp.sh <interface_name>

# Check if the user is root
if [[ $EUID -ne 0 ]]; then
  echo "This script must be run as root."
  exit 1
fi

# Check if an interface is provided as an argument
if [ -z "$1" ]; then
  echo "Please provide the interface name as an argument."
  echo "Usage: sudo ./analyze_dhcp.sh <interface_name>"
  exit 1
fi

INTERFACE=$1
OUTPUT_FILE="dhcp_capture.pcap"

# Capture DHCP traffic using tshark and save it to a pcap file.
# The '-i' option specifies the interface to capture on.
# The '-f' option specifies the capture filter (DHCP).
# The '-w' option specifies the output file to save the captured packets.
echo "Capturing DHCP traffic on interface $INTERFACE for a brief period..."
tshark -i "$INTERFACE" -f "udp port 67 or udp port 68" -w "$OUTPUT_FILE" -c 10 &

# Wait for a few seconds to capture some packets.
sleep 5

# Kill the tshark process if it's still running
kill %1 2>/dev/null

# Now analyze the captured DHCP traffic using tshark.
# The '-r' option specifies the input file (the captured pcap file).
# The '-T fields' option specifies the output format (fields).
# The '-e' options specify the fields to extract from the DHCP packets.
# The 'tshark' command with the specified options will display the DHCP information.
echo "Analyzing the captured DHCP traffic..."

tshark -r "$OUTPUT_FILE" \
  -T fields \
  -e frame.number \
  -e frame.time \
  -e eth.src \
  -e eth.dst \
  -e ip.src \
  -e ip.dst \
  -e udp.srcport \
  -e udp.dstport \
  -e dhcp.option.dhcp \
  -e dhcp.option.server_id \
  -e dhcp.option.requested_ip_address \
  -e dhcp.option.hostname \
  -E header=y \
  -E separator=, \
  -E quote=d

# Clean up the capture file.
echo "Cleaning up temporary file..."
rm -f "$OUTPUT_FILE"

echo "DHCP traffic analysis complete."

# Usage: sudo ./analyze_dhcp.sh <interface_name>
```