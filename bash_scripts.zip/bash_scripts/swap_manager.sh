# This script automates the process of creating and managing swap space on a Linux system.
# It includes functionality to:
# 1. Check the current swap usage.
# 2. Create new swap files or partitions.
# 3. Activate/Deactivate swap files/partitions.
# 4. Adjust the swappiness value.

# Function to check current swap usage
check_swap_usage() {
  echo "Current swap usage:"
  free -h | grep Swap
  echo ""
}

# Function to create a new swap file
create_swap_file() {
  read -p "Enter the desired size of the swap file (e.g., 1G): " size
  read -p "Enter the desired location of the swap file (e.g., /swapfile): " location

  if [[ -z "$size" || -z "$location" ]]; then
    echo "Error: Size and location must be specified."
    return 1
  fi

  # Check if the file already exists
  if [ -f "$location" ]; then
    read -p "File $location already exists. Overwrite? (y/n): " overwrite
    if [[ "$overwrite" != "y" ]]; then
      echo "Aborted."
      return 1
    fi
  fi

  sudo fallocate -l "$size" "$location"
  sudo chmod 600 "$location"
  sudo mkswap "$location"
  sudo swapon "$location"

  echo "Swap file created at $location with size $size."
  echo "Activating the swap file. Adding it to /etc/fstab..."

  # Add the swap file to /etc/fstab for persistent mounting
  echo "$location none swap sw 0 0" | sudo tee -a /etc/fstab > /dev/null

  echo "Swap file added to /etc/fstab."
  check_swap_usage
}

# Function to activate a swap partition or swap file
activate_swap() {
    read -p "Enter the path to the swap partition or file (e.g., /dev/sda5 or /swapfile): " swap_path

    if [[ -z "$swap_path" ]]; then
        echo "Error: Swap path must be specified."
        return 1
    fi

    if ! sudo swapon "$swap_path"; then
        echo "Error: Failed to activate swap at $swap_path"
        return 1
    fi
    
    echo "Swap activated at $swap_path."
    check_swap_usage
}

# Function to deactivate a swap partition or swap file
deactivate_swap() {
    read -p "Enter the path to the swap partition or file (e.g., /dev/sda5 or /swapfile): " swap_path

    if [[ -z "$swap_path" ]]; then
        echo "Error: Swap path must be specified."
        return 1
    fi

    if ! sudo swapoff "$swap_path"; then
        echo "Error: Failed to deactivate swap at $swap_path"
        return 1
    fi

    echo "Swap deactivated at $swap_path."
    check_swap_usage
}

# Function to adjust swappiness value
adjust_swappiness() {
  read -p "Enter the desired swappiness value (0-100, default is 60): " swappiness

  if [[ -z "$swappiness" ]]; then
    swappiness=60
  fi

  if ! [[ "$swappiness" =~ ^[0-9]+$ ]] || [[ "$swappiness" -lt 0 ]] || [[ "$swappiness" -gt 100 ]]; then
    echo "Error: Swappiness must be a number between 0 and 100."
    return 1
  fi

  # Set the swappiness value temporarily
  sudo sysctl vm.swappiness="$swappiness"

  # Set the swappiness value permanently in /etc/sysctl.conf
  sudo sed -i '/vm.swappiness/d' /etc/sysctl.conf
  echo "vm.swappiness=$swappiness" | sudo tee -a /etc/sysctl.conf > /dev/null

  echo "Swappiness value set to $swappiness."
}

# Main menu
while true; do
  echo "Swap Management Menu:"
  echo "1. Check swap usage"
  echo "2. Create a new swap file"
  echo "3. Activate a swap partition/file"
  echo "4. Deactivate a swap partition/file"
  echo "5. Adjust swappiness"
  echo "6. Exit"

  read -p "Enter your choice: " choice

  case "$choice" in
    1)
      check_swap_usage
      ;;
    2)
      create_swap_file
      ;;
    3)
      activate_swap
      ;;
    4)
      deactivate_swap
      ;;
    5)
      adjust_swappiness
      ;;
    6)
      echo "Exiting..."
      exit 0
      ;;
    *)
      echo "Invalid choice. Please try again."
      ;;
  esac
done
```