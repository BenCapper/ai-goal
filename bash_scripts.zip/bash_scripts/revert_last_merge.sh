# This script automates the process of reverting the last Git merge.
# It identifies the last merge commit and creates a revert commit.
# Usage: ./revert_last_merge.sh

# Get the latest merge commit hash
MERGE_COMMIT=$(git log --merges -n 1 --pretty=format:"%H")

# Check if a merge commit was found
if [ -z "$MERGE_COMMIT" ]; then
  echo "No merge commits found in the history."
  exit 1
fi

# Revert the merge commit
git revert -m 1 "$MERGE_COMMIT"

# Print success message
echo "Successfully reverted merge commit: $MERGE_COMMIT"
echo "A revert commit has been created. You need to commit and push the changes."
```