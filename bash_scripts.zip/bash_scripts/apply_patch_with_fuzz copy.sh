# This script applies a git patch file with a specified fuzz factor.
# It takes two arguments: the patch file and the fuzz factor.

# Check if the correct number of arguments is provided
if [ $# -ne 2 ]; then
  echo "Usage: $0 <patch_file> <fuzz_factor>"
  exit 1
fi

# Assign arguments to variables
patch_file="$1"
fuzz_factor="$2"

# Check if the patch file exists
if [ ! -f "$patch_file" ]; then
  echo "Error: Patch file '$patch_file' not found."
  exit 1
fi

# Check if the fuzz factor is a number
if ! [[ "$fuzz_factor" =~ ^[0-9]+$ ]]; then
  echo "Error: Fuzz factor '$fuzz_factor' is not a number."
  exit 1
fi

# Apply the patch with the specified fuzz factor
git apply --fuzz="$fuzz_factor" "$patch_file"

# Check the exit code of the git apply command
if [ $? -eq 0 ]; then
  echo "Patch '$patch_file' applied successfully with fuzz factor $fuzz_factor."
else
  echo "Error: Failed to apply patch '$patch_file' with fuzz factor $fuzz_factor."
  exit 1
fi

exit 0
```