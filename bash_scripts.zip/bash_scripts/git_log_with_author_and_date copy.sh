# This script uses git to display the commit history of a repository,
# including the author's name and the relative date of each commit.

git log --pretty=format:"%an, %ar: %s"
```