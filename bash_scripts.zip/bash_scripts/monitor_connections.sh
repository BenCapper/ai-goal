#
# This script monitors the number of active connections to a specific network service
# (e.g., SSH, HTTP) and prints the result to the console.  It uses netstat to
# retrieve connection information and awk to count connections matching a specific port.

# Configuration
SERVICE_PORT="22"  # Port number of the service to monitor (e.g., 22 for SSH, 80 for HTTP)
SERVICE_NAME="SSH" # Name of the service for output purposes. Optional.
SLEEP_INTERVAL="60" # Number of seconds to wait between checks

# Function to get the number of active connections
get_active_connections() {
  netstat -an | awk '$6 == "ESTABLISHED" && $4 ~ ":'$SERVICE_PORT'" {count++} END {print count}'
}

# Main loop
while true; do
  CONNECTION_COUNT=$(get_active_connections)
  TIMESTAMP=$(date +"%Y-%m-%d %H:%M:%S")

  echo "$TIMESTAMP: Active $SERVICE_NAME connections on port $SERVICE_PORT: $CONNECTION_COUNT"

  sleep $SLEEP_INTERVAL
done
```