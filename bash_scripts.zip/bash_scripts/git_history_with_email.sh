# This script uses git to display the commit history
# along with the author's email address for each commit.

git log --pretty=format:"%h - %an <%ae> - %s"
```