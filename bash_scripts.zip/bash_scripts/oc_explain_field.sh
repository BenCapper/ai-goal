#
# This script uses the `oc explain` command to get detailed help
# on a specific field within an OpenShift resource.
#
# Usage: ./oc_explain_field.sh <resource> <field_path>
# Example: ./oc_explain_field.sh deployment.spec.template.spec.containers.image
# Example: ./oc_explain_field.sh deployment spec.template.spec.containers.image

RESOURCE="$1"

if [ -z "$RESOURCE" ]; then
  echo "Error: Resource is required."
  echo "Usage: $0 <resource> <field_path>"
  exit 1
fi

shift

FIELD_PATH="$*"

if [ -z "$FIELD_PATH" ]; then
  echo "Error: Field path is required."
  echo "Usage: $0 <resource> <field_path>"
  exit 1
fi

oc explain "$RESOURCE.$FIELD_PATH"
```