# This script takes a URL as an argument and extracts all the script tags from the webpage.
# It uses curl to fetch the webpage content and grep to find the script tags.

if [ $# -eq 0 ]; then
  echo "Usage: $0 <url>"
  exit 1
fi

url=$1

curl -s "$url" | grep -o '<script.*?</script>'
```