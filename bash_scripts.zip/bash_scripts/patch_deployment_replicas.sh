#
# This script patches a specific deployment in OpenShift to change the number of replicas.
#
# Usage: ./patch_deployment_replicas.sh <deployment_name> <namespace> <replica_count>

# Check if the correct number of arguments is provided
if [ $# -ne 3 ]; then
  echo "Usage: ./patch_deployment_replicas.sh <deployment_name> <namespace> <replica_count>"
  exit 1
fi

# Assign arguments to variables
DEPLOYMENT_NAME=$1
NAMESPACE=$2
REPLICA_COUNT=$3

# Check if the deployment exists
oc get deployment "$DEPLOYMENT_NAME" -n "$NAMESPACE" > /dev/null 2>&1
if [ $? -ne 0 ]; then
  echo "Error: Deployment '$DEPLOYMENT_NAME' not found in namespace '$NAMESPACE'."
  exit 1
fi

# Patch the deployment to change the replica count
oc patch deployment "$DEPLOYMENT_NAME" -n "$NAMESPACE" --patch "{\"spec\": {\"replicas\": $REPLICA_COUNT}}"

# Check if the patch was successful
if [ $? -eq 0 ]; then
  echo "Successfully patched deployment '$DEPLOYMENT_NAME' in namespace '$NAMESPACE' to have $REPLICA_COUNT replicas."
else
  echo "Error: Failed to patch deployment '$DEPLOYMENT_NAME' in namespace '$NAMESPACE'."
  exit 1
fi

exit 0
```