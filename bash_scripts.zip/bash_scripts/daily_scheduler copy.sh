# This script creates a simple daily task scheduler.
# It allows the user to add tasks, view tasks, and mark tasks as completed.
# The task list is stored in a text file named tasks.txt.

# Define the tasks file
TASKS_FILE="tasks.txt"

# Function to add a new task
add_task() {
  echo -n "Enter task description: "
  read task_description
  echo "$task_description" >> "$TASKS_FILE"
  echo "Task added successfully."
}

# Function to list all tasks
list_tasks() {
  if [ ! -f "$TASKS_FILE" ]; then
    echo "No tasks found. The tasks list is empty."
    return
  fi

  if [ -s "$TASKS_FILE" ]; then
    echo "Tasks:"
    cat "$TASKS_FILE" | nl
  else
    echo "No tasks found. The tasks list is empty."
  fi
}

# Function to mark a task as completed (remove it from the list)
complete_task() {
  list_tasks
  if [ ! -s "$TASKS_FILE" ]; then
    return
  fi
  echo -n "Enter the task number to mark as completed: "
  read task_number

  if ! [[ "$task_number" =~ ^[0-9]+$ ]]; then
    echo "Invalid task number. Please enter a number."
    return
  fi

  # Check if the task number is valid
  num_lines=$(wc -l < "$TASKS_FILE")
  if [ "$task_number" -gt "$num_lines" ] || [ "$task_number" -lt 1 ]; then
    echo "Invalid task number."
    return
  fi

  # Remove the task from the file
  sed -i "${task_number}d" "$TASKS_FILE"
  echo "Task marked as completed."
}

# Main menu
while true; do
  echo ""
  echo "Daily Task Scheduler"
  echo "---------------------"
  echo "1. Add Task"
  echo "2. List Tasks"
  echo "3. Complete Task"
  echo "4. Exit"
  echo -n "Enter your choice: "
  read choice

  case "$choice" in
    1)
      add_task
      ;;
    2)
      list_tasks
      ;;
    3)
      complete_task
      ;;
    4)
      echo "Exiting..."
      exit 0
      ;;
    *)
      echo "Invalid choice. Please try again."
      ;;
  esac
done
```