# This script processes files in a specified directory.
# It calculates the total size of files with a specific extension
# and prints a summary.

# Define variables
SOURCE_DIRECTORY="/path/to/your/files" # Directory containing the files
FILE_EXTENSION="txt"           # Extension of the files to process
TOTAL_SIZE=0                    # Initialize the total size

# Check if the source directory exists
if [ ! -d "$SOURCE_DIRECTORY" ]; then
  echo "Error: Source directory '$SOURCE_DIRECTORY' does not exist."
  exit 1
fi

# Loop through files with the specified extension
for FILE in "$SOURCE_DIRECTORY"/*."$FILE_EXTENSION"; do
  # Check if the file exists
  if [ -f "$FILE" ]; then
    # Get the file size in bytes
    FILE_SIZE=$(stat -c %s "$FILE")

    # Add the file size to the total size
    TOTAL_SIZE=$((TOTAL_SIZE + FILE_SIZE))
  fi
done

# Convert total size to kilobytes (KB)
TOTAL_SIZE_KB=$((TOTAL_SIZE / 1024))

# Print the summary
echo "-----------------------------------------"
echo "File Processing Summary:"
echo "Directory: $SOURCE_DIRECTORY"
echo "Extension: .$FILE_EXTENSION"
echo "Total files processed with extension .$FILE_EXTENSION: $(find "$SOURCE_DIRECTORY" -maxdepth 1 -type f -name "*.$FILE_EXTENSION" | wc -l)"
echo "Total size: $TOTAL_SIZE bytes ($TOTAL_SIZE_KB KB)"
echo "-----------------------------------------"

exit 0
```