# This script automates the process of backing up and restoring
# the system's window manager themes and font settings.
# It backs up the relevant directories and configuration files to a specified backup directory.
# It also provides a restore function to restore the settings from the backup.

# --- Configuration ---
BACKUP_DIR="$HOME/backup_themes_fonts"
THEME_DIR="$HOME/.themes"
ICONS_DIR="$HOME/.icons"
FONT_CONFIG="$HOME/.config/fontconfig/fonts.conf"
XRESOURCES="$HOME/.Xresources" # or .Xdefaults, depending on your system
GTK_SETTINGS="$HOME/.config/gtk-3.0/settings.ini"
QT5_SETTINGS="$HOME/.config/qt5ct/qt5ct.conf" # If you use qt5ct

# --- Functions ---

backup_themes_fonts() {
  # Create the backup directory if it doesn't exist
  mkdir -p "$BACKUP_DIR"

  # Backup themes
  if [ -d "$THEME_DIR" ]; then
    cp -r "$THEME_DIR" "$BACKUP_DIR/"
    echo "Themes backed up to $BACKUP_DIR"
  else
    echo "Theme directory $THEME_DIR does not exist."
  fi

  # Backup icons
  if [ -d "$ICONS_DIR" ]; then
    cp -r "$ICONS_DIR" "$BACKUP_DIR/"
    echo "Icons backed up to $BACKUP_DIR"
  else
      echo "Icon directory $ICONS_DIR does not exist."
  fi

  # Backup font configuration
  if [ -f "$FONT_CONFIG" ]; then
    cp "$FONT_CONFIG" "$BACKUP_DIR/"
    echo "Font configuration backed up to $BACKUP_DIR"
  else
    echo "Font configuration file $FONT_CONFIG does not exist."
  fi

  # Backup Xresources
  if [ -f "$XRESOURCES" ]; then
    cp "$XRESOURCES" "$BACKUP_DIR/"
    echo "Xresources backed up to $BACKUP_DIR"
  else
    echo "Xresources file $XRESOURCES does not exist."
  fi
  
  # Backup GTK settings
  if [ -f "$GTK_SETTINGS" ]; then
    cp "$GTK_SETTINGS" "$BACKUP_DIR/"
    echo "GTK settings backed up to $BACKUP_DIR"
  else
    echo "GTK settings file $GTK_SETTINGS does not exist."
  fi

  #Backup QT5 settings
  if [ -f "$QT5_SETTINGS" ]; then
    cp "$QT5_SETTINGS" "$BACKUP_DIR/"
    echo "QT5 settings backed up to $BACKUP_DIR"
  else
    echo "QT5 settings file $QT5_SETTINGS does not exist."
  fi
}

restore_themes_fonts() {
  # Check if the backup directory exists
  if [ ! -d "$BACKUP_DIR" ]; then
    echo "Backup directory $BACKUP_DIR does not exist."
    return 1
  fi

  # Restore themes
  if [ -d "$BACKUP_DIR/.themes" ]; then
    echo "Restoring themes..."
    rm -rf "$THEME_DIR"
    cp -r "$BACKUP_DIR/.themes" "$HOME/"
  else
    echo "No themes backup found in $BACKUP_DIR"
  fi

  # Restore icons
  if [ -d "$BACKUP_DIR/.icons" ]; then
    echo "Restoring icons..."
    rm -rf "$ICONS_DIR"
    cp -r "$BACKUP_DIR/.icons" "$HOME/"
  else
    echo "No icons backup found in $BACKUP_DIR"
  fi

  # Restore font configuration
  if [ -f "$BACKUP_DIR/fonts.conf" ]; then
    echo "Restoring font configuration..."
    rm -f "$FONT_CONFIG"
    mkdir -p "$HOME/.config/fontconfig" # Ensure the directory exists
    cp "$BACKUP_DIR/fonts.conf" "$FONT_CONFIG"
    fc-cache -f -v # Update font cache
  else
    echo "No font configuration backup found in $BACKUP_DIR"
  fi

  # Restore Xresources
  if [ -f "$BACKUP_DIR/.Xresources" ]; then
    echo "Restoring Xresources..."
    rm -f "$XRESOURCES"
    cp "$BACKUP_DIR/.Xresources" "$XRESOURCES"
    xrdb "$XRESOURCES" # Load the new Xresources
  else
    echo "No Xresources backup found in $BACKUP_DIR"
  fi

  # Restore GTK settings
  if [ -f "$BACKUP_DIR/settings.ini" ]; then
    echo "Restoring GTK settings..."
    rm -f "$GTK_SETTINGS"
    mkdir -p "$HOME/.config/gtk-3.0"
    cp "$BACKUP_DIR/settings.ini" "$GTK_SETTINGS"
  else
    echo "No GTK settings backup found in $BACKUP_DIR"
  fi

  # Restore QT5 settings
    if [ -f "$BACKUP_DIR/qt5ct.conf" ]; then
      echo "Restoring QT5 settings..."
      rm -f "$QT5_SETTINGS"
      mkdir -p "$HOME/.config/qt5ct"
      cp "$BACKUP_DIR/qt5ct.conf" "$QT5_SETTINGS"
    else
      echo "No QT5 settings backup found in $BACKUP_DIR"
    fi

  echo "Restoration complete. You may need to restart your window manager or applications for the changes to take effect."
}


# --- Main Script ---

if [ "$1" == "backup" ]; then
  backup_themes_fonts
elif [ "$1" == "restore" ]; then
  restore_themes_fonts
else
  echo "Usage: $0 [backup|restore]"
  exit 1
fi

exit 0
```