#
# This script monitors the voltage of the system's cooling fans (if available via sensors)
# and logs the voltage fluctuations over time to a log file.
# It uses the 'sensors' command to read sensor data and extracts fan voltage information.
# It then appends the data to a log file with a timestamp.
#

# Usage: ./fan_voltage_monitor.sh

# Define the log file path
LOG_FILE="fan_voltage.log"

# Function to get fan voltage data using the 'sensors' command
get_fan_voltage() {
  sensors | grep "fan[0-9]+:" | awk '{print $1, $2}'
}

# Main loop to monitor and log the fan voltage
while true; do
  # Get the current timestamp
  TIMESTAMP=$(date +'%Y-%m-%d %H:%M:%S')

  # Get fan voltage data
  FAN_VOLTAGE=$(get_fan_voltage)

  # If fan voltage data is available, log it
  if [ -n "$FAN_VOLTAGE" ]; then
    echo "$TIMESTAMP - $FAN_VOLTAGE" >> "$LOG_FILE"
    echo "Logged: $TIMESTAMP - $FAN_VOLTAGE"
  else
    echo "$TIMESTAMP - No fan voltage sensors found." >> "$LOG_FILE"
    echo "$TIMESTAMP - No fan voltage sensors found."
  fi

  # Wait for a specified interval (e.g., 60 seconds)
  sleep 60
done
```