# This script takes two numbers as input and calculates their average.
# It performs error checking to ensure that the inputs are valid numbers.

# Get the first number from the user.
read -p "Enter the first number: " num1

# Get the second number from the user.
read -p "Enter the second number: " num2

# Check if the inputs are valid numbers.
if ! [[ "$num1" =~ ^[+-]?[0-9]+(\.[0-9]+)?$ ]] || ! [[ "$num2" =~ ^[+-]?[0-9]+(\.[0-9]+)?$ ]]; then
  echo "Error: Both inputs must be numbers."
  exit 1
fi

# Calculate the sum of the two numbers.
sum=$(echo "$num1 + $num2" | bc)

# Calculate the average.
average=$(echo "$sum / 2" | bc)

# Print the average.
echo "The average of $num1 and $num2 is: $average"

exit 0
```