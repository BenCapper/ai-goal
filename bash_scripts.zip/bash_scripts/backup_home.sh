# This script creates a full backup of the /home directory to a remote server using rsync over SSH.
# It prompts for the SSH password (or uses SSH keys if configured).
# It logs the start and end times of the backup to a log file.

# Usage: ./backup_home.sh <remote_user> <remote_host> <backup_directory>

# Define variables
REMOTE_USER="$1"
REMOTE_HOST="$2"
BACKUP_DIR="$3"
LOG_FILE="backup_home.log"
DATE=$(date +%Y-%m-%d_%H-%M-%S)
BACKUP_PATH="${BACKUP_DIR}/home_backup_${DATE}"

# Check if required arguments are provided
if [ -z "$REMOTE_USER" ] || [ -z "$REMOTE_HOST" ] || [ -z "$BACKUP_DIR" ]; then
  echo "Usage: $0 <remote_user> <remote_host> <backup_directory>"
  exit 1
fi

# Log the start time
echo "Backup started at: $(date)" >> "$LOG_FILE"

# Perform the backup using rsync over SSH
rsync -avz --delete /home/ "$REMOTE_USER@$REMOTE_HOST:$BACKUP_PATH"

# Check the exit code of rsync
if [ $? -eq 0 ]; then
  echo "Backup completed successfully." >> "$LOG_FILE"
else
  echo "Backup failed." >> "$LOG_FILE"
fi

# Log the end time
echo "Backup finished at: $(date)" >> "$LOG_FILE"

# Example usage: ./backup_home.sh user1 example.com /backups
```