# This script deploys a simple application to a Kubernetes cluster using a YAML file.
# It checks if kubectl is installed and configured, then applies the provided YAML file.

# Check if kubectl is installed
if ! command -v kubectl &> /dev/null
then
  echo "kubectl could not be found"
  exit 1
fi

# Check if the YAML file is provided as an argument
if [ -z "$1" ]
then
  echo "Usage: $0 <application.yaml>"
  exit 1
fi

yaml_file="$1"

# Check if the YAML file exists
if [ ! -f "$yaml_file" ]
then
  echo "Error: YAML file '$yaml_file' not found."
  exit 1
fi

# Apply the YAML file to deploy the application
echo "Deploying application using '$yaml_file'..."
kubectl apply -f "$yaml_file"

# Check the deployment status
if [ $? -eq 0 ]; then
  echo "Application deployed successfully!"
else
  echo "Error deploying application."
  exit 1
fi

exit 0
```