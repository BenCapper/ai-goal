# This script searches for failures in the system logs for today
# and extracts the timestamp and message using journalctl, grep, and awk.

# Use: ./failures_today.sh

journalctl --since "today" | grep -i "fail" | awk '{print $4, $5, $6, $7}'
```