# This script uses the 'ip' command to display detailed information about the routing table.
# It shows the destination network, gateway, and the interface used for each route.

# Usage: ./show_routing_table.sh

ip route show table all
```