# This script checks if a configuration directory exists, is readable, executable,
# not writable by the owner, and has no permissions for others (neither read, write, nor execute).
# It then declares a variable indicating the result of these checks.

# Usage: ./config_dir_check.sh

CONFIG_DIR="/opt/my_app/config"
CONFIG_DIR_READABLE_EXECUTABLE_NOT_WRITABLE_OTHER_NONE=0

if [ -d "$CONFIG_DIR" ] && [ -r "$CONFIG_DIR" ] && [ -x "$CONFIG_DIR" ] && ! [ -w "$CONFIG_DIR" ] && ! ( [ -o -r "$CONFIG_DIR" ] || [ -o -w "$CONFIG_DIR" ] || [ -o -x "$CONFIG_DIR" ] ); then
  echo "Configuration directory '$CONFIG_DIR' exists, is readable, executable, not writable by owner and has no permissions for others."
  CONFIG_DIR_READABLE_EXECUTABLE_NOT_WRITABLE_OTHER_NONE=1
else
  echo "Configuration directory '$CONFIG_DIR' does not meet the required criteria."
  CONFIG_DIR_READABLE_EXECUTABLE_NOT_WRITABLE_OTHER_NONE=0
fi

echo "CONFIG_DIR_READABLE_EXECUTABLE_NOT_WRITABLE_OTHER_NONE: $CONFIG_DIR_READABLE_EXECUTABLE_NOT_WRITABLE_OTHER_NONE"
```