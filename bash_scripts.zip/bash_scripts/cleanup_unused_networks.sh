# This script cleans up unused container networks (Docker and Podman)
# by removing networks that are not currently connected to any containers.
# It checks for both Docker and Podman environments and uses the appropriate
# command-line tools to identify and remove unused networks.

# Function to check if Docker is installed
is_docker_installed() {
  command -v docker &> /dev/null
}

# Function to check if Podman is installed
is_podman_installed() {
  command -v podman &> /dev/null
}

# Function to cleanup Docker networks
cleanup_docker_networks() {
  if is_docker_installed; then
    echo "Cleaning up unused Docker networks..."
    docker network prune -f
  else
    echo "Docker not found. Skipping Docker network cleanup."
  fi
}

# Function to cleanup Podman networks
cleanup_podman_networks() {
  if is_podman_installed; then
    echo "Cleaning up unused Podman networks..."
    podman network prune --all --force
  else
    echo "Podman not found. Skipping Podman network cleanup."
  fi
}


# Main script execution
echo "Starting network cleanup..."

cleanup_docker_networks
cleanup_podman_networks

echo "Network cleanup completed."
```