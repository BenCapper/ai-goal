# This script executes an Ansible playbook with a specific tag.
# It takes the playbook file and the tag name as arguments.

# Check if the correct number of arguments is provided
if [ $# -ne 2 ]; then
  echo "Usage: $0 <playbook_file> <tag_name>"
  exit 1
fi

# Assign arguments to variables
PLAYBOOK=$1
TAG=$2

# Check if the playbook file exists
if [ ! -f "$PLAYBOOK" ]; then
  echo "Error: Playbook file '$PLAYBOOK' not found."
  exit 1
fi

# Execute the Ansible playbook with the specified tag
ansible-playbook "$PLAYBOOK" --tags "$TAG"

# Check the exit code of the ansible-playbook command
if [ $? -ne 0 ]; then
  echo "Error: Ansible playbook execution failed."
  exit 1
fi

echo "Ansible playbook '$PLAYBOOK' executed successfully with tag '$TAG'."

exit 0
```