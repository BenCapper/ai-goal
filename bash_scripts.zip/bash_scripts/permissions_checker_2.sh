# This script reads a permission string (e.g., rwxr-xr--) and checks for
# specific permissions for group and others using if statements and
# substring extraction.

# Usage: ./permissions_checker.sh <permission_string>

# Check if an argument is provided
if [ $# -ne 1 ]; then
  echo "Error: Please provide a permission string as an argument."
  echo "Usage: ./permissions_checker.sh <permission_string>"
  exit 1
fi

MODE_STRING="$1"

# Check the length of the permission string
if [ ${#MODE_STRING} -ne 10 ]; then
  echo "Error: Permission string must be 10 characters long (e.g., drwxr-xr--)."
  exit 1
fi

# Check group permissions
GROUP_PERMISSIONS="${MODE_STRING:4:3}"
OTHERS_PERMISSIONS="${MODE_STRING:7:3}"


# Check if group has read permission
if [ "${GROUP_PERMISSIONS:0:1}" = "r" ]; then
  echo "Group has read permission."
fi

# Check if group has write permission
if [ "${GROUP_PERMISSIONS:1:1}" = "w" ]; then
  echo "Group has write permission."
fi

# Check if group has execute permission
if [ "${GROUP_PERMISSIONS:2:1}" = "x" ]; then
  echo "Group has execute permission."
fi

# Check if others have read permission
if [ "${OTHERS_PERMISSIONS:0:1}" = "r" ]; then
  echo "Others have read permission."
fi

# Check if others have write permission
if [ "${OTHERS_PERMISSIONS:1:1}" = "w" ]; then
  echo "Others have write permission."
fi

# Check if others have execute permission
if [ "${OTHERS_PERMISSIONS:2:1}" = "x" ]; then
  echo "Others have execute permission."
fi

#Example of usage:
#./permissions_checker.sh rwxr-xr--
```