# This script checks if a string contains only special characters 
# and no other character types (alphabets, digits, or spaces).

# Declare a variable to store the text to be checked.
TEXT_TO_CHECK_NON_ALPHABETICAL_NON_DIGIT_NON_SPACE_ONLY_SPECIAL="!@#$%^&*()"

# Check if the string contains only special characters using regex.
if [[ "$TEXT_TO_CHECK_NON_ALPHABETICAL_NON_DIGIT_NON_SPACE_ONLY_SPECIAL" =~ ^[^a-zA-Z0-9[:space:]]+$ ]]; then
  echo "The string contains only special characters."
else
  echo "The string contains characters other than special characters."
fi

# Usage: ./check_special_chars.sh
```