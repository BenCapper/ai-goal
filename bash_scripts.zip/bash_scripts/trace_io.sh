# This script traces I/O related system calls (read, write) for processes
# matching the name specified in the PROCESS_TO_TRACE_IO variable.
# It uses pgrep to find the PIDs of the matching processes, then uses
# strace to trace the read and write system calls with timestamps.
# The output of strace is logged to a file named trace_io.log.

# Usage: ./trace_io.sh

# Set the name of the process to trace.  Change this to the desired process.
PROCESS_TO_TRACE_IO="your_process_name"

# Output file for strace logs
LOG_FILE="trace_io.log"

# Check if process name is provided
if [ -z "$PROCESS_TO_TRACE_IO" ]; then
  echo "Error: PROCESS_TO_TRACE_IO variable is not set.  Please set it to the name of the process you want to trace."
  exit 1
fi

# Clear the log file if it exists
if [ -f "$LOG_FILE" ]; then
  > "$LOG_FILE"
fi

# Find PIDs of the process
PIDS=$(pgrep "$PROCESS_TO_TRACE_IO")

# Check if any PIDs were found
if [ -z "$PIDS" ]; then
  echo "No process found matching '$PROCESS_TO_TRACE_IO'."
  exit 1
fi

# Iterate through the PIDs and trace I/O related system calls
for PID in $PIDS; do
  echo "Tracing PID: $PID"
  strace -p "$PID" -e read,write -tt 2>&1 | tee -a "$LOG_FILE" &
done

echo "Tracing I/O calls for '$PROCESS_TO_TRACE_IO' processes.  Logs are being written to '$LOG_FILE'."
echo "Press Ctrl+C to stop tracing."

# Keep the script running until interrupted
wait

echo "Tracing stopped."

# Example usage:
# ./trace_io.sh
```