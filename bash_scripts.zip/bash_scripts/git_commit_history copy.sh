# This script uses git to display the commit history in a custom format.
# It shows the commit hash, committer email, commit body, and the number
# of lines added and deleted in each commit.

git log --pretty=format:"%h - %ae - %b" --numstat | awk '
BEGIN {
  commit_info = ""
}
/^([0-9]+|-)\t([0-9]+|-)\t(.*)/ {
  added += $1
  deleted += $2
  file_changed = $3
  changes[file_changed] = added "+" deleted

  if($1 != "-"){
     total_added += $1
     total_deleted += $2
  }

}
/^([a-f0-9]+) - (.*) - (.*)/ {
  if (commit_info != "") {
      printf "%sAdded: %s, Deleted: %s\n", commit_info, total_added, total_deleted
  }
  commit_info = $0 "\n"
  total_added = 0
  total_deleted = 0
}
END {
  printf "%sAdded: %s, Deleted: %s\n", commit_info, total_added, total_deleted
}
'
```