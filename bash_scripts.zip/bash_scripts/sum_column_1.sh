# This script uses awk to calculate the sum of a specific column in a data file.
# It takes the column number as an argument.
# The script reads the data file from standard input.

# Check if the correct number of arguments is provided.
if [ $# -ne 1 ]; then
  echo "Usage: $0 <column_number>"
  exit 1
fi

# Get the column number from the command line argument.
column_number=$1

# Use awk to calculate the sum of the specified column.
awk -v col="$column_number" '{ sum += $col } END { print sum }'

exit 0
```