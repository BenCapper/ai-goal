# This script takes a directory of video files as input
# and generates a contact sheet (thumbnail grid) using ffmpeg.

# Usage: ./contact_sheet.sh <input_directory> <output_file> <options>
#
# <input_directory>: Directory containing video files.
# <output_file>: Output image file name (e.g., contact_sheet.png).
# <options>: Additional ffmpeg options (optional).
#            -n <number_of_thumbnails> (default: 9)
#            -c <columns> (default: 3)
#            -w <width> (default: 320)
#            -f <format> (default: png)

# Default values
NUM_THUMBNAILS=9
NUM_COLUMNS=3
THUMBNAIL_WIDTH=320
OUTPUT_FORMAT="png"

# Function to print usage instructions
usage() {
  echo "Usage: $0 <input_directory> <output_file> [-n <number_of_thumbnails>] [-c <columns>] [-w <width>] [-f <format>]"
  echo "  <input_directory>: Directory containing video files."
  echo "  <output_file>: Output image file name (e.g., contact_sheet.png)."
  echo "  -n <number_of_thumbnails>: Number of thumbnails to generate (default: $NUM_THUMBNAILS)."
  echo "  -c <columns>: Number of columns in the grid (default: $NUM_COLUMNS)."
  echo "  -w <width>: Width of each thumbnail (default: $THUMBNAIL_WIDTH)."
  echo "  -f <format>: Output format (default: $OUTPUT_FORMAT)."
  exit 1
}

# Parse command-line arguments
INPUT_DIR="$1"
OUTPUT_FILE="$2"

if [ -z "$INPUT_DIR" ] || [ -z "$OUTPUT_FILE" ]; then
  usage
fi

shift 2

while [ "$#" -gt 0 ]; do
  case "$1" in
    -n)
      NUM_THUMBNAILS="$2"
      shift 2
      ;;
    -c)
      NUM_COLUMNS="$2"
      shift 2
      ;;
    -w)
      THUMBNAIL_WIDTH="$2"
      shift 2
      ;;
    -f)
      OUTPUT_FORMAT="$2"
      shift 2
      ;;
    *)
      echo "Unknown option: $1"
      usage
      ;;
  esac
done

# Create temporary directory
TEMP_DIR=$(mktemp -d)

# Find video files in the input directory
VIDEO_FILES=$(find "$INPUT_DIR" -type f \( -name "*.mp4" -o -name "*.avi" -o -name "*.mov" -o -name "*.mkv" \))

if [ -z "$VIDEO_FILES" ]; then
  echo "No video files found in $INPUT_DIR"
  rm -rf "$TEMP_DIR"
  exit 1
fi

# Calculate the number of rows
NUM_ROWS=$((NUM_THUMBNAILS / NUM_COLUMNS))

# Check if we need an extra row
if [ $((NUM_THUMBNAILS % NUM_COLUMNS)) -gt 0 ]; then
  NUM_ROWS=$((NUM_ROWS + 1))
fi

# Calculate thumbnail height (maintain aspect ratio) - not perfect, but works
THUMBNAIL_HEIGHT=$((THUMBNAIL_WIDTH * 9 / 16)) #approx 16:9 aspect ratio

# Loop through video files and generate thumbnails
i=0
for VIDEO_FILE in $VIDEO_FILES; do
  DURATION=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "$VIDEO_FILE")
  if [ -z "$DURATION" ]; then
    echo "Could not get duration for $VIDEO_FILE. Skipping."
    continue
  fi
  
  INTERVAL=$(( $(echo "$DURATION * 1000 / $NUM_THUMBNAILS" | bc) ))
  
  for j in $(seq 1 $NUM_THUMBNAILS); do
     
      TIMESTAMP=$(( $INTERVAL * $j / 1000 ))
    
      OUTPUT_THUMBNAIL="$TEMP_DIR/thumbnail_$i_$j.$OUTPUT_FORMAT"
       ffmpeg -ss "$TIMESTAMP" -i "$VIDEO_FILE" -vframes 1 -vf "scale=$THUMBNAIL_WIDTH:$THUMBNAIL_HEIGHT" "$OUTPUT_THUMBNAIL" 2>/dev/null
      i=$((i+1))
  done
  break # process the first video file only for demonstration purposes, remove to process all
done

# Create contact sheet
MONTAGE_COMMAND="montage -geometry ${THUMBNAIL_WIDTH}x${THUMBNAIL_HEIGHT}+0+0 -tile ${NUM_COLUMNS}x${NUM_ROWS} $TEMP_DIR/thumbnail_*.$OUTPUT_FORMAT $OUTPUT_FILE"
eval "$MONTAGE_COMMAND"

# Clean up temporary directory
rm -rf "$TEMP_DIR"

echo "Contact sheet generated: $OUTPUT_FILE"
```