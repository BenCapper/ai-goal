# This script reads a CSV file, extracts data from two specified columns,
# and generates a simple scatter plot in text format.

# Usage: ./scatter_plot.sh <csv_file> <x_column_index> <y_column_index>
# Example: ./scatter_plot.sh data.csv 1 2

# Check if the correct number of arguments is provided
if [ $# -ne 3 ]; then
  echo "Usage: $0 <csv_file> <x_column_index> <y_column_index>"
  exit 1
fi

csv_file="$1"
x_column_index="$2"
y_column_index="$3"

# Validate that the CSV file exists
if [ ! -f "$csv_file" ]; then
  echo "Error: CSV file '$csv_file' not found."
  exit 1
fi

# Validate that the column indices are positive integers
if ! [[ "$x_column_index" =~ ^[0-9]+$ ]] || ! [[ "$y_column_index" =~ ^[0-9]+$ ]]; then
  echo "Error: Column indices must be positive integers."
  exit 1
fi

# Convert column indices to be zero-based for `awk`
x_column_index=$((x_column_index - 1))
y_column_index=$((y_column_index - 1))

# Determine minimum and maximum values for scaling
x_min=$(awk -v col="$x_column_index" -F',' 'NR>1 {print $col}' "$csv_file" | sort -n | head -n 1)
x_max=$(awk -v col="$x_column_index" -F',' 'NR>1 {print $col}' "$csv_file" | sort -n | tail -n 1)
y_min=$(awk -v col="$y_column_index" -F',' 'NR>1 {print $col}' "$csv_file" | sort -n | head -n 1)
y_max=$(awk -v col="$y_column_index" -F',' 'NR>1 {print $col}' "$csv_file" | sort -n | tail -n 1)

# Define plot dimensions
plot_width=60
plot_height=20

# Function to scale a value to the plot range
scale() {
  local value="$1"
  local min="$2"
  local max="$3"
  local range="$4"

  if [ "$min" = "$max" ]; then
      echo "$range" # Avoid division by zero if min and max are the same
      return
  fi

  scaled_value=$(( (value - min) * range / (max - min) ))
  echo "$scaled_value"
}

# Create an empty plot
plot=""
for ((i=0; i<$plot_height; i++)); do
  for ((j=0; j<$plot_width; j++)); do
    plot+=' '
  done
  plot+=$'\n'
done

# Plot the data
while IFS=, read -r -a line; do
  # Skip the header row
  if [[ "$line" == *"Header"* ]]; then
    continue
  fi
  x_value="${line[$x_column_index]}"
  y_value="${line[$y_column_index]}"

  # Validate data is numeric
  if ! [[ "$x_value" =~ ^[0-9]+(\.[0-9]+)?$ ]] || ! [[ "$y_value" =~ ^[0-9]+(\.[0-9]+)?$ ]]; then
    continue  # Skip non-numeric data
  fi

  # Scale the values to plot coordinates
  x_coord=$(scale "$x_value" "$x_min" "$x_max" "$plot_width")
  y_coord=$((plot_height - $(scale "$y_value" "$y_min" "$y_max" "$plot_height") - 1 ))

  # Check that scaled coordinates are within plot bounds
  if [[ "$x_coord" -ge 0 ]] && [[ "$x_coord" -lt "$plot_width" ]] && [[ "$y_coord" -ge 0 ]] && [[ "$y_coord" -lt "$plot_height" ]]; then
    # Calculate the index in the string
    index=$(( y_coord * (plot_width + 1) + x_coord ))

    # Replace the space with a dot at the calculated index
    plot=$(printf "%s%.*s%s" "${plot:0:$index}" 1 "." "${plot:$((index+1))}")
  fi

done < <(tail -n +2 "$csv_file") #skip header

# Print the plot
echo "$plot"
```