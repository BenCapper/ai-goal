# This script parses an Ansible playbook and extracts a list of all defined handlers.
# It uses grep and sed to find and format the handler names.

playbook="$1"

if [ -z "$playbook" ]; then
  echo "Usage: $0 <playbook.yml>"
  exit 1
fi

if [ ! -f "$playbook" ]; then
  echo "Error: Playbook '$playbook' not found."
  exit 1
fi

grep -oP '(?s)handlers:.*?name: \K.*?(?=\n)' "$playbook" | sed 's/^[[:space:]]*//g' | sort | uniq
```