# This script automates the installation and configuration of a message queue system.
# It currently supports RabbitMQ and Kafka.
# The script takes one argument: the name of the message queue system to install (rabbitmq or kafka).

# Check if the user is root
if [[ $EUID -ne 0 ]]; then
  echo "This script must be run as root"
  exit 1
fi

# Function to install RabbitMQ
install_rabbitmq() {
  echo "Installing RabbitMQ..."

  # Update package lists
  apt-get update

  # Install RabbitMQ server
  apt-get install -y rabbitmq-server

  # Enable RabbitMQ management plugin
  rabbitmq-plugins enable rabbitmq_management

  # Optionally, add a user and set permissions (replace with secure credentials)
  # rabbitmqctl add_user myuser mypassword
  # rabbitmqctl set_permissions -p / myuser ".*" ".*" ".*"

  echo "RabbitMQ installation complete.  Access the management UI at http://localhost:15672 (default)."
}

# Function to install Kafka
install_kafka() {
  echo "Installing Kafka..."

  # Set up the Confluent repository (replace with appropriate version)
  wget -qO - https://packages.confluent.io/deb/7.5/archive.key | apt-key add -
  add-apt-repository "deb [trusted=yes] https://packages.confluent.io/deb/7.5 stable main"

  # Update package lists
  apt-get update

  # Install Kafka and Zookeeper (required for Kafka)
  apt-get install -y confluent-platform

  # Configure Zookeeper (minimal config for single-node, adjust for production)
  # Modify /etc/kafka/zookeeper.properties as needed (e.g., dataDir)

  # Start Zookeeper
  systemctl start confluent-zookeeper

  # Start Kafka
  systemctl start confluent-kafka

  # Create a Kafka topic (example)
  # kafka-topics --create --topic mytopic --partitions 1 --replication-factor 1 --bootstrap-server localhost:9092

  echo "Kafka installation complete. Zookeeper and Kafka servers are running."
}


# Main script logic
if [ -z "$1" ]; then
  echo "Usage: $0 <rabbitmq|kafka>"
  exit 1
fi

MESSAGE_QUEUE_SYSTEM="$1"

case "$MESSAGE_QUEUE_SYSTEM" in
  rabbitmq)
    install_rabbitmq
    ;;
  kafka)
    install_kafka
    ;;
  *)
    echo "Invalid message queue system: $MESSAGE_QUEUE_SYSTEM"
    echo "Supported systems are: rabbitmq, kafka"
    exit 1
    ;;
esac

echo "Installation and basic configuration complete."
```