# This script checks if a user is currently logged in.
# If the user is logged in, it prints a message indicating that.
# If the user is not logged in, it prints the user's last login time.

# Declare the variable for the username to query.
USER_TO_QUERY_LAST_LOGIN="example_user"

# Check if the user is currently logged in.
if last -i "$USER_TO_QUERY_LAST_LOGIN" | grep -q "still logged in"; then
  echo "$USER_TO_QUERY_LAST_LOGIN is currently logged in."
else
  # Get the last login time.
  last_login=$(last -i "$USER_TO_QUERY_LAST_LOGIN" | head -n 1)

  # Check if last command returned any output, or if the user doesn't exist
  if [ -z "$last_login" ]; then
    echo "No login history found for user: $USER_TO_QUERY_LAST_LOGIN"
  else
    # Print the last login time.
    echo "Last login for $USER_TO_QUERY_LAST_LOGIN:"
    echo "$last_login"
  fi
fi

# Usage: ./last_login_check.sh
```