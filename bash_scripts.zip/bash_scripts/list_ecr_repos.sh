# This script uses the AWS CLI to list all ECR repositories in the configured AWS account and region.

# Usage: ./list_ecr_repos.sh

# Retrieve the list of ECR repositories
aws ecr describe-repositories --output text --query 'repositories[*].repositoryName'
```