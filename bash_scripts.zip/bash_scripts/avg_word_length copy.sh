# This script calculates the average word length across all plain text files in a given directory.
# It takes the directory path as a command-line argument.

# Check if a directory is provided as an argument
if [ $# -ne 1 ]; then
  echo "Usage: $0 <directory>"
  exit 1
fi

directory="$1"

# Check if the directory exists
if [ ! -d "$directory" ]; then
  echo "Error: Directory '$directory' does not exist."
  exit 1
fi

# Initialize variables
total_words=0
total_characters=0

# Iterate through each file in the directory
find "$directory" -type f -print0 | while IFS= read -r -d $'\0' file; do
  # Check if the file is a plain text file
  if file --mime-type "$file" | grep -q "^${file}: text/plain"; then
    # Count the number of words and characters in the file
    words=$(wc -w "$file" | awk '{print $1}')
    characters=$(wc -c "$file" | awk '{print $1}')

    # Add to the totals
    total_words=$((total_words + words))
    total_characters=$((total_characters + characters))
  fi
done

# Calculate the average word length
if [ "$total_words" -gt 0 ]; then
  average_length=$(echo "scale=2; $total_characters / $total_words" | bc)
  echo "Average word length: $average_length"
else
  echo "No words found in the specified directory."
fi

exit 0
```