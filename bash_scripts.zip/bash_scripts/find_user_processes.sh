# This script iterates through the output of the ps aux command,
# stores each line in a variable PROCESS_INFO, and
# uses an if statement with grep to find lines belonging to a specific user.

# Usage: ./find_user_processes.sh <username>

USERNAME="$1"

if [ -z "$USERNAME" ]; then
  echo "Error: Please provide a username as an argument."
  exit 1
fi

for PROCESS_INFO in $(ps aux); do
  if echo "$PROCESS_INFO" | grep -q "^$USERNAME"; then
    echo "$PROCESS_INFO"
  fi
done

# ./find_user_processes.sh username
```