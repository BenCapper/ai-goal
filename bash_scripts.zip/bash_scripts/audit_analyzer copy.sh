# This script analyzes the system's auditd rules for system call monitoring.
# It parses the /etc/audit/audit.rules file and extracts rules related to system calls.
# It then provides a summary of the monitored system calls and the corresponding actions.
#
# Usage: ./audit_analyzer.sh

# Define the audit rules file
AUDIT_RULES_FILE="/etc/audit/audit.rules"

# Check if the audit rules file exists
if [ ! -f "$AUDIT_RULES_FILE" ]; then
  echo "Error: Audit rules file not found: $AUDIT_RULES_FILE"
  exit 1
fi

# Function to extract system call names from a rule
extract_syscalls() {
  local rule="$1"
  local syscalls

  # Extract the syscall names using grep and sed
  syscalls=$(echo "$rule" | grep -oP 'syscall=\K\[?[^\]]+\]?' | sed 's/[\[\]]//g' | tr ',' '\n' | sort -u)

  echo "$syscalls"
}

# Function to extract the action from the audit rule.
extract_action() {
  local rule="$1"
  local action

  # Extract the action (always last field in the rule) using awk.
  action=$(echo "$rule" | awk '{print $NF}')

  echo "$action"
}

# Function to process each audit rule
process_rule() {
  local rule="$1"

  # Skip comment lines and empty lines
  if [[ "$rule" =~ ^# ]] || [[ -z "$rule" ]]; then
    return
  fi

  # Extract the system calls
  local syscalls=$(extract_syscalls "$rule")

  # Extract the action
  local action=$(extract_action "$rule")

  # Print the system calls and action for each rule.
  if [[ -n "$syscalls" ]]; then
    while read -r syscall; do
      echo "System call: $syscall, Action: $action"
    done <<< "$syscalls"
  fi
}

# Main part of the script
echo "Analyzing audit rules in $AUDIT_RULES_FILE..."

# Read the audit rules file line by line
while IFS= read -r line; do
  process_rule "$line"
done < "$AUDIT_RULES_FILE"

echo "Analysis complete."
```