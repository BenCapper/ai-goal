# This script creates a new RoleBinding in a specified namespace,
# adds multiple subjects with specific user and group names,
# sets a specific role name and API group,
# and adds annotations and labels to the RoleBinding.

# Define variables
NAMESPACE="my-namespace"
ROLE_NAME="my-role"
ROLE_APIGROUP="rbac.authorization.k8s.io"
ROLEBINDING_NAME="my-rolebinding"
USER_NAME="john.doe"
GROUP_NAME="my-group"

# Create the RoleBinding manifest
cat <<EOF | kubectl apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: ${ROLEBINDING_NAME}
  namespace: ${NAMESPACE}
  annotations:
    example.com/annotation1: "value1"
    example.com/annotation2: "value2"
  labels:
    app: my-app
    environment: production
subjects:
- kind: User
  name: ${USER_NAME}
  apiGroup: rbac.authorization.k8s.io
- kind: Group
  name: ${GROUP_NAME}
  apiGroup: rbac.authorization.k8s.io
roleRef:
  kind: Role
  name: ${ROLE_NAME}
  apiGroup: ${ROLE_APIGROUP}
EOF

echo "RoleBinding ${ROLEBINDING_NAME} created in namespace ${NAMESPACE}."
```