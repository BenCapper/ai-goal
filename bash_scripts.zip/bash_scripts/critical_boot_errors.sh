# This script retrieves critical messages from the current boot log using journalctl.
# It then extracts specific fields (timestamp and hostname) from each critical message
# and prints them to the standard output.

# Use journalctl to filter log messages by priority (critical) for the current boot.
# Pipe the output to awk to print only the desired fields.

# Usage: ./critical_boot_errors.sh

journalctl --boot -p crit | awk '{print $3, $4, $5, $6}'
```