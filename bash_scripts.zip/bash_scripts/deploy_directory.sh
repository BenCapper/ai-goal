# This script uses Ansible to recursively copy a directory to multiple RHEL hosts.

# Ensure Ansible is installed.
if ! command -v ansible &> /dev/null
then
    echo "Ansible is not installed. Please install it before running this script."
    exit 1
fi

# Define variables
SOURCE_DIR="$1"       # Directory to copy from the Ansible control node.
DESTINATION_DIR="$2"  # Directory to copy to on the target hosts.
INVENTORY_FILE="$3"   # Ansible inventory file.
TARGET_HOSTS="$4"     # Target hosts or Ansible group name (e.g., "webservers" or "host1,host2").
ANSIBLE_USER="${ANSIBLE_USER:-root}" # Ansible user, defaults to root if not set in environment

# Check if the required arguments are provided
if [ -z "$SOURCE_DIR" ] || [ -z "$DESTINATION_DIR" ] || [ -z "$INVENTORY_FILE" ] || [ -z "$TARGET_HOSTS" ]; then
  echo "Usage: $0 <source_directory> <destination_directory> <inventory_file> <target_hosts>"
  exit 1
fi

# Check if the source directory exists
if [ ! -d "$SOURCE_DIR" ]; then
  echo "Error: Source directory '$SOURCE_DIR' does not exist."
  exit 1
fi

# Check if the inventory file exists
if [ ! -f "$INVENTORY_FILE" ]; then
  echo "Error: Inventory file '$INVENTORY_FILE' does not exist."
  exit 1
fi

# Ansible command to copy the directory recursively
ansible $TARGET_HOSTS -i "$INVENTORY_FILE" -m copy -a "src=$SOURCE_DIR dest=$DESTINATION_DIR owner=$ANSIBLE_USER group=$ANSIBLE_USER mode=0755" --become --user $ANSIBLE_USER

# Check the exit code of the Ansible command.
if [ $? -ne 0 ]; then
    echo "Ansible command failed."
    exit 1
fi

echo "Directory '$SOURCE_DIR' copied to '$DESTINATION_DIR' on hosts '$TARGET_HOSTS' successfully."

exit 0
```