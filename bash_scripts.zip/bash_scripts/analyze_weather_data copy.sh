# This script takes a directory of meteorological data files,
# parses the files, and performs basic analysis such as
# calculating the average temperature.  It assumes that each
# data file contains temperature readings in a column labeled
# "temperature" (or that can be specified via an argument).
# The script outputs the average temperature for each file.

# Usage: ./analyze_weather_data.sh <data_directory> [--temp_col <column_name>]

# Function to calculate the average of numbers in a file column
calculate_average() {
  local file="$1"
  local column="$2"

  # Extract the temperature column using awk. Handle potential errors if column doesn't exist.
  local temperatures
  temperatures=$(awk -v col="$column" 'NR>1 {print $col}' "$file" 2>/dev/null) # Skip header row

  if [ -z "$temperatures" ]; then
    echo "Error: Could not find column '$column' in file '$file' or file is empty." >&2
    return 1
  fi


  # Sum the temperatures and count the number of values.
  local sum=0
  local count=0
  while IFS= read -r temp; do
    # Input validation: check if $temp is a number
    if ! [[ "$temp" =~ ^-?[0-9]+(\.[0-9]+)?$ ]]; then
      echo "Warning: Invalid temperature value '$temp' found in '$file', skipping." >&2
      continue # Skip invalid value
    fi
    sum=$(echo "$sum + $temp" | bc)
    count=$((count + 1))
  done <<< "$temperatures"

  # Calculate the average. Avoid division by zero.
  if [ "$count" -gt 0 ]; then
    local average=$(echo "scale=2; $sum / $count" | bc)
    echo "Average temperature for $file: $average"
  else
    echo "Error: No valid temperature data found in $file." >&2
    return 1
  fi
}


# --- Main Script ---

# Set default value for the temperature column
temperature_column="temperature"

# Parse command-line arguments
data_directory="$1"
shift

while [[ $# -gt 0 ]]; do
  case "$1" in
    --temp_col)
      temperature_column="$2"
      shift 2
      ;;
    *)
      echo "Error: Unknown option '$1'" >&2
      exit 1
      ;;
  esac
done

# Check if data directory is provided
if [ -z "$data_directory" ]; then
  echo "Usage: ./analyze_weather_data.sh <data_directory> [--temp_col <column_name>]" >&2
  exit 1
fi

# Check if the data directory exists
if [ ! -d "$data_directory" ]; then
  echo "Error: Directory '$data_directory' does not exist." >&2
  exit 1
fi

# Loop through each file in the directory
find "$data_directory" -type f -print0 | while IFS= read -r -d $'\0' file; do
  # Process each file.  Skip directories and other special file types.
  if [ -f "$file" ]; then
    # Calculate the average temperature for the file.
    calculate_average "$file" "$temperature_column"
    if [ $? -ne 0 ]; then
      echo "Error processing file $file. Skipping." >&2
    fi
  fi
done

exit 0
```