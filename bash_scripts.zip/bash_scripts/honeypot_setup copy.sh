# This script automates the setup and basic management of a honeypot.
# It uses Cowrie as the honeypot and provides basic logging and monitoring.

# Configuration
HONEYPOT_USER="honeypot"
HONEYPOT_DIR="/opt/cowrie"
LOG_DIR="/var/log/cowrie"
COWRIE_VERSION="cowrie" #can specify a tag/branch too

# Ensure script is run with sudo
if [[ $EUID -ne 0 ]]; then
  echo "This script must be run as root."
  exit 1
fi

# Update package lists
echo "Updating package lists..."
apt-get update -y

# Install necessary packages
echo "Installing necessary packages..."
apt-get install -y git python3 python3-venv openssh-server

# Create honeypot user
echo "Creating honeypot user..."
useradd -m -s /bin/bash $HONEYPOT_USER

# Create honeypot directory
echo "Creating honeypot directory..."
mkdir -p $HONEYPOT_DIR
chown $HONEYPOT_USER:$HONEYPOT_USER $HONEYPOT_DIR

# Clone Cowrie repository
echo "Cloning Cowrie repository..."
git clone https://github.com/cowrie/cowrie.git $HONEYPOT_DIR
cd $HONEYPOT_DIR
git checkout $COWRIE_VERSION

# Create virtual environment
echo "Creating virtual environment..."
python3 -m venv env
source env/bin/activate

# Install Cowrie dependencies
echo "Installing Cowrie dependencies..."
pip3 install --upgrade pip
pip3 install --no-cache-dir -r requirements.txt

# Create log directory
echo "Creating log directory..."
mkdir -p $LOG_DIR
chown $HONEYPOT_USER:$HONEYPOT_USER $LOG_DIR

# Copy configuration files (replace with your desired config)
echo "Copying configuration files..."
cp etc/cowrie.cfg.dist etc/cowrie.cfg
#edit etc/cowrie.cfg here to customize
#sed -i 's/option = value/option = new_value/g' etc/cowrie.cfg

#Configure logging
echo "Configuring Logging..."
sed -i "s|output_json = true|output_json = true\nlog_json = $LOG_DIR/cowrie.json.log|g" etc/cowrie.cfg
sed -i "s|output_failed_logins = false|output_failed_logins = true\nfailed_logins_log = $LOG_DIR/cowrie.failed.log|g" etc/cowrie.cfg
sed -i "s|output_tty = false|output_tty = true\ntty_log = $LOG_DIR/cowrie.tty.log|g" etc/cowrie.cfg

# Prepare Cowrie to run as a service (replace /path/to/your/script.sh accordingly)
echo "Creating systemd service file..."
cat <<EOF > /etc/systemd/system/cowrie.service
[Unit]
Description=Cowrie SSH Honeypot
After=network.target

[Service]
User=$HONEYPOT_USER
WorkingDirectory=$HONEYPOT_DIR
ExecStart=$HONEYPOT_DIR/env/bin/python3 bin/cowrie start
Restart=on-failure

[Install]
WantedBy=multi-user.target
EOF

# Reload systemd daemon
echo "Reloading systemd daemon..."
systemctl daemon-reload

# Enable Cowrie service
echo "Enabling Cowrie service..."
systemctl enable cowrie

# Start Cowrie service
echo "Starting Cowrie service..."
systemctl start cowrie

echo "Cowrie honeypot setup complete!"
echo "Logs are located in $LOG_DIR"
echo "Ensure port 22 (or the port you configured) is forwarded to this server."
```