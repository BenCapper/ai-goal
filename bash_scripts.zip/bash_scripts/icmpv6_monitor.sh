# This script monitors the number of ICMPv6 echo requests and replies
# on a specified network interface using tcpdump and awk.
# It requires root privileges to capture packets.

# Set the network interface to monitor
INTERFACE="eth0"  # Change this to the appropriate interface

# Function to capture and count ICMPv6 echo requests and replies
monitor_icmpv6() {
  echo "Monitoring ICMPv6 echo requests and replies on $INTERFACE..."

  # Use tcpdump to capture ICMPv6 packets and awk to count requests and replies
  tcpdump -i "$INTERFACE" -n -vv icmp6 | \
  awk '/ICMP6, echo request/,/ICMP6, echo reply/ {
        if (/ICMP6, echo request/) { req_count++ }
        if (/ICMP6, echo reply/) { rep_count++ }
      }
      END {
        printf "Echo Requests: %d\n", req_count;
        printf "Echo Replies: %d\n", rep_count;
      }'
}

# Main execution
if [[ $(id -u) -ne 0 ]]; then
  echo "This script requires root privileges. Please run with sudo."
  exit 1
fi

monitor_icmpv6
```