# This script executes an Ansible playbook with very verbose output,
# including the raw SSH session details using the -vvvv flag.
# It also redirects stderr to stdout so we can see everything in one stream.

# Check if the playbook file is provided as an argument
if [ -z "$1" ]; then
  echo "Usage: $0 <playbook.yml>"
  exit 1
fi

PLAYBOOK="$1"

# Check if the playbook file exists
if [ ! -f "$PLAYBOOK" ]; then
  echo "Error: Playbook file '$PLAYBOOK' not found."
  exit 1
fi

# Execute the Ansible playbook with maximum verbosity and redirect stderr to stdout
echo "Executing Ansible playbook '$PLAYBOOK' with verbose output including SSH details..."
ansible-playbook -vvvv "$PLAYBOOK" 2>&1

echo "Ansible playbook execution completed."
```