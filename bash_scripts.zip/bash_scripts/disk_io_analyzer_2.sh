# This script analyzes disk I/O queue length of individual processes using pidstat
# and identifies processes causing disk bottlenecks.

# Usage: ./disk_io_analyzer.sh [interval] [count]
# Example: ./disk_io_analyzer.sh 1 10  (reports every 1 second, 10 times)

INTERVAL=${1:-1}  # Default interval is 1 second
COUNT=${2:-5}    # Default count is 5

echo "Analyzing disk I/O queue length using pidstat..."

# pidstat -d -p ALL <interval> <count>
pidstat -d -p ALL $INTERVAL $COUNT | awk '$11 > 0.5 {print "Process ID: " $3 ", Command: " $2 ", Disk Queue Length: " $11}'

echo "Analysis complete."
```