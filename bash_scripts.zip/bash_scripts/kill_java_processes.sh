# This script kills all processes with the name "java".
# It uses the pgrep command to find the process IDs (PIDs) of all java processes.
# Then, it uses the kill command to send a SIGKILL signal (signal 9) to each of those PIDs,
# effectively terminating the processes.

# Find the PIDs of all java processes
java_pids=$(pgrep java)

# Check if any java processes were found
if [ -n "$java_pids" ]; then
  # Kill all java processes
  kill -9 $java_pids
  echo "Killed all java processes."
else
  echo "No java processes found."
fi

# Usage: ./kill_java_processes.sh
```