# This script demonstrates how to use the 'file' command
# with options to display MIME types of files.

# Create sample files
echo "This is a text file." > text_file.txt
echo "<html><body><h1>Hello</h1></body></html>" > index.html

# File usage command:
file --mime-type text_file.txt
file --mime-type index.html
file --mime text_file.txt
file --mime index.html
```