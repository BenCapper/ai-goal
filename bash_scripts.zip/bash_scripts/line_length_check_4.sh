# This script reads lines from a file and checks if the length of each line is less than 3 characters.
# It prints a message if the line length is less than 3.

# File usage: ./line_length_check.sh input.txt

while IFS= read -r line; do
  if [ ${#line} -lt 3 ]; then
    echo "Line \"$line\" has length less than 3."
  fi
done < "$1"
```