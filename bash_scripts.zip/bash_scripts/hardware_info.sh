# This script gathers detailed hardware information on a RHEL machine using lshw or dmidecode.
# It attempts to use lshw first, and if it's not available, it falls back to dmidecode.
# The output is directed to a file named hardware_info.txt.

# Check if lshw is installed
if command -v lshw &> /dev/null
then
  echo "Using lshw to gather hardware information..."
  sudo lshw -html > hardware_info.html
  echo "Hardware information saved to hardware_info.html"
elif command -v dmidecode &> /dev/null
then
  echo "lshw not found. Using dmidecode to gather hardware information..."
  sudo dmidecode > hardware_info.txt
  echo "Hardware information saved to hardware_info.txt"
else
  echo "Neither lshw nor dmidecode found. Please install one of them to gather hardware information."
  exit 1
fi

exit 0
```