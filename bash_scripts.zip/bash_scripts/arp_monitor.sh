# This script monitors the number of ARP requests and replies on a network interface.
# It uses tcpdump to capture ARP packets and awk to count the requests and replies.

#!/bin/bash

interface="$1"
if [ -z "$interface" ]; then
  echo "Usage: $0 <interface>"
  exit 1
fi

# Initialize counters
arp_requests=0
arp_replies=0

# Trap Ctrl+C to exit gracefully
trap "exit 0" INT

echo "Monitoring ARP traffic on interface $interface. Press Ctrl+C to stop."

while true; do
  # Use tcpdump to capture ARP packets on the specified interface
  tcpdump -i "$interface" -nn arp 2>/dev/null | while read line; do
    # Check if the packet is an ARP request
    if [[ "$line" == *"ARP, Request"* ]]; then
      arp_requests=$((arp_requests + 1))
      echo "ARP Request: $line"
    fi
    # Check if the packet is an ARP reply
    if [[ "$line" == *"ARP, Reply"* ]]; then
      arp_replies=$((arp_replies + 1))
      echo "ARP Reply: $line"
    fi
  done
done

# Display the counts after the loop is interrupted
echo "Total ARP Requests: $arp_requests"
echo "Total ARP Replies: $arp_replies"
```