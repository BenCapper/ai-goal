# This script creates a simple YAML file.
# It defines a data structure and writes it to a file.

# Define the data to be written to the YAML file
data='
name: John Doe
age: 30
occupation: Software Engineer
address:
  street: 123 Main St
  city: Anytown
  state: CA
  zip: 91234
skills:
  - Python
  - JavaScript
  - Bash
'

# Specify the output YAML file name
output_file="data.yaml"

# Write the data to the YAML file
echo "$data" > "$output_file"

# Optional: Display a success message
echo "YAML file '$output_file' created successfully."

# Usage: ./create_yaml.sh
```