# This script reads two numerical strings, checks if they are perfect numbers,
# and then checks if their sum is also a perfect number.

# Function to check if a number is a perfect number
is_perfect() {
  local num=$1
  local sum=1

  if [[ "$num" -le 1 ]]; then
    return 1 # Not perfect
  fi

  for (( i=2; i*i<=num; i++ )); do
    if [[ $((num % i)) -eq 0 ]]; then
      sum=$((sum + i + num / i))
    fi
  done

  if [[ "$sum" -eq "$num" ]]; then
    return 0 # Perfect
  else
    return 1 # Not perfect
  fi
}

# Read the two numbers
read -p "Enter the first number: " N1_PERFECT_CHK
read -p "Enter the second number: " N2_PERFECT_CHK

# Check if the inputs are valid numbers
if ! [[ "$N1_PERFECT_CHK" =~ ^[0-9]+$ ]] || ! [[ "$N2_PERFECT_CHK" =~ ^[0-9]+$ ]]; then
  echo "Error: Inputs must be non-negative integers."
  exit 1
fi

# Check if the numbers are perfect
is_perfect "$N1_PERFECT_CHK"
N1_PERFECT=$?

is_perfect "$N2_PERFECT_CHK"
N2_PERFECT=$?

# Calculate the sum
SUM_PERFECT_CHK=$((N1_PERFECT_CHK + N2_PERFECT_CHK))

# Check if the sum is perfect
is_perfect "$SUM_PERFECT_CHK"
SUM_PERFECT=$?

# Check if both numbers and their sum are perfect
if [[ "$N1_PERFECT" -eq 0 ]] && [[ "$N2_PERFECT" -eq 0 ]] && [[ "$SUM_PERFECT" -eq 0 ]]; then
  echo "Both $N1_PERFECT_CHK and $N2_PERFECT_CHK are perfect numbers, and their sum $SUM_PERFECT_CHK is also a perfect number."
elif [[ "$N1_PERFECT" -eq 0 ]] && [[ "$N2_PERFECT" -eq 0 ]]; then
  echo "Both $N1_PERFECT_CHK and $N2_PERFECT_CHK are perfect numbers, but their sum $SUM_PERFECT_CHK is not a perfect number."
else
  echo "At least one of the numbers $N1_PERFECT_CHK and $N2_PERFECT_CHK is not a perfect number, or their sum $SUM_PERFECT_CHK is not a perfect number."
fi

# Usage: bash perfect_number_check.sh
```