# This script uses git to show a summary of the commit history.
# It displays short commit hashes, the first line of the commit message,
# the author name, and the commit age, limited to a specified number of commits.
# The output is sorted by author date in reverse order (most recent first).

# Set the number of commits to display.  Default is 10.
NUM_COMMITS=${1:-10}

# Use git log to get the commit history in the desired format.
git log \
  --pretty=format:"%h %<(15)%an %<(20)%ad %s" \
  --date=relative \
  --max-count="$NUM_COMMITS" \
  --author-date-order
```