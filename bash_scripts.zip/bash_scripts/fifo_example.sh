# This script demonstrates inter-process communication using named pipes (FIFOs).
# It creates two processes: a writer and a reader.
# The writer sends a message through the FIFO, and the reader receives and prints it.

# Create the FIFO if it doesn't exist
FIFO="/tmp/my_fifo"

if [ ! -p "$FIFO" ]; then
  mkfifo "$FIFO"
fi

# Writer process
writer() {
  echo "Hello from writer!" > "$FIFO"
  echo "Writer sent a message."
}

# Reader process
reader() {
  message=$(cat "$FIFO")
  echo "Reader received: $message"
}

# Run the reader in the background
reader &

# Wait a short time to let reader start listening
sleep 0.1

# Run the writer
writer

# Wait for background reader to finish (optional, but good practice)
wait

# Cleanup (remove the FIFO)
rm -f "$FIFO"

# Usage: ./fifo_example.sh
```