# This script lists all templates in all namespaces in OpenShift
# using the oc get template --all-namespaces command.

oc get template --all-namespaces
```