# This script reads the /var/log/secure file, filters lines indicating successful SSH logins ("Accepted password"),
# counts the number of such lines, and prints the total count to the console.

# Usage: ./count_ssh_logins.sh

log_file="/var/log/secure"
search_string="Accepted password"

# Check if the log file exists
if [ ! -f "$log_file" ]; then
  echo "Error: Log file '$log_file' not found."
  exit 1
fi

# Use grep to find lines containing the search string, then wc -l to count the lines
count=$(grep "$search_string" "$log_file" | wc -l)

# Print the total count
echo "Total successful SSH login attempts: $count"
```