# This script simulates a number guessing game.
# The computer generates a random number, and the user has a limited number of attempts to guess it.
# The script provides feedback to the user, such as "Too high", "Too low", or "Correct!".
# It also provides more specific guidance like "much higher", "slightly lower".

# Usage: ./guessing_game.sh

# Generate a random number between 1 and 100
secret_number=$((RANDOM % 100 + 1))

# Set the number of attempts allowed
max_attempts=7
attempts=0

echo "Welcome to the Number Guessing Game!"
echo "I'm thinking of a number between 1 and 100."
echo "You have $max_attempts attempts to guess it."

while [ $attempts -lt $max_attempts ]; do
  # Increment the attempts counter
  attempts=$((attempts + 1))

  # Prompt the user for a guess
  read -p "Attempt $attempts: Enter your guess: " guess

  # Validate the input
  if ! [[ "$guess" =~ ^[0-9]+$ ]]; then
    echo "Invalid input. Please enter a number."
    continue
  fi

  # Check if the guess is correct
  if [ "$guess" -eq "$secret_number" ]; then
    echo "Congratulations! You guessed the number in $attempts attempts."
    exit 0
  elif [ "$guess" -lt "$secret_number" ]; then
    diff=$((secret_number - guess))
    if [ $diff -gt 20 ]; then
      echo "Too low, much lower."
    elif [ $diff -gt 5 ]; then
      echo "Too low, slightly lower."
    else
      echo "Too low."
    fi
  else
    diff=$((guess - secret_number))
    if [ $diff -gt 20 ]; then
      echo "Too high, much higher."
    elif [ $diff -gt 5 ]; then
      echo "Too high, slightly higher."
    else
      echo "Too high."
    fi
  fi
done

# If the user runs out of attempts
echo "You ran out of attempts. The number was $secret_number."

exit 1
# Usage: ./guessing_game.sh
```