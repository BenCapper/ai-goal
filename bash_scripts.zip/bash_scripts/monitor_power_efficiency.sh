# This script monitors the system's power supply efficiency rating.
# It attempts to read power consumption and voltage data from available sources
# and calculates the efficiency. The script requires root privileges to access
# system power information. The output provides the instantaneous efficiency.

# Usage: sudo ./monitor_power_efficiency.sh

# Define a function to read power consumption
read_power() {
    # Attempt to read power consumption from various sources.
    # Prioritize more accurate sensors.

    # 1. IPMI (Intelligent Platform Management Interface) - Most accurate if available
    if command -v ipmitool >/dev/null 2>&1; then
        power_usage=$(ipmitool sdr reading "System Level" | grep "Power Supply" | awk '{print $6}')
        if [[ ! -z "$power_usage" ]]; then
            echo "$power_usage"
            return 0
        fi
    fi

    # 2. /sys/class/power_supply/ - ACPI power supply
    if [[ -d /sys/class/power_supply/ ]]; then
        for supply in /sys/class/power_supply/*; do
            if [[ -f "$supply/power_now" ]]; then
                power_now=$(cat "$supply/power_now")
                # Convert from microwatts to watts
                power_watts=$((power_now / 1000000))
                echo "$power_watts"
                return 0
            fi
        done
    fi

    # 3. Try a generic power consumption sensor
    if [[ -f /sys/class/hwmon/hwmon0/power1_input ]]; then
        power_microwatts=$(cat /sys/class/hwmon/hwmon0/power1_input)
        power_watts=$((power_microwatts / 1000000))
        echo "$power_watts"
        return 0
    fi


    # If no power information is found, return an error
    echo "Error: Unable to determine power consumption." >&2
    return 1
}

# Define a function to read voltage
read_voltage() {
    # Attempt to read voltage from various sources.
    # /sys/class/hwmon/hwmon0/in0_input (example)
    if [[ -d /sys/class/hwmon/ ]]; then
        for hwmon in /sys/class/hwmon/*; do
            if [[ -f "$hwmon/in0_input" ]]; then
                voltage_millivolts=$(cat "$hwmon/in0_input")
                voltage=$(bc -l <<< "scale=3; $voltage_millivolts / 1000")
                echo "$voltage"
                return 0
            fi
        done
    fi

    echo "Error: Unable to determine voltage." >&2
    return 1

}
# Get the current power usage
read_power
if [ $? -ne 0 ]; then
    exit 1
fi
power_watts=$?

# Get the current voltage
read_voltage
if [ $? -ne 0 ]; then
    exit 1
fi

# Calculate the current and theoretical power
current=$(bc -l <<< "scale=3; $voltage_value / $power_value")

# Determine the power supply capacity.  This needs to be adjusted based on actual PSU.
power_supply_capacity=650

# Define efficiency curve (replace with actual PSU values)
# This is a simplified linear example, more complex curves are possible
efficiency() {
    local load=$1
    efficiency_percent=$(bc -l <<< "scale=2; 0.80 + 0.10 * $load")
    if [[ $(echo "$efficiency_percent > 0.90" | bc) -eq 1 ]]; then
        echo 0.90
    else
        echo $efficiency_percent
    fi

}

# Calculate power efficiency
load_percentage=$(bc -l <<< "scale=2; ($power_watts / $power_supply_capacity) ")
efficiency_theoretical=$(efficiency "$load_percentage")

# Calculate power efficiency percentage
efficiency_percentage=$(bc -l <<< "scale=2; 100 * $efficiency_theoretical")

# Display the calculated power efficiency
echo "Current Power Usage: $power_watts W"
echo "Theoretical Power Efficiency: $efficiency_percentage%"
```