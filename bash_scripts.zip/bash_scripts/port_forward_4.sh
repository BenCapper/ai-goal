# This script automates the process of setting up and managing a basic port forwarding configuration using iptables or nftables.
# It allows you to forward traffic from a public port on your server to a private port on a local machine.

# Usage: ./port_forward.sh <public_port> <private_ip> <private_port> [iptables|nftables]

# Check if the user is root
if [[ $EUID -ne 0 ]]; then
  echo "This script must be run as root"
  exit 1
fi

# Define variables
PUBLIC_PORT="$1"
PRIVATE_IP="$2"
PRIVATE_PORT="$3"
FIREWALL_TYPE="${4:-iptables}" # Default to iptables if not specified

# Function to check if a port is valid
is_valid_port() {
  local port=$1
  if ! [[ "$port" =~ ^[0-9]+$ ]]; then
    return 1 # Not a number
  fi
  if [[ "$port" -lt 1 || "$port" -gt 65535 ]]; then
    return 1 # Out of range
  fi
  return 0 # Valid port
}

# Validate input
if [ -z "$PUBLIC_PORT" ] || [ -z "$PRIVATE_IP" ] || [ -z "$PRIVATE_PORT" ]; then
  echo "Usage: ./port_forward.sh <public_port> <private_ip> <private_port> [iptables|nftables]"
  exit 1
fi

if ! is_valid_port "$PUBLIC_PORT"; then
  echo "Invalid public port: $PUBLIC_PORT"
  exit 1
fi

if ! is_valid_port "$PRIVATE_PORT"; then
  echo "Invalid private port: $PRIVATE_PORT"
  exit 1
fi

# Check if iptables or nftables is available
if [[ "$FIREWALL_TYPE" == "iptables" ]]; then
  if ! command -v iptables &> /dev/null; then
    echo "iptables is not installed. Please install it before using this script with iptables."
    exit 1
  fi
elif [[ "$FIREWALL_TYPE" == "nftables" ]]; then
  if ! command -v nft &> /dev/null; then
    echo "nftables is not installed. Please install it before using this script with nftables."
    exit 1
  fi
else
  echo "Invalid firewall type. Must be iptables or nftables."
  exit 1
fi


# Set up port forwarding using iptables
if [[ "$FIREWALL_TYPE" == "iptables" ]]; then
  echo "Setting up port forwarding using iptables..."

  # Enable IP forwarding
  echo 1 > /proc/sys/net/ipv4/ip_forward

  # Set up iptables rules
  iptables -t nat -A PREROUTING -p tcp --dport "$PUBLIC_PORT" -j DNAT --to-destination "$PRIVATE_IP":"$PRIVATE_PORT"
  iptables -t nat -A POSTROUTING -j MASQUERADE
  iptables -A FORWARD -p tcp -d "$PRIVATE_IP" --dport "$PRIVATE_PORT" -j ACCEPT

  echo "Port forwarding set up successfully."
  echo "Forwarding public port $PUBLIC_PORT to $PRIVATE_IP:$PRIVATE_PORT"
fi

# Set up port forwarding using nftables
if [[ "$FIREWALL_TYPE" == "nftables" ]]; then

  echo "Setting up port forwarding using nftables..."

  # Flush existing rules (optional, but recommended for clean slate)
  nft flush ruleset

  # Create a table and chain
  nft add table inet filter
  nft add chain inet filter input { type filter hook input priority 0 ; policy drop ; }
  nft add chain inet filter forward { type filter hook forward priority 0 ; policy drop ; }
  nft add chain inet nat prerouting { type nat hook prerouting priority 0 ; policy accept ; }
  nft add chain inet nat postrouting { type nat hook postrouting priority 0 ; policy accept ; }

  # Allow established and related connections
  nft add rule inet filter input ct state { established, related } accept
  nft add rule inet filter forward ct state { established, related } accept

  # Allow SSH (example, adjust as needed)
  nft add rule inet filter input tcp dport 22 accept

  # Add DNAT rule for port forwarding
  nft add rule inet nat prerouting tcp dport "$PUBLIC_PORT" dnat to "$PRIVATE_IP":"$PRIVATE_PORT"

  # Add masquerade rule for outgoing traffic (important for the internal network to reach the outside)
  nft add rule inet nat postrouting oifname eth0 masquerade #Replace eth0 with your outbound interface

  # Add forwarding rule (allow traffic to the internal server)
  nft add rule inet filter forward tcp daddr "$PRIVATE_IP" dport "$PRIVATE_PORT" accept

  # Enable IP forwarding (if not already enabled)
  echo 1 > /proc/sys/net/ipv4/ip_forward

  echo "Port forwarding set up successfully."
  echo "Forwarding public port $PUBLIC_PORT to $PRIVATE_IP:$PRIVATE_PORT using nftables."

fi

# Save firewall rules (iptables only, nftables is typically persistent by default on most systems)
if [[ "$FIREWALL_TYPE" == "iptables" ]]; then
  if command -v iptables-save &> /dev/null; then
    iptables-save > /etc/iptables/rules.v4
    echo "iptables rules saved to /etc/iptables/rules.v4"
  else
    echo "Warning: iptables-save not found.  iptables rules will not persist after reboot."
  fi
fi

exit 0
```