# This script takes a directory path and a number of days as input.
# It removes all files in the specified directory that are hidden (i.e., their names start with a dot)
# and that are older than the specified number of days.

# Usage: ./remove_old_hidden.sh <directory> <number_of_days>

# Check if the correct number of arguments is provided.
if [ $# -ne 2 ]; then
  echo "Usage: $0 <directory> <number_of_days>"
  exit 1
fi

# Assign the directory and number of days from the command-line arguments.
directory="$1"
days="$2"

# Check if the directory exists.
if [ ! -d "$directory" ]; then
  echo "Error: Directory '$directory' does not exist."
  exit 1
fi

# Check if the number of days is a valid integer.
if ! [[ "$days" =~ ^[0-9]+$ ]]; then
  echo "Error: Number of days '$days' is not a valid integer."
  exit 1
fi

# Find all hidden files in the directory that are older than the specified number of days.
find "$directory" -maxdepth 1 -type f -name ".*" -atime +"$days" -print0 |
  while IFS= read -r -d $'\0' file; do
    # Remove the file.
    rm -f "$file"
    echo "Removed: $file"
  done

echo "Done."
exit 0
```