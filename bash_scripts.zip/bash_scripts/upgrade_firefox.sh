# This script upgrades only the firefox package using pacman on an Arch Linux system.
# It first updates the package database and then performs the upgrade.

# Update the package database
sudo pacman -Sy

# Upgrade only the firefox package
sudo pacman -S firefox
```