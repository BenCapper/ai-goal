# This script automates the installation and configuration of a system performance
# monitoring tool (sar from the sysstat package).  It installs the sysstat package,
# enables data collection and configures some basic settings.

# Check if the script is run as root
if [[ $EUID -ne 0 ]]; then
  echo "This script must be run as root"
  exit 1
fi

# Update package lists
echo "Updating package lists..."
apt-get update -y

# Install sysstat package
echo "Installing sysstat..."
apt-get install -y sysstat

# Enable data collection
echo "Enabling data collection..."
sed -i 's/ENABLED="false"/ENABLED="true"/g' /etc/default/sysstat

# Restart the sysstat service to apply the changes
echo "Restarting sysstat service..."
systemctl restart sysstat

# Check if the service is running
echo "Checking sysstat service status..."
systemctl status sysstat

# Configure sar to collect data every 5 minutes
echo "Configuring sar to collect data every 5 minutes..."
sed -i 's/SA1_INTERVAL=600/SA1_INTERVAL=300/g' /etc/default/sysstat

# Restart sysstat again to apply the interval change
echo "Restarting sysstat service after changing interval..."
systemctl restart sysstat

echo "Performance monitoring tool (sar) installed and configured."
echo "Data will be collected every 5 minutes.  Data is located in /var/log/sa."
echo "Use 'sar -u' to check CPU usage, 'sar -r' for memory usage, etc."
```