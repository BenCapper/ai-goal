# This script uses awk to calculate the exponentiation of two specific fields in a file.
# It takes the input file as an argument.  It raises field 1 to the power of field 2
# and prints the result to standard output, along with the original line.

# Check if the input file is provided as an argument.
if [ $# -ne 1 ]; then
  echo "Usage: $0 <input_file>"
  exit 1
fi

input_file="$1"

# Check if the input file exists.
if [ ! -f "$input_file" ]; then
  echo "Error: Input file '$input_file' not found."
  exit 1
fi

# Use awk to read the input file, calculate the exponentiation of field 1 to the power of field 2
# and print the original line followed by the result.
awk '{printf "%s %.6f\n", $0, $1^$2}' "$input_file"
```