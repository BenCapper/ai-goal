# This script takes a directory of video files as input.
# It generates a video storyboard for each video in the directory.
# The storyboard is a grid of thumbnails extracted from the video.
# Requires: ffmpeg, imagemagick

# Usage: ./storyboard_generator.sh <directory> <output_directory> <columns> <rows>

# Example: ./storyboard_generator.sh videos storyboards 4 3

# Check if ffmpeg is installed
if ! command -v ffmpeg &> /dev/null
then
    echo "ffmpeg could not be found. Please install ffmpeg."
    exit 1
fi

# Check if convert (imagemagick) is installed
if ! command -v convert &> /dev/null
then
    echo "ImageMagick's convert command could not be found. Please install ImageMagick."
    exit 1
fi

# Set default values
INPUT_DIR="${1:-.}" # Current directory if no input dir
OUTPUT_DIR="${2:-storyboards}" # storyboards dir if no output dir
COLUMNS="${3:-4}" # 4 columns if not specified
ROWS="${4:-3}" # 3 rows if not specified

# Create output directory if it doesn't exist
mkdir -p "$OUTPUT_DIR"

# Function to generate a storyboard for a single video
generate_storyboard() {
  VIDEO_FILE="$1"
  FILENAME=$(basename "$VIDEO_FILE")
  FILENAME_NO_EXT="${FILENAME%.*}"
  OUTPUT_IMAGE="$OUTPUT_DIR/$FILENAME_NO_EXT.jpg"

  # Get video duration
  DURATION=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "$VIDEO_FILE")

  # Calculate the number of frames to extract
  NUM_FRAMES=$((COLUMNS * ROWS))

  # Calculate the time interval between frames
  INTERVAL=$(echo "$DURATION / $NUM_FRAMES" | bc)

  # Create the frame extraction command
  FRAMES_CMD=""
  for ((i=0; i<$NUM_FRAMES; i++)); do
      TIME=$(echo "$i * $INTERVAL" | bc)
      FRAMES_CMD+="-ss $TIME -vframes 1 tmp_$i.png "
  done

  # Extract the frames
  ffmpeg -y -i "$VIDEO_FILE" $FRAMES_CMD

  # Check if ffmpeg succeeded
  if [ $? -ne 0 ]; then
    echo "Error: ffmpeg failed to extract frames from $VIDEO_FILE"
    return 1
  fi

  # Create the montage command
  MONTAGE_CMD="montage tmp_*.png -tile ${COLUMNS}x${ROWS} -geometry +0+0 \"$OUTPUT_IMAGE\""

  # Create the storyboard using montage
  eval $MONTAGE_CMD

  # Check if montage succeeded
  if [ $? -ne 0 ]; then
    echo "Error: montage failed to create the storyboard for $VIDEO_FILE"
    # Remove the temporary files
    rm -f tmp_*.png
    return 1
  fi

  # Remove the temporary files
  rm -f tmp_*.png

  echo "Storyboard created: $OUTPUT_IMAGE"
  return 0
}

# Loop through all video files in the input directory
find "$INPUT_DIR" -type f \( -name "*.mp4" -o -name "*.avi" -o -name "*.mov" -o -name "*.mkv" \) -print0 | while IFS= read -r -d $'\0' VIDEO_FILE; do
  generate_storyboard "$VIDEO_FILE"
done

echo "Storyboards generated successfully in $OUTPUT_DIR"

exit 0
```