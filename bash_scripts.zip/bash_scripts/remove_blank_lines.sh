# This script reads a plain text file
# and removes all blank lines,
# writing the result to a new file.

# Usage: ./remove_blank_lines.sh input.txt output.txt

INPUT="$1"
OUTPUT="$2"

if [ -z "$INPUT" ] || [ -z "$OUTPUT" ]; then
  echo "Usage: ./remove_blank_lines.sh input.txt output.txt"
  exit 1
fi

grep . "$INPUT" > "$OUTPUT"
```