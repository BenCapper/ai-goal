# This script reads numbers from standard input until the user enters 0.
# It calculates the sum of positive numbers entered by the user.
# Usage: ./sum_positive.sh

sum=0

while true
do
  read -p "Enter a number (0 to quit): " INPUT_NUM

  if [[ $INPUT_NUM -eq 0 ]]; then
    break
  fi

  if [[ $INPUT_NUM -gt 0 ]]; then
    sum=$((sum + INPUT_NUM))
  fi
done

echo "The sum of positive numbers is: $sum"
```