# This script reads lines from a file using a while loop.
# It checks if each line has a length greater than 0.
# If the line length is greater than 0, it prints the line.

# Usage: ./process_lines.sh input.txt

while IFS= read -r line; do
  if [ ${#line} -gt 0 ]; then
    echo "$line"
  fi
done < "$1"
```