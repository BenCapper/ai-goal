# This script demonstrates how to use the strace utility to trace memory mapping system calls.
# It focuses on tracing calls like mmap, munmap, mprotect, etc. to observe how a program manages its memory.

# Usage: ./trace_mmap.sh <command_to_trace>

# Check if a command is provided as an argument
if [ $# -eq 0 ]; then
  echo "Usage: ./trace_mmap.sh <command_to_trace>"
  exit 1
fi

# Use strace to trace memory mapping system calls
strace -e trace=memory "$@"

# Example Usage:
# ./trace_mmap.sh ls -l
# ./trace_mmap.sh cat /etc/passwd
# ./trace_mmap.sh ./a.out # Assuming a.out is a compiled executable

```