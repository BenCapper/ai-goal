# This script validates a password based on length and character requirements.
# It checks if the password length is between 6 and 12 characters, and if it contains
# at least one uppercase letter, one lowercase letter, one digit, and one special symbol.
#
# Usage: ./password_validator.sh <password>

# Check if a password is provided as an argument
if [ $# -ne 1 ]; then
  echo "Error: Please provide a password as an argument."
  exit 1
fi

password="$1"
length=${#password}

# Check password length
if [ $length -ge 6 ]; then
  if [ $length -le 12 ]; then
    # Check for character requirements
    uppercase=$(echo "$password" | grep -o "[A-Z]" | wc -l)
    lowercase=$(echo "$password" | grep -o "[a-z]" | wc -l)
    digit=$(echo "$password" | grep -o "[0-9]" | wc -l)
    special=$(echo "$password" | grep -o "[^a-zA-Z0-9]" | wc -l)

    if [ "$uppercase" -gt 0 ]; then
      if [ "$lowercase" -gt 0 ]; then
        if [ "$digit" -gt 0 ]; then
          if [ "$special" -gt 0 ]; then
            echo "Password is valid."
          else
            echo "Password must contain at least one special symbol."
          fi
        else
          echo "Password must contain at least one digit."
        fi
      else
        echo "Password must contain at least one lowercase letter."
      fi
    else
      echo "Password must contain at least one uppercase letter."
    fi
  else
    echo "Password length must be at most 12 characters."
  fi
else
  echo "Password length must be at least 6 characters."
fi
# Usage: ./password_validator.sh <password>
```