# This script uses ansible-galaxy to list all outdated Ansible roles.

# Check if ansible-galaxy is installed.
if ! command -v ansible-galaxy &> /dev/null; then
  echo "ansible-galaxy is not installed. Please install it."
  exit 1
fi

# Run ansible-galaxy role list and filter for outdated roles
ansible-galaxy role list --format yaml | yq '. | to_entries | .[] | select(.value.version != .value.latest) | .key'
```