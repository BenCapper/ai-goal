# This script searches for a specific file within the files installed by packages.
# It iterates through the installed packages, extracts the list of files belonging to each package,
# and then checks if the specified file is present in that list.

# Usage: ./find_file_in_packages.sh <file_to_search>

if [ $# -ne 1 ]; then
  echo "Usage: $0 <file_to_search>"
  exit 1
fi

file_to_search="$1"

# Get a list of all installed packages
packages=$(dpkg --get-selections | awk '{print $1}')

# Iterate through the packages
for package in $packages; do
  # Get the list of files belonging to the package
  files=$(dpkg -L "$package" 2>/dev/null)

  # Check if the file is present in the package's files
  if echo "$files" | grep -q "$file_to_search"; then
    echo "File '$file_to_search' found in package: $package"
  fi
done
```