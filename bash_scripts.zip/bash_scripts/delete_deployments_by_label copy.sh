# This script deletes all deployments matching a specified label selector
# across all namespaces in an OpenShift cluster using the oc command-line tool.

# Check if a label selector is provided as a command-line argument.
if [ -z "$1" ]; then
  echo "Usage: $0 <label_selector>"
  echo "Example: $0 app=my-app"
  exit 1
fi

# Store the label selector provided as the first argument.
LABEL_SELECTOR="$1"

# Delete deployments matching the label selector in all namespaces.
oc delete deployment -l "$LABEL_SELECTOR" --all-namespaces

# Check the exit code of the oc command.
if [ $? -eq 0 ]; then
  echo "Successfully deleted deployments with label selector: $LABEL_SELECTOR in all namespaces."
else
  echo "Error deleting deployments. Please check the label selector and your OpenShift credentials."
  exit 1
fi
```