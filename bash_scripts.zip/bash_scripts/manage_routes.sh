# This script manages network routes on a RHEL system, allowing adding and deleting routes.
# Usage: sudo ./manage_routes.sh <add|delete> <destination_network> <gateway_ip> <interface>

# Check if the script is run with sudo
if [[ $EUID -ne 0 ]]; then
  echo "This script must be run as root (sudo)."
  exit 1
fi

# Check the number of arguments
if [[ $# -lt 4 ]]; then
  echo "Usage: sudo ./manage_routes.sh <add|delete> <destination_network> <gateway_ip> <interface>"
  exit 1
fi

ACTION="$1"
DESTINATION="$2"
GATEWAY="$3"
INTERFACE="$4"

# Function to add a route
add_route() {
  ip route add "$DESTINATION" via "$GATEWAY" dev "$INTERFACE"
  if [[ $? -eq 0 ]]; then
    echo "Route added successfully: $DESTINATION via $GATEWAY dev $INTERFACE"
  else
    echo "Failed to add route: $DESTINATION via $GATEWAY dev $INTERFACE"
  fi
}

# Function to delete a route
delete_route() {
  ip route delete "$DESTINATION" via "$GATEWAY" dev "$INTERFACE"
  if [[ $? -eq 0 ]]; then
    echo "Route deleted successfully: $DESTINATION via $GATEWAY dev $INTERFACE"
  else
    echo "Failed to delete route: $DESTINATION via $GATEWAY dev $INTERFACE"
  fi
}

# Main logic
case "$ACTION" in
  add)
    add_route
    ;;
  delete)
    delete_route
    ;;
  *)
    echo "Invalid action.  Use 'add' or 'delete'."
    exit 1
    ;;
esac

exit 0
# Usage: sudo ./manage_routes.sh <add|delete> <destination_network> <gateway_ip> <interface>
```