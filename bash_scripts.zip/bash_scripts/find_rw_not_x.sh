# This script iterates through the files in a directory and
# prints the names of files that are readable and writable
# by the owner, but not executable.

# Usage: ./find_rw_not_x.sh <directory>

DIRECTORY="$1"

if [ -z "$DIRECTORY" ]; then
  echo "Usage: ./find_rw_not_x.sh <directory>"
  exit 1
fi

if [ ! -d "$DIRECTORY" ]; then
  echo "Error: '$DIRECTORY' is not a directory."
  exit 1
fi

for file in "$DIRECTORY"/*; do
  if [ -f "$file" ]; then
    if [ -o -r "$file" ] && [ -o -w "$file" ] && [ ! -o -x "$file" ]; then
      echo "$file"
    fi
  fi
done

# ./find_rw_not_x.sh /path/to/directory
```