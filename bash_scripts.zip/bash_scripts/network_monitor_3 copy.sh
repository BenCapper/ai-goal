#
# This script monitors network traffic, logs packets, calculates bandwidth usage, and triggers alerts.
# It captures packet details (size, protocol, source/destination IP/port) and logs them with timestamps.
# It calculates average bandwidth usage over a specified interval and sends an alert if it exceeds a threshold.

# Configuration
LOG_FILE="/var/log/network_monitor.log"
BANDWIDTH_THRESHOLD_MBPS=10 # Threshold in Mbps
MONITOR_INTERVAL=60 # Monitoring interval in seconds
INTERFACE="eth0" # Interface to monitor

# Function to log messages with timestamps
log() {
  timestamp=$(date +'%Y-%m-%d %H:%M:%S')
  echo "$timestamp: $1" >> "$LOG_FILE"
  echo "$timestamp: $1" # Also output to console for immediate visibility
}

# Function to capture and log packet information using tcpdump
capture_packets() {
  log "Starting packet capture on interface $INTERFACE..."
  tcpdump -i "$INTERFACE" -nn -q | while read -r line; do
    timestamp=$(date +'%Y-%m-%d %H:%M:%S')
    packet_size=$(echo "$line" | awk '{print length($0)}')

    # Extract protocol (TCP or UDP)
    protocol=$(echo "$line" | awk '{if ($0 ~ /TCP/) print "TCP"; else if ($0 ~ /UDP/) print "UDP"; else print "Other";}')

    # Extract source and destination IP addresses and ports for TCP and UDP
    if [[ "$protocol" == "TCP" ]]; then
      src_ip=$(echo "$line" | awk '{split($1,a,"."); print a[1]"."a[2]"."a[3]"."a[4]}')
      src_port=$(echo "$line" | awk '{split($1,a,"."); split(a[5],b,":"); print b[1]}')
      dst_ip=$(echo "$line" | awk '{split($3,a,"."); print a[1]"."a[2]"."a[3]"."a[4]}')
      dst_port=$(echo "$line" | awk '{split($3,a,"."); split(a[5],b,":"); print b[1]}')
    elif [[ "$protocol" == "UDP" ]]; then
      src_ip=$(echo "$line" | awk '{split($1,a,"."); print a[1]"."a[2]"."a[3]"."a[4]}')
      src_port=$(echo "$line" | awk '{split($1,a,"."); split(a[5],b,":"); print b[1]}')
      dst_ip=$(echo "$line" | awk '{split($3,a,"."); print a[1]"."a[2]"."a[3]"."a[4]}')
      dst_port=$(echo "$line" | awk '{split($3,a,"."); split(a[5],b,":"); print b[1]}')

    else
       src_ip="N/A"
       src_port="N/A"
       dst_ip="N/A"
       dst_port="N/A"

    fi


    log "Packet: Size=$packet_size bytes, Protocol=$protocol, SrcIP=$src_ip, SrcPort=$src_port, DstIP=$dst_ip, DstPort=$dst_port"
  done
}

# Function to calculate bandwidth usage
calculate_bandwidth() {
  local rx_bytes_start=$(cat /sys/class/net/"$INTERFACE"/statistics/rx_bytes)
  local tx_bytes_start=$(cat /sys/class/net/"$INTERFACE"/statistics/tx_bytes)

  sleep "$MONITOR_INTERVAL"

  local rx_bytes_end=$(cat /sys/class/net/"$INTERFACE"/statistics/rx_bytes)
  local tx_bytes_end=$(cat /sys/class/net/"$INTERFACE"/statistics/tx_bytes)

  local rx_bytes_diff=$((rx_bytes_end - rx_bytes_start))
  local tx_bytes_diff=$((tx_bytes_end - tx_bytes_start))
  local total_bytes_diff=$((rx_bytes_diff + tx_bytes_diff))

  local bandwidth_bps=$((total_bytes_diff * 8 / MONITOR_INTERVAL)) # bits per second
  local bandwidth_mbps=$((bandwidth_bps / 1000000)) # Mbps

  log "Bandwidth Usage: $bandwidth_mbps Mbps"

  # Check if bandwidth exceeds threshold
  if (( $(echo "$bandwidth_mbps > $BANDWIDTH_THRESHOLD_MBPS" | bc -l) )); then
    log "ALERT: Bandwidth usage exceeds threshold of $BANDWIDTH_THRESHOLD_MBPS Mbps!"
    # Add your alerting mechanism here (e.g., send an email)
    echo "ALERT: Bandwidth usage exceeds threshold of $BANDWIDTH_THRESHOLD_MBPS Mbps!" | mail -s "Network Bandwidth Alert" your_email@example.com
  fi
}


# Main loop
while true; do
  # Run packet capture in the background
  capture_packets &
  packet_capture_pid=$!

  # Calculate bandwidth usage
  calculate_bandwidth

  # Kill background tcpdump process.
  kill $packet_capture_pid

  # Wait for a while before the next iteration
  sleep "$MONITOR_INTERVAL"
done

# Usage: ./network_monitor.sh
```