# This script uses awk to print lines from a file where a specific field matches a regular expression.
# It replaces the matched part of the field with a specified string and prints the modified line.

# Check if the correct number of arguments is provided
if [ $# -ne 5 ]; then
  echo "Usage: $0 <file> <field_number> <regex> <replacement> <output_file>"
  echo "  <file>: Input file to process."
  echo "  <field_number>: The field number to check (1-based)."
  echo "  <regex>: The regular expression to match."
  echo "  <replacement>: The string to replace the matched part with."
  echo "  <output_file>: The file to write the output to. If it's '-' then output to standard out."
  exit 1
fi

# Assign arguments to variables
file="$1"
field_number="$2"
regex="$3"
replacement="$4"
output_file="$5"


# Check if the input file exists
if [ ! -f "$file" ]; then
  echo "Error: File '$file' not found."
  exit 1
fi

# Construct the awk command
awk_command="awk '\$${field_number} ~ /$regex/ { gsub(/$regex/, \"$replacement\", \$${field_number}); print } \$${field_number} !~ /$regex/ {print}' \"$file\""

# Execute the awk command and redirect output to a file
if [ "$output_file" = "-" ]; then
  eval "$awk_command"
else
  eval "$awk_command" > "$output_file"
fi
```