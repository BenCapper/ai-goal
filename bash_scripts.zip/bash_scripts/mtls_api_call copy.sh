#
# This script uses curl to interact with an API endpoint that requires mutual TLS authentication.
# It specifies the client certificate, private key, CA certificate, TLS version, and verifies the server certificate.

# Set the API endpoint URL
API_URL="https://example.com/api/endpoint"

# Set the paths to the client certificate, private key, and CA certificate
CLIENT_CERT="/path/to/client.crt"
CLIENT_KEY="/path/to/client.key"
CA_CERT="/path/to/ca.crt"

# Set the TLS version to use (e.g., TLSv1.2)
TLS_VERSION="TLSv1.2"

# Perform the API call using curl with mutual TLS authentication and TLS version specification
curl \
  --cert "${CLIENT_CERT}" \
  --key "${CLIENT_KEY}" \
  --cacert "${CA_CERT}" \
  --tlsv1.2 \
  --verbose \
  "${API_URL}"
```