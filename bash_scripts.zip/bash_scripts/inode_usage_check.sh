# This script checks inode usage on all mounted partitions.
# It uses df -i to get inode usage information,
# grep to filter for partitions with >90% inode usage,
# and awk to print the mount points of those partitions.

# Get inode usage, filter for >90%, and print the mount point.
df -i | grep -v 'Use%' | awk '{if($5 + 0 > 90) print $6}'
# Usage: bash inode_usage_check.sh
```