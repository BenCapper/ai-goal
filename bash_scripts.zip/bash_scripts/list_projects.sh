# This script lists all projects in an OpenShift cluster.
# It uses the 'oc' command-line tool to retrieve the list of projects
# and then prints the names of the projects.

# Usage: ./list_projects.sh

# Check if the 'oc' command is available
if ! command -v oc &> /dev/null; then
  echo "Error: 'oc' command not found. Please install the OpenShift CLI."
  exit 1
fi

# Get the list of projects
projects=$(oc get projects -o name)

# Check if any projects were found
if [ -z "$projects" ]; then
  echo "No projects found in the cluster."
  exit 0
fi

# Print the list of projects
echo "Projects in the OpenShift cluster:"
for project in $projects; do
  # Extract the project name from the "project.openshift.io/<project_name>" format
  project_name=$(echo "$project" | cut -d'/' -f2)
  echo "$project_name"
done

exit 0
```