#
# This script monitors the number of TCP retransmissions on a specified network interface.
# It uses `netstat -s` to get the TCP statistics and `grep` to find the number of retransmissions.
# It then compares the current number of retransmissions with the previous number, printing the difference.
# Requires root privileges.

INTERFACE="eth0"  # Change this to the network interface you want to monitor
SLEEP_INTERVAL=5   # Time in seconds between checks

PREVIOUS_RETRANSMITS=0

while true; do
  # Get the current number of TCP retransmissions
  CURRENT_RETRANSMITS=$(netstat -s | grep "segments retransmitted" | awk '{print $1}')

  # Check if we successfully got the retransmission count
  if [ -z "$CURRENT_RETRANSMITS" ]; then
    echo "Error: Could not retrieve TCP retransmission count. Check interface name and netstat output."
    exit 1
  fi

  # Calculate the difference
  if [ "$PREVIOUS_RETRANSMITS" -eq 0 ]; then
    DIFFERENCE=0
  else
    DIFFERENCE=$((CURRENT_RETRANSMITS - PREVIOUS_RETRANSMITS))
  fi

  # Print the results
  echo "$(date): Interface $INTERFACE - Retransmissions: $CURRENT_RETRANSMITS, Difference: $DIFFERENCE"

  # Update the previous retransmission count
  PREVIOUS_RETRANSMITS=$CURRENT_RETRANSMITS

  # Wait before the next check
  sleep $SLEEP_INTERVAL
done
```