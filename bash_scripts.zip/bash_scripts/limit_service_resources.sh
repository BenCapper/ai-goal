# This script sets resource limits for a specified systemd service using systemctl.
# It modifies the service's unit file to include resource limit directives.

# Usage: sudo ./limit_service_resources.sh <service_name> <limit_type> <limit_value>
# Example: sudo ./limit_service_resources.sh myapp CPUQuota 50%
# Example: sudo ./limit_service_resources.sh myapp MemoryMax 1G

# Check if the script is run with root privileges.
if [[ $EUID -ne 0 ]]; then
  echo "This script must be run with sudo."
  exit 1
fi

# Check if the correct number of arguments are provided.
if [[ $# -ne 3 ]]; then
  echo "Usage: sudo ./limit_service_resources.sh <service_name> <limit_type> <limit_value>"
  exit 1
fi

# Assign arguments to variables.
service_name="$1"
limit_type="$2"
limit_value="$3"

# Validate service_name
if ! systemctl is-active "$service_name" &> /dev/null; then
    echo "Error: Service '$service_name' not found or inactive."
    exit 1
fi

# Validate limit_type: add more as needed.
case "$limit_type" in
    CPUQuota|MemoryMax|TasksMax)
        ;;
    *)
        echo "Error: Invalid limit type '$limit_type'."
        echo "Supported limit types: CPUQuota, MemoryMax, TasksMax"
        exit 1
        ;;
esac

# Create a directory for overrides (if it doesn't exist)
mkdir -p "/etc/systemd/system/${service_name}.service.d"

# Create the override file.
override_file="/etc/systemd/system/${service_name}.service.d/override.conf"

# Write the override configuration to the file.
cat > "$override_file" <<EOF
[Service]
${limit_type}=${limit_value}
EOF

# Reload the systemd daemon to apply the changes.
systemctl daemon-reload

# Restart the service to apply the new limits.
systemctl restart "$service_name"

echo "Resource limit '$limit_type=$limit_value' set for service '$service_name'."
echo "Please check with 'systemctl show $service_name' to confirm settings."

#file usage: sudo ./limit_service_resources.sh <service_name> <limit_type> <limit_value>
```