# This script uses screen to send a command to a specific detached session and then quits the current session.

# Set the name of the screen session to target.
SESSION_NAME="my_session"

# Set the command to send to the screen session.
COMMAND_TO_SEND="echo 'Hello from remote!'"

# Send the command to the detached screen session.
screen -S "$SESSION_NAME" -X stuff "$COMMAND_TO_SEND^M"

# Detach the current screen session (if running inside one) or exit the shell.
exit
```