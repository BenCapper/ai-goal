# This script reads two strings, TEXT_A and TEXT_B, from the user.
# It then uses an if statement with string comparison and the > operator
# to check if TEXT_A comes after TEXT_B lexicographically.
# It prints a message indicating whether TEXT_A is greater than TEXT_B.

# Read the first string into TEXT_A
read -p "Enter the first string (TEXT_A): " TEXT_A

# Read the second string into TEXT_B
read -p "Enter the second string (TEXT_B): " TEXT_B

# Compare the strings using the > operator
if [[ "$TEXT_A" > "$TEXT_B" ]]; then
  echo "TEXT_A ($TEXT_A) comes after TEXT_B ($TEXT_B) lexicographically."
else
  echo "TEXT_A ($TEXT_A) does not come after TEXT_B ($TEXT_B) lexicographically."
fi

# Usage: ./compare_strings.sh
```