# This script monitors the iSCSI initiator status and reports any changes.
# It checks if iSCSI services are running and if the specified targets are logged in.
# Usage: ./iscsi_monitor.sh <target_iqn1> [<target_iqn2> ...]

# Configuration
ISCSI_SERVICES="iscsid iscsi"  # Services to check
LOG_FILE="/var/log/iscsi_monitor.log"
TARGETS=("$@") # Targets to monitor from command line arguments

# Function to check if a service is running
is_service_running() {
  service="$1"
  if systemctl is-active --quiet "$service"; then
    return 0  # Service is running
  else
    return 1  # Service is not running
  fi
}

# Function to check if a target is logged in
is_target_logged_in() {
  target_iqn="$1"
  iscsiadm -m session | grep "$target_iqn" > /dev/null 2>&1
  return $?
}

# Function to log messages
log_message() {
  message="$1"
  timestamp=$(date "+%Y-%m-%d %H:%M:%S")
  echo "$timestamp: $message" >> "$LOG_FILE"
  echo "$timestamp: $message" # Also print to stdout for immediate feedback.
}

# Main script logic

log_message "Starting iSCSI monitoring..."

# Check if iSCSI services are running
for service in $ISCSI_SERVICES; do
  if is_service_running "$service"; then
    log_message "iSCSI service '$service' is running."
  else
    log_message "ERROR: iSCSI service '$service' is NOT running. Please start it."
    # Consider adding code to automatically restart the service if desired:
    # sudo systemctl start "$service"
  fi
done

# Check if specified targets are logged in
if [[ ${#TARGETS[@]} -eq 0 ]]; then
   log_message "WARNING: No target IQNs specified.  Please specify targets to monitor as arguments to the script."
else
    for target in "${TARGETS[@]}"; do
    if is_target_logged_in "$target"; then
        log_message "Target '$target' is logged in."
    else
        log_message "ERROR: Target '$target' is NOT logged in."
        # Consider adding code to attempt login automatically. Example below (uncomment to enable):
        # iscsiadm -m discovery -t st -p <portal_ip>:<portal_port> # Replace <portal_ip>:<portal_port>
        # iscsiadm -m node -T "$target" -l
    fi
    done
fi


log_message "iSCSI monitoring complete."

# end of script
# Usage: ./iscsi_monitor.sh iqn.2023-10.com.example:target1 iqn.2023-10.com.example:target2
```