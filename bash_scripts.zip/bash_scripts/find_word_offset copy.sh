# This script uses grep to find lines containing a specific word
# and prints the filename and the byte offset of the match.

# The word to search for
WORD="example"

# Use grep with the -b (byte offset) and -H (filename) options
grep -b -H "$WORD" *
```