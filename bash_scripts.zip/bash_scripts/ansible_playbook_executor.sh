#
# This script executes an Ansible playbook, checks for failures and unreachable hosts,
# and sends an email notification if the failure rate exceeds a specified threshold.

# Configuration
PLAYBOOK="your_playbook.yml" # Replace with your playbook's name
INVENTORY="your_inventory" # Replace with your inventory file
FAILURE_THRESHOLD=10        # Maximum allowed failure percentage
EMAIL_RECIPIENT="your_email@example.com" # Replace with your email
EMAIL_SUBJECT="Ansible Playbook Execution Report"

# Variables
TIMESTAMP=$(date +%Y-%m-%d_%H-%M-%S)
LOG_FILE="ansible_log_${TIMESTAMP}.txt"
ERROR_MESSAGE=""
AFFECTED_HOSTS=""
TOTAL_HOSTS=0
FAILED_HOSTS=0
UNREACHABLE_HOSTS=0


# Execute the Ansible playbook and capture output
echo "Executing Ansible playbook: $PLAYBOOK"
ansible-playbook -i "$INVENTORY" "$PLAYBOOK" 2>&1 | tee "$LOG_FILE"

# Analyze the log file for failures and unreachable hosts
FAILED_HOSTS=$(grep -c "failed=[1-9][0-9]*" "$LOG_FILE")
UNREACHABLE_HOSTS=$(grep -c "unreachable=[1-9][0-9]*" "$LOG_FILE")

# Extract the number of total hosts from the inventory (assuming hosts are listed directly in the inventory file)
TOTAL_HOSTS=$(wc -l < "$INVENTORY" | awk '{print $1}')


# Calculate the failure percentage
TOTAL_FAILED=$((FAILED_HOSTS + UNREACHABLE_HOSTS))
FAILURE_PERCENTAGE=$(echo "scale=2; $TOTAL_FAILED / $TOTAL_HOSTS * 100" | bc)

echo "Total Hosts: $TOTAL_HOSTS"
echo "Failed Hosts: $FAILED_HOSTS"
echo "Unreachable Hosts: $UNREACHABLE_HOSTS"
echo "Failure Percentage: $FAILURE_PERCENTAGE%"

# Check if the failure percentage exceeds the threshold
if (( $(echo "$FAILURE_PERCENTAGE > $FAILURE_THRESHOLD" | bc -l) )); then
    echo "Failure percentage ($FAILURE_PERCENTAGE%) exceeds the threshold ($FAILURE_THRESHOLD%)."

    # Extract detailed error messages from the log
    ERROR_MESSAGE=$(grep -A 10 "fatal:" "$LOG_FILE" || true) # || true to avoid script exiting if no matches
    ERROR_MESSAGE="$ERROR_MESSAGE $(grep -A 10 "unreachable:" "$LOG_FILE" || true)"

    # Extract list of affected hosts
    AFFECTED_HOSTS=$(grep "fatal:" "$LOG_FILE" | awk '{print $1}' | sed 's/\[//g' | sed 's/\]://g' || true)
    AFFECTED_HOSTS="$AFFECTED_HOSTS $(grep "unreachable:" "$LOG_FILE" | awk '{print $1}' | sed 's/\[//g' | sed 's/\]://g' || true)"

    # Create the email body
    EMAIL_BODY="Playbook: $PLAYBOOK\n"
    EMAIL_BODY="$EMAIL_BODYInventory: $INVENTORY\n"
    EMAIL_BODY="$EMAIL_BODYTotal Hosts: $TOTAL_HOSTS\n"
    EMAIL_BODY="$EMAIL_BODYFailed Hosts: $FAILED_HOSTS\n"
    EMAIL_BODY="$EMAIL_BODYUnreachable Hosts: $UNREACHABLE_HOSTS\n"
    EMAIL_BODY="$EMAIL_BODYFailure Percentage: $FAILURE_PERCENTAGE%\n"
    EMAIL_BODY="$EMAIL_BODY\nAffected Hosts:\n$AFFECTED_HOSTS\n"
    EMAIL_BODY="$EMAIL_BODY\nDetailed Error Messages:\n$ERROR_MESSAGE\n"
    EMAIL_BODY="$EMAIL_BODY\nFull Log File: $(cat $LOG_FILE)\n"

    # Send email notification
    echo "$EMAIL_BODY" | mail -s "$EMAIL_SUBJECT" "$EMAIL_RECIPIENT"

    echo "Email notification sent to $EMAIL_RECIPIENT"
    exit 1  # Exit with an error code to indicate failure
else
    echo "Playbook executed successfully with acceptable failure rate."
    exit 0  # Exit with success code
fi
```