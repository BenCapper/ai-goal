# This script takes a directory of climate data files as input,
# and performs basic analysis to calculate annual averages for each file.
# It assumes each file contains daily data with a date and temperature value per line.
# The script outputs the annual average temperature for each file in the directory.

# Function to calculate the annual average temperature for a single file
calculate_annual_average() {
  local file="$1"
  local year
  local total_temp=0
  local num_days=0

  # Extract the year from the filename (assuming filename format: data_YYYY.txt)
  year=$(echo "$file" | grep -oP 'data_\K\d{4}')

  # Check if year was successfully extracted
  if [[ -z "$year" ]]; then
    echo "Error: Could not extract year from filename: $file" >&2
    return 1
  fi

  # Read each line from the file, extract the temperature, and calculate the sum.
  while IFS= read -r line; do
    temp=$(echo "$line" | awk '{print $2}') # Assuming temperature is the second column

    # Check if the temperature is a number
    if [[ ! "$temp" =~ ^[+-]?([0-9]+\.?[0-9]*|\.[0-9]+)$ ]]; then
      echo "Warning: Invalid temperature value '$temp' in file '$file', line '$line'. Skipping." >&2
      continue
    fi

    total_temp=$(echo "$total_temp + $temp" | bc)
    num_days=$((num_days + 1))
  done < "$file"

  # Calculate the average temperature
  if [[ "$num_days" -gt 0 ]]; then
    average_temp=$(echo "scale=2; $total_temp / $num_days" | bc)
    echo "Annual average temperature for $year in $file: $average_temp"
  else
    echo "No valid data found in $file."
  fi
}


# Check if a directory argument is provided
if [ -z "$1" ]; then
  echo "Usage: $0 <directory>"
  exit 1
fi

# Check if the directory exists
if [ ! -d "$1" ]; then
  echo "Error: Directory '$1' does not exist."
  exit 1
fi

# Loop through each file in the directory
for file in "$1"/*; do
  # Check if the file is a regular file
  if [ -f "$file" ]; then
    calculate_annual_average "$file"
  fi
done

exit 0
```