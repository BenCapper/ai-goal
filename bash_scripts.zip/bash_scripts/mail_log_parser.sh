# This script parses a mail server log file and reports on the number of sent and received emails.
# It extracts relevant log entries using grep, counts them, and then prints the results.

# Set the log file path.  Change this to the actual path of your mail log file.
LOG_FILE="/var/log/mail.log"

# Function to count emails of a specific type (sent/received).
count_emails() {
  log_pattern="$1"
  email_type="$2"

  email_count=$(grep "$log_pattern" "$LOG_FILE" | wc -l)

  echo "Number of $email_type emails: $email_count"
}

# Main script execution.
# Count sent emails.  The specific log pattern may need adjustment depending on your mail server.
count_emails "postfix/smtp:.*to=<" "sent"

# Count received emails.  The specific log pattern may need adjustment depending on your mail server.
count_emails "postfix/smtpd:.*from=<" "received"

exit 0
```