# This script automates the creation and management of a basic AWS VPC and subnets using the AWS CLI.
# It creates a VPC, two public subnets, and configures the necessary routing.

# Set AWS region
REGION="us-east-1"

# Set VPC CIDR block
VPC_CIDR="10.0.0.0/16"

# Set subnet CIDR blocks
PUBLIC_SUBNET1_CIDR="10.0.1.0/24"
PUBLIC_SUBNET2_CIDR="10.0.2.0/24"

# Set Availability Zones
AVAILABILITY_ZONE1="us-east-1a"
AVAILABILITY_ZONE2="us-east-1b"

# Set VPC name and tag
VPC_NAME="MyVPC"

# Create VPC
echo "Creating VPC..."
VPC_ID=$(aws ec2 create-vpc --cidr-block "$VPC_CIDR" --region "$REGION" --output text | awk '{print $1}')
echo "VPC ID: $VPC_ID"

# Tag VPC
echo "Tagging VPC..."
aws ec2 create-tags --resources "$VPC_ID" --tags "Key=Name,Value=$VPC_NAME" --region "$REGION"

# Enable DNS support and DNS hostnames
echo "Enabling DNS support and hostnames..."
aws ec2 modify-vpc-attribute --vpc-id "$VPC_ID" --enable-dns-support "{\"Value\":true}" --region "$REGION"
aws ec2 modify-vpc-attribute --vpc-id "$VPC_ID" --enable-dns-hostnames "{\"Value\":true}" --region "$REGION"

# Create Internet Gateway
echo "Creating Internet Gateway..."
INTERNET_GATEWAY_ID=$(aws ec2 create-internet-gateway --region "$REGION" --output text | awk '{print $1}')
echo "Internet Gateway ID: $INTERNET_GATEWAY_ID"

# Attach Internet Gateway to VPC
echo "Attaching Internet Gateway to VPC..."
aws ec2 attach-internet-gateway --vpc-id "$VPC_ID" --internet-gateway-id "$INTERNET_GATEWAY_ID" --region "$REGION"

# Create Public Subnet 1
echo "Creating Public Subnet 1..."
PUBLIC_SUBNET1_ID=$(aws ec2 create-subnet --vpc-id "$VPC_ID" --cidr-block "$PUBLIC_SUBNET1_CIDR" --availability-zone "$AVAILABILITY_ZONE1" --region "$REGION" --output text | awk '{print $1}')
echo "Public Subnet 1 ID: $PUBLIC_SUBNET1_ID"

# Tag Public Subnet 1
echo "Tagging Public Subnet 1..."
aws ec2 create-tags --resources "$PUBLIC_SUBNET1_ID" --tags "Key=Name,Value=PublicSubnet1" --region "$REGION"

# Modify subnet attribute to enable auto-assign public IP address
echo "Enabling auto-assign public IP for Public Subnet 1..."
aws ec2 modify-subnet-attribute --subnet-id "$PUBLIC_SUBNET1_ID" --map-public-ip-on-launch --region "$REGION"

# Create Public Subnet 2
echo "Creating Public Subnet 2..."
PUBLIC_SUBNET2_ID=$(aws ec2 create-subnet --vpc-id "$VPC_ID" --cidr-block "$PUBLIC_SUBNET2_CIDR" --availability-zone "$AVAILABILITY_ZONE2" --region "$REGION" --output text | awk '{print $1}')
echo "Public Subnet 2 ID: $PUBLIC_SUBNET2_ID"

# Tag Public Subnet 2
echo "Tagging Public Subnet 2..."
aws ec2 create-tags --resources "$PUBLIC_SUBNET2_ID" --tags "Key=Name,Value=PublicSubnet2" --region "$REGION"

# Modify subnet attribute to enable auto-assign public IP address
echo "Enabling auto-assign public IP for Public Subnet 2..."
aws ec2 modify-subnet-attribute --subnet-id "$PUBLIC_SUBNET2_ID" --map-public-ip-on-launch --region "$REGION"

# Create Route Table
echo "Creating Route Table..."
ROUTE_TABLE_ID=$(aws ec2 create-route-table --vpc-id "$VPC_ID" --region "$REGION" --output text | awk '{print $1}')
echo "Route Table ID: $ROUTE_TABLE_ID"

# Tag Route Table
echo "Tagging Route Table..."
aws ec2 create-tags --resources "$ROUTE_TABLE_ID" --tags "Key=Name,Value=PublicRouteTable" --region "$REGION"

# Create Route to Internet Gateway
echo "Creating Route to Internet Gateway..."
aws ec2 create-route --route-table-id "$ROUTE_TABLE_ID" --destination-cidr-block "0.0.0.0/0" --gateway-id "$INTERNET_GATEWAY_ID" --region "$REGION"

# Associate Subnet 1 with Route Table
echo "Associating Subnet 1 with Route Table..."
aws ec2 associate-route-table --subnet-id "$PUBLIC_SUBNET1_ID" --route-table-id "$ROUTE_TABLE_ID" --region "$REGION"

# Associate Subnet 2 with Route Table
echo "Associating Subnet 2 with Route Table..."
aws ec2 associate-route-table --subnet-id "$PUBLIC_SUBNET2_ID" --route-table-id "$ROUTE_TABLE_ID" --region "$REGION"

echo "VPC and Subnets created successfully!"
```