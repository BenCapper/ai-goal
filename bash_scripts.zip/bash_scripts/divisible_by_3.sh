# This script reads a number from the user, 
# then checks if the number is divisible by 3 using the modulo operator.
# It then prints whether the number is divisible by 3 or not.

# Usage: ./divisible_by_3.sh

read -p "Enter a number: " INPUT_NUM

if (( INPUT_NUM % 3 == 0 )); then
  echo "$INPUT_NUM is divisible by 3."
else
  echo "$INPUT_NUM is not divisible by 3."
fi
```