# This script monitors the system's CPU and memory usage using vmstat.
# It collects data every 5 seconds for a total of 30 seconds.
# After the monitoring period, it calculates and prints the average CPU idle percentage.
# Usage: ./monitor_cpu_memory.sh

# Initialize variables
total_idle=0
count=0
duration=30
interval=5

# Print header
echo "Monitoring CPU and Memory usage..."

# Run vmstat in a loop and capture idle CPU percentage
for ((i=0; i<duration; i+=interval)); do
  vmstat 1 1 | tail -n 1 | awk '{print $15}' > temp_idle.txt
  idle=$(cat temp_idle.txt)

  # Add to total idle and increment count
  total_idle=$((total_idle + idle))
  count=$((count + 1))

  sleep $interval
done

# Calculate average idle percentage
average_idle=$((total_idle / count))

# Print the average
echo "Average CPU idle percentage: $average_idle%"

# Clean up the temporary file
rm temp_idle.txt

# ./monitor_cpu_memory.sh
```