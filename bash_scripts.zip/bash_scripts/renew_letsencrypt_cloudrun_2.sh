# This script automates the process of renewing Let's Encrypt certificates
# for a web application hosted on Google Cloud Run.
# It assumes you're using Google Cloud DNS for managing your domain's DNS records.
# It leverages certbot with the dns-google plugin for DNS-01 challenge.
#
# Prerequisites:
# 1. You have the Google Cloud SDK (gcloud) installed and configured.
# 2. You have certbot installed: `sudo apt install certbot` or equivalent.
# 3. You have the certbot dns-google plugin installed: `sudo apt install python3-certbot-dns-google` or `pip install certbot-dns-google`
# 4. You have a Google Cloud service account with the "DNS Administrator" role
#    and have downloaded the service account key file.
# 5. The GOOGLE_APPLICATION_CREDENTIALS environment variable is set to point to
#    your service account key file:
#    `export GOOGLE_APPLICATION_CREDENTIALS=/path/to/your/service_account_key.json`
#
# Usage:
# 1. Configure the variables below.
# 2. Make the script executable: `chmod +x renew_letsencrypt_cloudrun.sh`
# 3. Run the script manually: `./renew_letsencrypt_cloudrun.sh`
# 4. Schedule the script to run regularly (e.g., weekly) using cron:
#    `0 0 * * 0 /path/to/renew_letsencrypt_cloudrun.sh`

# Configuration
DOMAIN="yourdomain.com" # Replace with your domain
EMAIL="your@email.com"   # Replace with your email address
CERT_DIR="/etc/letsencrypt/live/$DOMAIN" # The directory where certificates are stored
DNS_GOOGLE_CREDENTIALS="/path/to/your/service_account_key.json" # Replace with the path to your service account key file.  Should match GOOGLE_APPLICATION_CREDENTIALS if set.
PROJECT=$(gcloud config get-value project) # Your Google Cloud project ID.
RENEWAL_THRESHOLD=30 # Renew the certificate if it expires within this many days

# Check if the certificate exists
if [ -d "$CERT_DIR" ]; then
  # Check if the certificate is about to expire
  expiry_date=$(openssl x509 -in "$CERT_DIR/cert.pem" -text -noout | grep "Not After" | cut -d '=' -f 2)
  expiry_timestamp=$(date -d "$expiry_date" +%s)
  now_timestamp=$(date +%s)
  remaining_days=$(( ($expiry_timestamp - $now_timestamp) / (60 * 60 * 24) ))

  if [ "$remaining_days" -le "$RENEWAL_THRESHOLD" ]; then
    echo "Certificate for $DOMAIN expires in $remaining_days days. Renewing..."

    # Renew the certificate using certbot with dns-google plugin
    certbot certonly \
      --dns-google \
      --dns-google-credentials "$DNS_GOOGLE_CREDENTIALS" \
      --dns-google-propagation-seconds 60 \
      -d "$DOMAIN" \
      --email "$EMAIL" \
      --agree-tos \
      --non-interactive \
      --preferred-challenges dns
    
    if [ $? -eq 0 ]; then
      echo "Certificate renewed successfully for $DOMAIN."
      # Optionally, trigger a new Cloud Run revision to use the updated certificate
      # gcloud run services update your-service --platform managed --image gcr.io/your-project/your-image --update-secrets CERTIFICATE_PATH=$CERT_DIR/cert.pem,PRIVATE_KEY_PATH=$CERT_DIR/privkey.pem
      # Instead of using secrets, copy the cert files to a cloud storage bucket and then update cloud run with those files.
      echo "Remember to update your Cloud Run service with the new certificate (e.g., via secrets or a new revision)."
    else
      echo "Certificate renewal failed for $DOMAIN."
      exit 1
    fi
  else
    echo "Certificate for $DOMAIN is valid for more than $RENEWAL_THRESHOLD days ($remaining_days days). No renewal needed."
  fi
else
  echo "Certificate directory not found for $DOMAIN. Requesting a new certificate..."
  
  # Request a new certificate using certbot with dns-google plugin
  certbot certonly \
    --dns-google \
    --dns-google-credentials "$DNS_GOOGLE_CREDENTIALS" \
    --dns-google-propagation-seconds 60 \
    -d "$DOMAIN" \
    --email "$EMAIL" \
    --agree-tos \
    --non-interactive \
    --preferred-challenges dns

  if [ $? -eq 0 ]; then
    echo "Certificate generated successfully for $DOMAIN."
    # Optionally, trigger a new Cloud Run revision to use the updated certificate
    # gcloud run services update your-service --platform managed --image gcr.io/your-project/your-image --update-secrets CERTIFICATE_PATH=$CERT_DIR/cert.pem,PRIVATE_KEY_PATH=$CERT_DIR/privkey.pem
    # Instead of using secrets, copy the cert files to a cloud storage bucket and then update cloud run with those files.
    echo "Remember to update your Cloud Run service with the new certificate (e.g., via secrets or a new revision)."
  else
    echo "Certificate generation failed for $DOMAIN."
    exit 1
  fi
fi

exit 0
```