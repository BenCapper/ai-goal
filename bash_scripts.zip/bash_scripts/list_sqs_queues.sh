# This script uses the AWS CLI to list all SQS queues in your AWS account.
# It requires the AWS CLI to be configured with appropriate credentials.

# Usage: ./list_sqs_queues.sh

aws sqs list-queues
```