# This script generates a self-signed SSL certificate for localhost using openssl.
# The certificate is valid for 365 days and stored in localhost.crt and localhost.key.

# Set the output filenames
CERT_FILE="localhost.crt"
KEY_FILE="localhost.key"

# Generate the private key and self-signed certificate
openssl req -x509 -newkey rsa:4096 -keyout "$KEY_FILE" -out "$CERT_FILE" -days 365 -subj "/CN=localhost"

# Set permissions on the private key for security
chmod 400 "$KEY_FILE"

echo "Self-signed certificate generated: $CERT_FILE"
echo "Private key generated: $KEY_FILE"
```