# This script lists all CloudWatch logs in a specific log group.

# Usage: ./list_cloudwatch_logs.sh <log_group_name>

# Check if the log group name is provided as an argument
if [ -z "$1" ]; then
  echo "Error: Log group name is required."
  echo "Usage: ./list_cloudwatch_logs.sh <log_group_name>"
  exit 1
fi

LOG_GROUP_NAME="$1"

# Use the AWS CLI to list log streams in the specified log group
aws logs describe-log-streams \
  --log-group-name "$LOG_GROUP_NAME" \
  --order-by lastEventTime \
  --descending \
  --output text \
  --query 'logStreams[*].logStreamName'
```