# This script demonstrates how to generate SSH keys using ssh-keygen and 
# how to copy the public key to a remote server using ssh-copy-id.

# Check if ssh-keygen and ssh-copy-id are installed
if ! command -v ssh-keygen &> /dev/null
then
    echo "ssh-keygen is not installed. Please install it (e.g., apt install openssh-client)."
    exit 1
fi

if ! command -v ssh-copy-id &> /dev/null
then
    echo "ssh-copy-id is not installed. Please install it (e.g., apt install openssh-client)."
    exit 1
fi

# Prompt the user for the hostname or IP address of the remote server.
read -p "Enter the hostname or IP address of the remote server: " remote_host

# Prompt the user for the username on the remote server.
read -p "Enter the username on the remote server: " remote_user

# Generate an SSH key pair.
echo "Generating SSH key pair..."
ssh-keygen -t rsa -b 2048 -N "" -f ~/.ssh/id_rsa

# Copy the public key to the remote server.
echo "Copying public key to remote server..."
ssh-copy-id "$remote_user@$remote_host"

# Optional: Test the SSH connection without a password.
echo "Testing SSH connection..."
ssh -o StrictHostKeyChecking=no "$remote_user@$remote_host" "echo 'Successfully connected without password!'"

# Output success message.
echo "SSH key setup complete. You should now be able to SSH into $remote_user@$remote_host without a password."

# file usage: ./ssh_key_setup.sh
```