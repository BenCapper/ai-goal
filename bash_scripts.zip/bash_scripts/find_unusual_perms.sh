# This script finds files in a user's home directory with specific unusual permission sets.
# It uses a for loop with find and stat to identify files with specific permissions.

# Usage: ./find_unusual_perms.sh

USER_TO_FIND_ALL_PERMS="$1"

if [ -z "$USER_TO_FIND_ALL_PERMS" ]; then
  echo "Error: Please provide a username as an argument."
  exit 1
fi

USER_HOME=$(eval echo "~$USER_TO_FIND_ALL_PERMS")

if [ ! -d "$USER_HOME" ]; then
  echo "Error: User home directory '$USER_HOME' does not exist."
  exit 1
fi

find "$USER_HOME" -type f -print0 | while IFS= read -r -d $'\0' file; do
  permissions=$(stat -c "%a" "$file")
  filename=$(stat -c "%n" "$file")

  if [ "$permissions" = "777" ]; then
    echo "Warning: World-writable file found: $filename"
  elif [ "$permissions" = "775" ]; then
    echo "Warning: Group and Owner Writable & Executable: $filename"
  elif [ "$permissions" = "757" ]; then
      echo "Warning: World Writable/Executable, Owner Read/Execute: $filename"
  elif [ "$permissions" = "700" ]; then
    echo "Found: User Owns, no others permissions: $filename"
  fi
done

# ./find_unusual_perms.sh <username>
```