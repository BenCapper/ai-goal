#
# This script retrieves all NetworkPolicy resources from all OpenShift projects (namespaces)
# and prints them to the console in YAML format.  It uses `oc` command line tool which
# needs to be installed and configured to connect to the OpenShift cluster.
#
# Usage: ./get_all_network_policies.sh

# Loop through each OpenShift project.
for project in $(oc get projects -o name); do
  # Extract the project name from the "project.openshift.io/<project_name>" format.
  project_name=$(echo "$project" | cut -d'/' -f2)

  # Switch to the project.
  echo "Getting NetworkPolicies from project: $project_name"
  oc project "$project_name" > /dev/null 2>&1

  # Get all NetworkPolicies in the project and output them in YAML format.
  oc get networkpolicy --all-namespaces -n "$project_name" -o yaml
  echo "---" # Separator between projects
done

# Exit the script
exit 0
```