# This script takes a list of DOIs from a file as input, 
# and retrieves the metadata (title, authors, abstract) for each DOI 
# using the Crossref API.  It requires `curl` and `jq` to be installed.

# Check if curl and jq are installed
if ! command -v curl &> /dev/null
then
  echo "curl could not be found. Please install it."
  exit 1
fi

if ! command -v jq &> /dev/null
then
  echo "jq could not be found. Please install it."
  exit 1
fi

# Function to retrieve metadata for a given DOI
get_metadata() {
  doi="$1"
  
  # Construct the Crossref API URL
  api_url="https://api.crossref.org/works/$doi"
  
  # Retrieve the JSON response from the API
  json_data=$(curl -s "$api_url")
  
  # Check if the API call was successful
  if [[ $? -ne 0 ]]; then
    echo "Error: Failed to retrieve data for DOI: $doi"
    return 1
  fi
  
  # Extract metadata using jq
  title=$(echo "$json_data" | jq -r '.message.title[]')
  authors=$(echo "$json_data" | jq -r '.message.author[] | map(.given + " " + .family) | join(", ")')
  abstract=$(echo "$json_data" | jq -r '.message.abstract // "No abstract available"')

  # Print the metadata
  echo "DOI: $doi"
  echo "Title: $title"
  echo "Authors: $authors"
  echo "Abstract: $abstract"
  echo "------------------------"
}

# Check if a DOI file is provided as an argument
if [ -z "$1" ]; then
  echo "Usage: $0 <doi_file>"
  echo "  <doi_file> is a text file containing a list of DOIs, one per line."
  exit 1
fi

doi_file="$1"

# Check if the DOI file exists
if [ ! -f "$doi_file" ]; then
  echo "Error: DOI file '$doi_file' not found."
  exit 1
fi

# Read DOIs from the file and process each one
while IFS= read -r doi; do
  get_metadata "$doi"
done < "$doi_file"

exit 0
```