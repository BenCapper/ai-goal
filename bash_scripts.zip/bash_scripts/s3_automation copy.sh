# This script automates the creation and management of AWS S3 buckets and file transfers using the AWS CLI.
# It covers basic bucket creation, file uploading, and file downloading.

# Set AWS CLI configuration
# export AWS_ACCESS_KEY_ID="YOUR_ACCESS_KEY_ID"
# export AWS_SECRET_ACCESS_KEY="YOUR_SECRET_ACCESS_KEY"
# export AWS_REGION="YOUR_AWS_REGION"  # e.g., us-east-1

# Define variables
BUCKET_NAME="your-unique-bucket-name" # Replace with a globally unique bucket name
LOCAL_FILE="local_file.txt"
S3_KEY="path/to/remote_file.txt"
DOWNLOAD_FILE="downloaded_file.txt"

# Function to create an S3 bucket
create_bucket() {
  echo "Creating S3 bucket: $BUCKET_NAME"
  aws s3api create-bucket --bucket "$BUCKET_NAME" --region "$AWS_REGION" --create-bucket-configuration LocationConstraint="$AWS_REGION"
  if [ $? -eq 0 ]; then
    echo "Bucket '$BUCKET_NAME' created successfully."
  else
    echo "Failed to create bucket '$BUCKET_NAME'."
    exit 1
  fi
}

# Function to upload a file to S3
upload_file() {
  echo "Uploading file '$LOCAL_FILE' to 's3://$BUCKET_NAME/$S3_KEY'"
  aws s3 cp "$LOCAL_FILE" "s3://$BUCKET_NAME/$S3_KEY"
  if [ $? -eq 0 ]; then
    echo "File uploaded successfully."
  else
    echo "Failed to upload file."
    exit 1
  fi
}

# Function to download a file from S3
download_file() {
  echo "Downloading file 's3://$BUCKET_NAME/$S3_KEY' to '$DOWNLOAD_FILE'"
  aws s3 cp "s3://$BUCKET_NAME/$S3_KEY" "$DOWNLOAD_FILE"
  if [ $? -eq 0 ]; then
    echo "File downloaded successfully."
  else
    echo "Failed to download file."
    exit 1
  fi
}

# Function to list bucket contents
list_bucket() {
  echo "Listing contents of bucket: $BUCKET_NAME"
  aws s3 ls "s3://$BUCKET_NAME"
  if [ $? -ne 0 ]; then
      echo "Failed to list bucket contents"
      exit 1
  fi
}

# Function to delete a file from S3
delete_file() {
  echo "Deleting file 's3://$BUCKET_NAME/$S3_KEY'"
  aws s3 rm "s3://$BUCKET_NAME/$S3_KEY"
  if [ $? -eq 0 ]; then
    echo "File deleted successfully."
  else
    echo "Failed to delete file."
    exit 1
  fi
}

# Function to delete an S3 bucket (bucket must be empty)
delete_bucket() {
  echo "Deleting S3 bucket: $BUCKET_NAME"
  aws s3 rb "s3://$BUCKET_NAME" --force
  if [ $? -eq 0 ]; then
    echo "Bucket '$BUCKET_NAME' deleted successfully."
  else
    echo "Failed to delete bucket '$BUCKET_NAME'.  Make sure the bucket is empty."
    exit 1
  fi
}

# Main execution
echo "Starting S3 automation script..."

# Create a sample local file if it doesn't exist
if [ ! -f "$LOCAL_FILE" ]; then
  echo "Creating sample file: $LOCAL_FILE"
  echo "This is a sample file for testing." > "$LOCAL_FILE"
fi

create_bucket
upload_file
list_bucket
download_file
delete_file
# Uncomment the following line after deleting all files in the bucket
# delete_bucket

echo "S3 automation script completed."
```