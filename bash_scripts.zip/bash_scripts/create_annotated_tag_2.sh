# This script creates an annotated tag in a Git repository.
# It requires a tag name and a tag message as input.

# Usage: ./create_annotated_tag.sh <tag_name> <tag_message>

TAG_NAME="$1"
TAG_MESSAGE="$2"

if [ -z "$TAG_NAME" ] || [ -z "$TAG_MESSAGE" ]; then
  echo "Error: Tag name and message are required."
  echo "Usage: ./create_annotated_tag.sh <tag_name> <tag_message>"
  exit 1
fi

git tag -a "$TAG_NAME" -m "$TAG_MESSAGE"

if [ $? -eq 0 ]; then
  echo "Annotated tag '$TAG_NAME' created successfully."
else
  echo "Error: Failed to create annotated tag '$TAG_NAME'."
  exit 1
fi

# Example Usage: ./create_annotated_tag.sh v1.0.0 "Release version 1.0.0"
```