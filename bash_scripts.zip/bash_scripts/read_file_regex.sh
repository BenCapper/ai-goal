# This script reads lines from a file using a while loop.
# It uses grep -Eq to check if a line matches a complex regular expression
# with multiple alternatives.
# The script stops when a matching line is found.

# Usage: ./read_file_regex.sh <input_file>

INPUT_FILE="$1"

if [ -z "$INPUT_FILE" ]; then
  echo "Error: Please provide an input file."
  exit 1
fi

if [ ! -f "$INPUT_FILE" ]; then
  echo "Error: File '$INPUT_FILE' not found."
  exit 1
fi

while IFS= read -r line; do
  # Check if the line matches the regular expression.
  if grep -Eq '^(ERROR|WARNING|CRITICAL): (Disk|Memory|CPU) usage is (high|low)' <<< "$line"; then
    echo "Found matching line: $line"
    break # Exit the loop if a match is found.
  fi
  echo "Processing line: $line"

done < "$INPUT_FILE"

echo "Script finished."
```