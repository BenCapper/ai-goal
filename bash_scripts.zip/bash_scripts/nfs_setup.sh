# This script automates the process of setting up and managing a basic NFS share
# with different user mapping options.

# Variables
SHARE_DIR="/srv/nfs/shared"
NFS_SERVER_IP="192.168.1.100" # Replace with your NFS server IP
CLIENT_IP="192.168.1.101"   # Replace with your client IP
NFS_VERSION="4"              # NFS version to use (3 or 4)
exportfs_options="rw,sync"   # Default export options

# Function to check if a command exists
command_exists() {
  command -v "$1" >/dev/null 2>&1
}

# Function to install NFS server packages
install_nfs_server() {
  echo "Installing NFS server packages..."

  if command_exists apt-get; then
    sudo apt-get update
    sudo apt-get install -y nfs-kernel-server nfs-common
  elif command_exists yum; then
    sudo yum install -y nfs-utils nfs4-acl-tools
    sudo systemctl enable rpcbind
    sudo systemctl start rpcbind
  elif command_exists dnf; then
    sudo dnf install -y nfs-utils nfs4-acl-tools
    sudo systemctl enable rpcbind
    sudo systemctl start rpcbind
  else
    echo "Unsupported package manager. Please install NFS server packages manually."
    exit 1
  fi

  echo "NFS server packages installed."
}

# Function to create the shared directory
create_shared_directory() {
  echo "Creating shared directory: $SHARE_DIR"
  sudo mkdir -p "$SHARE_DIR"
  sudo chown nobody:nogroup "$SHARE_DIR"  # Ensure nobody:nogroup owns the share initially
  sudo chmod 777 "$SHARE_DIR"           # give everyone access
  echo "Shared directory created."
}

# Function to configure NFS exports
configure_nfs_exports() {
  echo "Configuring NFS exports..."

  # Create/update /etc/exports
  echo "$SHARE_DIR $CLIENT_IP($exportfs_options,all_squash,anonuid=65534,anongid=65534)" | sudo tee -a /etc/exports > /dev/null
  # Example using root_squash instead of all_squash, anonuid, anongid
  # echo "$SHARE_DIR $CLIENT_IP($exportfs_options,root_squash)" | sudo tee -a /etc/exports > /dev/null
  # Example with no_root_squash (root user on client retains root privileges on server)
  # echo "$SHARE_DIR $CLIENT_IP($exportfs_options,no_root_squash)" | sudo tee -a /etc/null

  sudo exportfs -a # Export all filesystems listed in /etc/exports

  echo "NFS exports configured."
}

# Function to configure NFS version (if needed)
configure_nfs_version() {
    if [ "$NFS_VERSION" == "4" ]; then
        echo "Configuring NFSv4..."

        # Enable NFSv4
        if ! grep -q "fsid=0" /etc/exports; then
            echo "/ $CLIENT_IP(rw,sync,fsid=0,no_subtree_check,no_root_squash)" | sudo tee -a /etc/exports > /dev/null
        fi
        # Create NFSv4 root directory
        if [ ! -d /exports ]; then
          sudo mkdir /exports
        fi

        # Mount shared dir under /exports
        if [ ! -L "$SHARE_DIR" ]; then
          sudo ln -s "$SHARE_DIR" /exports/shared
        fi

        echo "NFSv4 configured."
    fi
}

# Function to restart NFS server
restart_nfs_server() {
  echo "Restarting NFS server..."

  if command_exists systemctl; then
    sudo systemctl restart nfs-kernel-server
  elif command_exists service; then
    sudo service nfs-kernel-server restart
  else
    echo "Unsupported service manager.  Please restart NFS server manually."
  fi

  echo "NFS server restarted."
}

# Function to configure the client
configure_client() {
    echo "Configuring NFS client..."

    if command_exists apt-get; then
        sudo apt-get update
        sudo apt-get install -y nfs-common
    elif command_exists yum; then
        sudo yum install -y nfs-utils
    elif command_exists dnf; then
        sudo dnf install -y nfs-utils
    else
        echo "Unsupported package manager. Please install NFS client packages manually."
        exit 1
    fi

  echo "NFS Client configuration complete. You must mount the share from a client machine."
  echo "Example command: sudo mount $NFS_SERVER_IP:$SHARE_DIR /mnt"

}

# Main script logic
install_nfs_server
create_shared_directory
configure_nfs_version
configure_nfs_exports
restart_nfs_server
configure_client

echo "NFS setup complete."
```