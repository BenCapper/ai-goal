# This script uses git to show the log of commits that are reachable
# from a specific tag but not the current branch.

# Usage: ./git_log_from_tag_not_branch.sh <tag_name>

# Check if a tag name is provided as an argument
if [ $# -ne 1 ]; then
  echo "Usage: $0 <tag_name>"
  exit 1
fi

tag_name="$1"

# Check if the tag exists
if ! git show-ref --tags --quiet "$tag_name"; then
  echo "Error: Tag '$tag_name' does not exist."
  exit 1
fi

# Get the log of commits reachable from the tag but not the current branch
git log "$tag_name" --not HEAD
```