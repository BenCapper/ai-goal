# This script uses curl to fetch the license information for a given GitHub repository
# via the GitHub API and displays the license name.

# Check if repository owner and name are provided as arguments
if [ $# -ne 2 ]; then
  echo "Usage: $0 <repository_owner> <repository_name>"
  exit 1
fi

REPOSITORY_OWNER=$1
REPOSITORY_NAME=$2

# Construct the API URL
API_URL="https://api.github.com/repos/${REPOSITORY_OWNER}/${REPOSITORY_NAME}"

# Fetch the repository information using curl
RESPONSE=$(curl -s "$API_URL")

# Check if the curl request was successful
if [ $? -ne 0 ]; then
  echo "Error: Failed to fetch repository information."
  exit 1
fi

# Extract the license name using jq
LICENSE_NAME=$(echo "$RESPONSE" | jq -r '.license.name // "No license found"')

# Display the license name
echo "License: $LICENSE_NAME"
```