# This script interacts with an API that requires Digest HTTP authentication.
# It uses curl to make a request to the API, providing the username and password.
# The script assumes you have curl installed.
#
# Usage: ./digest_auth_api.sh <api_url> <username> <password>

# Check if the correct number of arguments are provided
if [ $# -ne 3 ]; then
  echo "Usage: ./digest_auth_api.sh <api_url> <username> <password>"
  exit 1
fi

API_URL="$1"
USERNAME="$2"
PASSWORD="$3"

# Make the API request using curl with digest authentication
RESPONSE=$(curl -s --digest -u "$USERNAME:$PASSWORD" "$API_URL")

# Check the exit status of curl
if [ $? -eq 0 ]; then
  # Print the response from the API
  echo "$RESPONSE"
else
  # Print an error message if the request failed
  echo "Error: API request failed."
  exit 1
fi

exit 0
# ./digest_auth_api.sh http://example.com/api/resource myuser mypassword
```