# This script copies all .txt files from the current directory
# to a directory named "docs" in the user's home directory.
# If the "docs" directory doesn't exist, it will be created.

# Define the target directory
TARGET_DIR="$HOME/docs"

# Check if the target directory exists. If not, create it.
if [ ! -d "$TARGET_DIR" ]; then
  mkdir -p "$TARGET_DIR"
  echo "Created directory: $TARGET_DIR"
fi

# Copy all .txt files from the current directory to the target directory
find . -maxdepth 1 -name "*.txt" -print0 | while IFS= read -r -d $'\0' file
do
  cp "$file" "$TARGET_DIR"
  echo "Copied: $file to $TARGET_DIR"
done

echo "Finished copying .txt files."
```