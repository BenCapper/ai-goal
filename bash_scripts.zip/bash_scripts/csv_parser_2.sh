# This script reads a comma-separated value (CSV) line from a variable CSV_LINE.
# It uses IFS and a for loop to split the line into individual values.
# It then checks if the value at a specific index matches a predefined string.

# Usage: ./csv_parser.sh

# Define the CSV line
CSV_LINE="value1,value2,value3,target,value5"

# Define the target string and the index to check
TARGET_STRING="target"
TARGET_INDEX=3

# Set IFS to comma to split the CSV line
OLD_IFS="$IFS"
IFS=','

# Initialize an array to store the values
VALUES=()

# Split the CSV line into individual values using a for loop
i=0
for value in $CSV_LINE; do
  VALUES[$i]="$value"
  ((i++))
done

# Restore the original IFS
IFS="$OLD_IFS"

# Check if the value at the target index matches the target string
if [ "${VALUES[$TARGET_INDEX]}" = "$TARGET_STRING" ]; then
  echo "Value at index $TARGET_INDEX matches the target string '$TARGET_STRING'."
else
  echo "Value at index $TARGET_INDEX ('${VALUES[$TARGET_INDEX]}') does not match the target string '$TARGET_STRING'."
fi
```