# This script automates the installation and basic configuration of Lynis,
# a security auditing tool.  It updates the package lists, installs Lynis,
# and then runs a basic audit with some recommended options.

# Update package lists
sudo apt update

# Install Lynis
sudo apt install -y lynis

# Run Lynis audit
lynis audit system

# Optional: Run Lynis with specific checks and verbosity
# lynis audit system --tests "network filesystems" --verbosity medium

# Suggestion: Save the audit report to a file for review
# lynis audit system --report-file /var/log/lynis_report.txt
```