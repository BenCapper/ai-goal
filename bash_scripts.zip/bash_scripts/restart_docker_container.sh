# This script restarts a specific Docker container,
# given its name or ID.

# Check if a container name or ID is provided as an argument.
if [ -z "$1" ]; then
  echo "Usage: $0 <container_name_or_id>"
  exit 1
fi

CONTAINER_ID="$1"

# Attempt to restart the container.
docker restart "$CONTAINER_ID"

# Check the exit code of the docker restart command.
if [ $? -eq 0 ]; then
  echo "Container '$CONTAINER_ID' restarted successfully."
else
  echo "Failed to restart container '$CONTAINER_ID'."
  exit 1
fi

exit 0
```