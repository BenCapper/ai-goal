# This script takes a URL as input and checks the expiration date of its SSL/TLS certificate.

# Usage: ./check_ssl_expiration.sh <URL>

# Check if a URL is provided as an argument.
if [ -z "$1" ]; then
  echo "Usage: $0 <URL>"
  exit 1
fi

URL="$1"

# Extract the hostname from the URL.  Handle both https:// and simple hostnames
if [[ "$URL" == "https://"* ]]; then
  HOST=$(echo "$URL" | cut -d'/' -f3)
else
  HOST="$URL"
fi


# Use openssl to connect to the host and retrieve the certificate's expiration date.
EXPIRY_DATE=$(openssl s_client -servername "$HOST" -connect "$HOST:443" 2>/dev/null | openssl x509 -noout -enddate)

# Check if the command was successful
if [ $? -ne 0 ]; then
  echo "Error: Could not retrieve SSL certificate information for $HOST"
  exit 1
fi

# Extract the date from the openssl output.
EXPIRY_DATE=$(echo "$EXPIRY_DATE" | cut -d'=' -f2)


# Convert the expiry date string to epoch seconds.
EXPIRY_EPOCH=$(date -d "$EXPIRY_DATE" +%s)

# Get the current time in epoch seconds.
CURRENT_EPOCH=$(date +%s)

# Calculate the remaining time in seconds.
REMAINING_SECONDS=$((EXPIRY_EPOCH - CURRENT_EPOCH))

# Calculate the remaining time in days.
REMAINING_DAYS=$((REMAINING_SECONDS / (60 * 60 * 24)))

# Print the expiration date and the remaining days.
echo "SSL Certificate for $HOST expires on: $EXPIRY_DATE"
echo "Remaining days: $REMAINING_DAYS"

# Check if the certificate is about to expire soon.
if [ "$REMAINING_DAYS" -lt 30 ]; then
  echo "Warning: SSL certificate for $HOST expires in less than 30 days!"
fi

exit 0
```