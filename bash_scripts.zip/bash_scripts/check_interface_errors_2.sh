# This script checks for network interfaces with errors.
# It uses 'ip -s link show' to get interface statistics,
# then greps for lines containing "errors",
# and finally uses awk to extract specific fields (RX errors, TX errors, etc.).
# Usage: ./check_interface_errors.sh

ip -s link show | grep "errors" | awk '{print $2, $3, $4, $5}'
```