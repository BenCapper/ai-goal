# This script generates a random bit manipulation challenge for daily practice.
# It randomly selects a challenge type and provides relevant input values.

# Function to generate a random number within a range
random_number() {
  local min=$1
  local max=$2
  local range=$((max - min + 1))
  echo $((RANDOM % range + min))
}

# Function to display the challenge
display_challenge() {
  local challenge_type=$1
  case $challenge_type in
    1) # Check if the bit at a given position is set
      local num=$(random_number 1 255)
      local pos=$(random_number 0 7)
      echo "Challenge: Check if the bit at position $pos in the number $num is set (1) or not (0)."
      echo "Number (decimal): $num"
      echo "Position (0-indexed): $pos"
      ;;
    2) # Set the bit at a given position
      local num=$(random_number 1 255)
      local pos=$(random_number 0 7)
      echo "Challenge: Set the bit at position $pos in the number $num."
      echo "Number (decimal): $num"
      echo "Position (0-indexed): $pos"
      ;;
    3) # Clear the bit at a given position
      local num=$(random_number 1 255)
      local pos=$(random_number 0 7)
      echo "Challenge: Clear the bit at position $pos in the number $num."
      echo "Number (decimal): $num"
      echo "Position (0-indexed): $pos"
      ;;
    4) # Toggle the bit at a given position
      local num=$(random_number 1 255)
      local pos=$(random_number 0 7)
      echo "Challenge: Toggle the bit at position $pos in the number $num."
      echo "Number (decimal): $num"
      echo "Position (0-indexed): $pos"
      ;;
    5) # Count set bits in a number
      local num=$(random_number 1 255)
      echo "Challenge: Count the number of set bits in the number $num."
      echo "Number (decimal): $num"
      ;;
    6) # Check if a number is a power of 2
      local num=$(random_number 1 128) #Keep it reasonable
      echo "Challenge: Check if the number $num is a power of 2 (true or false)."
      echo "Number (decimal): $num"
      ;;
    *)
      echo "Invalid challenge type."
      exit 1
      ;;
  esac
}

# Main script
# Seed the random number generator
RANDOM=$$
challenge_type=$(random_number 1 6) # Choose between different bit challenges
display_challenge $challenge_type
```