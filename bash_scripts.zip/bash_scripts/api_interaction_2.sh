# This script interacts with an API that requires an API key in the header.
# It takes the API endpoint and API key as arguments.
# It sends a GET request to the API and prints the response.
# Usage: ./api_interaction.sh <API_ENDPOINT> <API_KEY>

# Get the API endpoint and API key from the command line arguments.
API_ENDPOINT="$1"
API_KEY="$2"

# Check if the API endpoint and API key are provided.
if [ -z "$API_ENDPOINT" ] || [ -z "$API_KEY" ]; then
  echo "Usage: ./api_interaction.sh <API_ENDPOINT> <API_KEY>"
  exit 1
fi

# Construct the Authorization header with the API key.
HEADERS="Authorization: Bearer $API_KEY"

# Send the GET request with the API key in the header using curl.
RESPONSE=$(curl -s -H "$HEADERS" "$API_ENDPOINT")

# Check the exit status of curl.
if [ $? -ne 0 ]; then
  echo "Error: Failed to connect to the API."
  exit 1
fi

# Print the API response.
echo "$RESPONSE"
```