# This script automates the process of backing up files with a specific extension
# from a source directory to a destination directory.  It checks if the source
# directory exists, prompts the user for the file extension to backup,
# and then copies the files with that extension to the destination directory.
# It also includes basic error handling.

# Usage: ./backup_files.sh <source_directory> <destination_directory>

# Check if the correct number of arguments are provided
if [ $# -ne 2 ]; then
  echo "Usage: ./backup_files.sh <source_directory> <destination_directory>"
  exit 1
fi

# Source and destination directories
SOURCE_DIR="$1"
DEST_DIR="$2"

# Check if the source directory exists
if [ ! -d "$SOURCE_DIR" ]; then
  echo "Error: Source directory '$SOURCE_DIR' does not exist."
  exit 1
fi

# Check if the destination directory exists, create if it doesn't
if [ ! -d "$DEST_DIR" ]; then
  echo "Destination directory '$DEST_DIR' does not exist. Creating..."
  mkdir -p "$DEST_DIR"
  if [ $? -ne 0 ]; then
    echo "Error: Failed to create destination directory '$DEST_DIR'."
    exit 1
  fi
fi

# Prompt the user for the file extension
read -p "Enter the file extension to backup (e.g., txt, pdf): " FILE_EXTENSION

# Check if the extension is empty
if [ -z "$FILE_EXTENSION" ]; then
  echo "Error: File extension cannot be empty."
  exit 1
fi

# Construct the find command to locate files with the specified extension
FIND_COMMAND="find \"$SOURCE_DIR\" -type f -name \"*.$FILE_EXTENSION\""

# Backup the files
echo "Backing up files with extension '.$FILE_EXTENSION' from '$SOURCE_DIR' to '$DEST_DIR'..."
$FIND_COMMAND -print0 | xargs -0 cp -t "$DEST_DIR"

# Check if the copy command was successful
if [ $? -eq 0 ]; then
  echo "Backup completed successfully."
else
  echo "Error: Backup failed."
  exit 1
fi

exit 0
```