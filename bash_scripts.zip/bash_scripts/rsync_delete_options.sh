# This script demonstrates the use of rsync with the --delete-before and --delete_after options.
# It synchronizes a source directory to a destination directory, deleting files in the destination.
# --delete-before: deletion happens before the transfer
# --delete-after: deletion happens after the transfer
# This demonstrates a subtle difference in when deletions occur.

# Define source and destination directories
SOURCE_DIR="source"
DEST_DIR="destination"

# Create source and destination directories if they don't exist
mkdir -p "$SOURCE_DIR"
mkdir -p "$DEST_DIR"

# Create some files in the source directory
touch "$SOURCE_DIR/file1.txt"
touch "$SOURCE_DIR/file2.txt"
touch "$SOURCE_DIR/file3.txt"

# Create some files in the destination directory (including one not in source)
touch "$DEST_DIR/file1.txt"
touch "$DEST_DIR/file2.txt"
touch "$DEST_DIR/file4.txt"

# Display the initial state of the source and destination directories
echo "Initial state:"
echo "Source directory:"
ls -l "$SOURCE_DIR"
echo "Destination directory:"
ls -l "$DEST_DIR"

echo "--------------------------------------------------"

# Example 1: rsync with --delete-before
echo "Running rsync with --delete-before:"
rsync -av --delete-before "$SOURCE_DIR/" "$DEST_DIR/"
echo "Destination directory after --delete-before:"
ls -l "$DEST_DIR"

echo "--------------------------------------------------"

# Clean up destination directory before the next example.
rm -rf "$DEST_DIR"/*
mkdir -p "$DEST_DIR"

touch "$DEST_DIR/file1.txt"
touch "$DEST_DIR/file2.txt"
touch "$DEST_DIR/file4.txt"

echo "--------------------------------------------------"

# Example 2: rsync with --delete-after
echo "Running rsync with --delete-after:"
rsync -av --delete-after "$SOURCE_DIR/" "$DEST_DIR/"
echo "Destination directory after --delete-after:"
ls -l "$DEST_DIR"

echo "--------------------------------------------------"

# Clean up source and destination directories
rm -rf "$SOURCE_DIR" "$DEST_DIR"

# To execute the script:
# chmod +x rsync_delete_options.sh
# ./rsync_delete_options.sh
```