# This script reads a file line by line using a while loop.
# It filters out comment lines (lines starting with '#') and prints the remaining lines.
# It uses sed to accomplish this filtering.

# Set the input file name
INPUT_FILE="input.txt"

# Read the file line by line
while IFS= read -r TEXT_LINE; do
  # Check if the line is not a comment using sed
  if [[ ! -z $(echo "$TEXT_LINE" | sed -n '/^[^#]/p') ]]; then
    # Print the line if it's not a comment
    echo "$TEXT_LINE"
  fi
done < "$INPUT_FILE"

# Usage: ./read_file_non_comment.sh
```