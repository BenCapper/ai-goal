# This script takes a directory as an argument and recursively finds all files
# that have a specific extended attribute.  It then prints the path of each file
# that matches the criteria.

# Usage: ./find_files_with_xattr.sh <directory> <attribute_name>

if [ $# -ne 2 ]; then
  echo "Usage: $0 <directory> <attribute_name>"
  exit 1
fi

directory="$1"
attribute_name="$2"

# Function to recursively find files with the specified extended attribute
find_files_with_xattr() {
  find "$1" -type f -print0 | while IFS= read -r -d $'\0' file; do
    if xattr -p "$2" "$file" > /dev/null 2>&1; then
      echo "$file"
    fi
  done
}

# Call the function with the provided directory and attribute name
find_files_with_xattr "$directory" "$attribute_name"

exit 0
```