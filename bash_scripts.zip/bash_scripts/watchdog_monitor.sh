# This script monitors the system's software watchdog status.
# It checks if the watchdog is running and reports its status.

# Usage: ./watchdog_monitor.sh

# Check if the watchdog process is running
if pgrep -x "watchdog" > /dev/null
then
  echo "Watchdog is running."
else
  echo "Watchdog is NOT running."
fi

# Optionally, check the watchdog's configuration (implementation dependent)
# This part is just an example and may need adjustment based on system
# if [ -f "/etc/watchdog.conf" ]; then
#   echo "Watchdog configuration file: /etc/watchdog.conf"
#   # You could add code here to parse the configuration file
#   # and check specific settings.
# fi

exit 0
```