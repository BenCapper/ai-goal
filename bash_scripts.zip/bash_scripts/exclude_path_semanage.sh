# This script demonstrates how to use semanage fcontext to exclude paths from
# existing SELinux file context rules.  This is useful when you want to
# prevent certain files or directories from being relabeled by a specific rule.

# First, we create some test files and directories.

mkdir -p /opt/test_dir
touch /opt/test_dir/test_file.txt
touch /opt/test_dir/excluded_file.txt

# Next, we add a file context rule that applies to /opt/test_dir.
# This rule will label files in /opt/test_dir as httpd_sys_content_t
# Replace "httpd_sys_content_t" with the SELinux type you want to use for your example.
# If an error occurs here, ensure that the httpd_sys_content_t type exists or use a valid one.
semanage fcontext -a -t httpd_sys_content_t "/opt/test_dir(/.*)?"

# Now, we exclude /opt/test_dir/excluded_file.txt from the above rule.
# The -e option specifies the path to exclude.
semanage fcontext -a -e "/opt/test_dir/excluded_file.txt" "/opt/test_dir(/.*)?"

# Apply the changes using restorecon.  This relabels files according to
# the defined SELinux policy.
restorecon -v /opt/test_dir/*

# List the SELinux context of the files to demonstrate the exclusion.
ls -Z /opt/test_dir/*

# Clean up the test files and directories.
rm -rf /opt/test_dir

# Usage: ./exclude_path_semanage.sh
```