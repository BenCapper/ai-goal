# This script monitors the system's interrupt rate and logs it to a file with timestamps.
# It reads the /proc/interrupts file and extracts the total number of interrupts per second.

# Usage: ./interrupt_monitor.sh <log_file> <interval_seconds>

# Set default values
LOG_FILE="interrupts.log"
INTERVAL=1

# Override defaults if arguments are provided
if [ $# -ge 1 ]; then
  LOG_FILE="$1"
fi

if [ $# -ge 2 ]; then
  INTERVAL="$2"
fi

# Function to get the total number of interrupts
get_total_interrupts() {
  awk '{sum=0; for (i=1; i<=NF; i++) if (i>1 && $i ~ /^[0-9]+$/) sum += $i; print sum}' /proc/interrupts | head -n 1
}

# Get the initial interrupt count
INITIAL_INTERRUPTS=$(get_total_interrupts)

# Loop indefinitely
while true; do
  # Wait for the specified interval
  sleep "$INTERVAL"

  # Get the current interrupt count
  CURRENT_INTERRUPTS=$(get_total_interrupts)

  # Calculate the interrupt rate
  INTERRUPT_RATE=$((CURRENT_INTERRUPTS - INITIAL_INTERRUPTS))

  # Get the current timestamp
  TIMESTAMP=$(date +"%Y-%m-%d %H:%M:%S")

  # Log the timestamp and interrupt rate to the file
  echo "$TIMESTAMP: Interrupt Rate: $INTERRUPT_RATE interrupts/second" >> "$LOG_FILE"

  # Update the initial interrupt count
  INITIAL_INTERRUPTS="$CURRENT_INTERRUPTS"
done
```