# This script attempts to recover a deleted file with a specific name
# from an ext4 filesystem using extundelete.
#
# It requires the extundelete package to be installed.
#
# It takes the filesystem device and the filename as arguments.
# Example usage: ./recover_file.sh /dev/sda1 deleted_file.txt

# Check if extundelete is installed
if ! command -v extundelete &> /dev/null
then
  echo "extundelete is not installed. Please install it before running this script."
  exit 1
fi

# Check if the script is run as root
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root."
   exit 1
fi

# Check if the correct number of arguments is provided
if [ $# -ne 2 ]; then
  echo "Usage: $0 <filesystem_device> <filename>"
  echo "Example: $0 /dev/sda1 deleted_file.txt"
  exit 1
fi

# Assign arguments to variables
filesystem_device="$1"
filename="$2"

# Check if the filesystem device exists
if [ ! -b "$filesystem_device" ]; then
  echo "Error: Filesystem device '$filesystem_device' does not exist."
  exit 1
fi

# Create a directory to recover the file to
recovery_dir="recovered_files"
mkdir -p "$recovery_dir"

# Attempt to recover the file
echo "Attempting to recover '$filename' from '$filesystem_device'..."
extundelete "$filesystem_device" --restore-file "$filename" --output-dir "$recovery_dir"

# Check if the file was recovered successfully
if [ $? -eq 0 ]; then
  echo "File '$filename' recovered successfully to '$recovery_dir'."
else
  echo "Failed to recover file '$filename'."
  echo "Please check the extundelete output for errors."
fi

exit 0
```