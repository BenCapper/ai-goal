# This script demonstrates how to use the netstat and ss utilities to display network socket states.
# It shows common use cases for both utilities, focusing on displaying listening ports, connections, and filtering results.

# Usage: ./netstat_ss_examples.sh

# Display all listening ports using netstat
echo "--- Netstat: All Listening Ports ---"
netstat -tulnp | grep LISTEN

# Display all TCP connections using netstat
echo "--- Netstat: All TCP Connections ---"
netstat -atn

# Display UDP socket information using netstat
echo "--- Netstat: UDP Socket Information ---"
netstat -anu

# Display process using a given port (e.g., port 80) using netstat
echo "--- Netstat: Process using port 80 ---"
netstat -tulnp | grep :80

# Display all listening ports using ss
echo "--- SS: All Listening Ports ---"
ss -tuln | grep LISTEN

# Display all TCP connections using ss
echo "--- SS: All TCP Connections ---"
ss -tan

# Display UDP socket information using ss
echo "--- SS: UDP Socket Information ---"
ss -uan

# Display TCP connections to a specific port (e.g., port 22) using ss
echo "--- SS: TCP Connections to port 22 ---"
ss -tan '( dport = :22 )'

# Display all processes listening on TCP ports
echo "--- SS: Processes listening on TCP ports ---"
ss -ltp

# Show only established connections using ss
echo "--- SS: Established Connections ---"
ss -t state established

#Show pid and command name of sockets using ss
echo "--- SS: PID and command name of sockets ---"
ss -p

#Filter IP Address:
echo "--- SS: Filter IP Address ---"
ss src 192.168.1.100

```