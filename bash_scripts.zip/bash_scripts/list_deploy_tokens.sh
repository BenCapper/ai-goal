# This script interacts with the GitLab API to list all deploy tokens for a given project.
# It requires the project ID and a personal access token with API access.

# Usage: ./list_deploy_tokens.sh <project_id> <personal_access_token>

# Check if the required arguments are provided
if [ $# -ne 2 ]; then
  echo "Usage: $0 <project_id> <personal_access_token>"
  exit 1
fi

# Assign arguments to variables
PROJECT_ID="$1"
PERSONAL_ACCESS_TOKEN="$2"

# GitLab API endpoint for listing deploy tokens
API_ENDPOINT="https://gitlab.com/api/v4/projects/${PROJECT_ID}/deploy_tokens"

# Make the API request
curl --header "PRIVATE-TOKEN: ${PERSONAL_ACCESS_TOKEN}" "${API_ENDPOINT}"

# Exit gracefully
exit 0
```