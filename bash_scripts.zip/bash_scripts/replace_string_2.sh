# This script replaces all occurrences of a specified string with another string within a given file.
# It creates a backup of the original file before making the changes.

# Usage: ./replace_string.sh "string_to_replace" "replacement_string" "input_file"

# Check if the correct number of arguments are provided.
if [ $# -ne 3 ]; then
  echo "Usage: $0 \"string_to_replace\" \"replacement_string\" \"input_file\""
  exit 1
fi

# Assign arguments to variables.
string_to_replace="$1"
replacement_string="$2"
input_file="$3"

# Check if the input file exists.
if [ ! -f "$input_file" ]; then
  echo "Error: Input file '$input_file' not found."
  exit 1
fi

# Create a backup of the original file.
backup_file="$input_file.bak"
cp "$input_file" "$backup_file"

# Check if the backup was successful
if [ ! -f "$backup_file" ]; then
    echo "Error: Failed to create backup file '$backup_file'"
    exit 1
fi

# Use sed to replace all occurrences of the string.
sed -i "s/$string_to_replace/$replacement_string/g" "$input_file"

# Check if the sed command was successful
if [ $? -ne 0 ]; then
    echo "Error: Failed to replace string in '$input_file'"
    # Attempt to restore the backup
    mv "$backup_file" "$input_file"
    exit 1
fi

# Print a success message.
echo "Successfully replaced all occurrences of '$string_to_replace' with '$replacement_string' in '$input_file'."
echo "Original file backed up to '$backup_file'."

# Example usage:
# ./replace_string.sh "old_string" "new_string" "my_file.txt"
```