# This script checks if a string variable contains only digits using regular expressions.
# It declares a variable named TEXT_TO_CHECK_DIGIT_ONLY and assigns a string to it.
# Then, it uses an if statement and a regular expression to determine if the string contains only digits.
# Finally, it prints an appropriate message based on the result.
# Usage: ./check_digits.sh

TEXT_TO_CHECK_DIGIT_ONLY="12345"

if [[ "$TEXT_TO_CHECK_DIGIT_ONLY" =~ ^[0-9]+$ ]]; then
  echo "The string '$TEXT_TO_CHECK_DIGIT_ONLY' contains only digits."
else
  echo "The string '$TEXT_TO_CHECK_DIGIT_ONLY' does not contain only digits."
fi
```