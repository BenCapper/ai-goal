# This script lists all Security Context Constraints (SCCs) in the OpenShift cluster
# and extracts the ALLOWED CAPABILITIES column.

# Get SCCs and their details in wide format, then use awk to extract the ALLOWED CAPABILITIES column.
oc get scc -o wide | awk '{print $8}'
```