# This script triggers a GitLab pipeline for a specific project and branch using the GitLab API.
# It requires a project ID and a personal access token with API scope.

# Set the project ID and personal access token.  These MUST be set correctly for the script to work.
PROJECT_ID="YOUR_PROJECT_ID" # Replace with your GitLab project ID
PRIVATE_TOKEN="YOUR_PRIVATE_TOKEN" # Replace with your GitLab Personal Access Token with API scope
GIT_REF="main" # The branch or tag to trigger the pipeline on.

# Check if the Project ID and Private Token are set
if [ -z "$PROJECT_ID" ] || [ "$PROJECT_ID" == "YOUR_PROJECT_ID" ]; then
  echo "Error: PROJECT_ID is not set. Please set it to your GitLab project ID."
  exit 1
fi

if [ -z "$PRIVATE_TOKEN" ] || [ "$PRIVATE_TOKEN" == "YOUR_PRIVATE_TOKEN" ]; then
  echo "Error: PRIVATE_TOKEN is not set. Please set it to your GitLab Personal Access Token with API scope."
  exit 1
fi


# Construct the API endpoint URL
API_URL="https://gitlab.com/api/v4/projects/${PROJECT_ID}/pipeline"

# Use curl to trigger the pipeline
curl --request POST \
     --header "PRIVATE-TOKEN: ${PRIVATE_TOKEN}" \
     --form "ref=${GIT_REF}" \
     "${API_URL}"

# Example of also including a variable for the triggered pipeline.
# To include variables, use multiple --form "variables[VAR_NAME]=var_value" arguments.
# curl --request POST \
#      --header "PRIVATE-TOKEN: ${PRIVATE_TOKEN}" \
#      --form "ref=${GIT_REF}" \
#      --form "variables[MY_VARIABLE]=some_value" \
#      "${API_URL}"
```