# This script demonstrates how to use the ip command to manage policy-based routing (PBR) rules.
# It will create a new routing table, add rules to route traffic based on source IP address to that table,
# and then show how to remove the rules and table.

# Define variables
TABLE_NAME="VPN_ROUTE"
TABLE_ID=200
SOURCE_IP="192.168.1.0/24"
GATEWAY_IP="10.0.0.1"
INTERFACE="eth0"

# Create a new routing table
echo "Creating routing table $TABLE_NAME (ID: $TABLE_ID)"
echo "$TABLE_ID $TABLE_NAME" | sudo tee -a /etc/iproute2/rt_tables

# Add a default route to the new routing table
echo "Adding default route via $GATEWAY_IP to table $TABLE_NAME"
sudo ip route add default via $GATEWAY_IP dev $INTERFACE table $TABLE_NAME

# Add a rule to route traffic from the specified source IP to the new routing table
echo "Adding rule to route traffic from $SOURCE_IP to table $TABLE_NAME"
sudo ip rule add from $SOURCE_IP table $TABLE_NAME

# Show current routing rules
echo "Current routing rules:"
sudo ip rule show

# Show routing table
echo "Routing table $TABLE_NAME:"
sudo ip route show table $TABLE_NAME

# Test connectivity (optional, requires ping)
# echo "Testing connectivity to 8.8.8.8 via VPN"
# ping -I $SOURCE_IP 8.8.8.8

# Cleanup: Remove the rule and the routing table
echo "Cleaning up..."

echo "Deleting rule for $SOURCE_IP"
sudo ip rule del from $SOURCE_IP table $TABLE_NAME

echo "Deleting routing table $TABLE_NAME (ID: $TABLE_ID)"
sudo sed -i "/$TABLE_ID $TABLE_NAME/d" /etc/iproute2/rt_tables

# Remove the default route from the table
echo "Removing default route from table $TABLE_NAME"
sudo ip route del default via $GATEWAY_IP dev $INTERFACE table $TABLE_NAME

# Verify cleanup
echo "Routing rules after cleanup:"
sudo ip rule show

echo "Routing table $TABLE_NAME after cleanup:"
sudo ip route show table $TABLE_NAME || true # Ignore if table does not exist

# file usage: ./pbr_example.sh
```