# This script reads a file path, gets its name and numeric permissions,
# and checks if the permissions match a specific octal value.

# Define the octal permission value to check against
TARGET_PERMISSIONS="755"

# Read the file path into a variable
read -p "Enter the file path: " FILE_TO_CHECK_PERMISSIONS_NUMERIC

# Get the filename and numeric permissions using stat
FILE_INFO=$(stat -c "%n %a" "$FILE_TO_CHECK_PERMISSIONS_NUMERIC")

# Extract the filename and permissions
FILENAME=$(echo "$FILE_INFO" | awk '{print $1}')
PERMISSIONS=$(echo "$FILE_INFO" | awk '{print $2}')

# Check if the permissions match the target permissions
if [ "$PERMISSIONS" == "$TARGET_PERMISSIONS" ]; then
  echo "The permissions of $FILENAME match $TARGET_PERMISSIONS"
else
  echo "The permissions of $FILENAME ($PERMISSIONS) do not match $TARGET_PERMISSIONS"
fi

# Usage: ./check_permissions.sh
```