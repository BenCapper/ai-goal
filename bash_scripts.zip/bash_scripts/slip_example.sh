# This script demonstrates how to create and use Serial Line IP (SLIP)
# using netcat and socat. It sets up a simple TCP connection over a pseudo-TTY.
#
# Requirements:
# - netcat (nc)
# - socat
# - root privileges (for creating the pseudo-TTY)
#
# Usage: sudo ./slip_example.sh


# Configuration
INTERFACE="sl0"      # The interface name for SLIP
LOCAL_IP="10.0.0.1"   # Local IP address (on the machine running this script)
REMOTE_IP="10.0.0.2"  # Remote IP address (on the connected device)
TCP_PORT="23"        # The TCP port for the connection
PTY1="/tmp/pty1"      # First pseudo terminal
PTY2="/tmp/pty2"      # Second pseudo terminal

# Check if required utilities are installed
if ! command -v nc &> /dev/null
then
    echo "Error: netcat (nc) is not installed. Please install it."
    exit 1
fi

if ! command -v socat &> /dev/null
then
    echo "Error: socat is not installed. Please install it."
    exit 1
fi

# Check for root privileges
if [[ $EUID -ne 0 ]]; then
   echo "This script requires root privileges. Please run with sudo."
   exit 1
fi

# Cleanup previous instances, if any
echo "Cleaning up any previous configurations..."
ip link del $INTERFACE 2>/dev/null
rm -f $PTY1 $PTY2

# Create the pseudo-TTY pair
echo "Creating pseudo-TTY pair..."
mkfifo $PTY1 $PTY2

# Configure SLIP on one side (this machine)
echo "Configuring SLIP interface..."
ip link add $INTERFACE type slip remote $PTY1 local $PTY2
ip addr add $LOCAL_IP/30 dev $INTERFACE
ip link set $INTERFACE up

# Start socat to listen on the TCP port and forward to PTY1
echo "Starting socat..."
socat TCP-LISTEN:$TCP_PORT,fork FILE:$PTY1 &
SOCAT_PID=$!

# Print instructions for the other side
echo "SLIP interface created."
echo "Now, on the other device (e.g., embedded device or another Linux machine), connect to this machine using netcat."
echo "Run the following command on the remote device (replace with your appropriate settings):"
echo "  nc $LOCAL_IP $TCP_PORT | slattach -p slip -s 115200 /dev/stdin &"
echo "Then, configure the remote device's IP address and routing, for example:"
echo "  ifconfig sl0 $REMOTE_IP pointopoint $LOCAL_IP up"
echo "  route add default gw $LOCAL_IP"
echo "Finally, you can ping from either machine. For example, from this machine:"
echo "  ping $REMOTE_IP"
echo "Or, from the remote machine:"
echo "  ping $LOCAL_IP"

# Keep the script running (optional). You can uncomment to see it.
# To terminate the script, run `sudo kill $SOCAT_PID` and then `sudo ./slip_example.sh` again.

# Wait until user press any key
echo "Press any key to terminate the script"
read -n 1 -s

# Cleanup
echo "Cleaning up..."
ip link del $INTERFACE 2>/dev/null
rm -f $PTY1 $PTY2
kill $SOCAT_PID 2>/dev/null

echo "Finished."
```