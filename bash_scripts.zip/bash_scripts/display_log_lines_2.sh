# This script displays lines 15 to 20 of the specified log file.
# It uses the 'sed' command to extract the desired lines.

sed -n '15,20p' /var/log/apache2/access.log
```