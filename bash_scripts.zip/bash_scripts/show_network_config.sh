# This script displays the network configuration of all interfaces using the `ip addr` command.
# It provides information such as IP addresses, link status, and other interface details.

# Usage: ./show_network_config.sh

ip addr
```