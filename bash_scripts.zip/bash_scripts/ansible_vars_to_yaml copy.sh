# This script executes an Ansible playbook, retrieves all registered variables from each host, and saves them to a single YAML file.

set -e

PLAYBOOK="$1"  # Ansible playbook to execute
OUTPUT_FILE="$2" # Output YAML file to save variables

if [ -z "$PLAYBOOK" ] || [ -z "$OUTPUT_FILE" ]; then
  echo "Usage: $0 <playbook.yml> <output.yaml>"
  exit 1
fi

# Create a temporary directory
TEMP_DIR=$(mktemp -d)
echo "Temporary directory: $TEMP_DIR"

# Run the playbook with a callback plugin to save registered variables
ANSIBLE_CALLBACK_PLUGINS=$TEMP_DIR ansible-playbook -i inventory "$PLAYBOOK"

# Collect variable files from temporary directory and convert to a single YAML
find "$TEMP_DIR" -name "*.json" -print0 | while IFS= read -r -d $'\0' file; do
  host=$(basename "$file" .json)
  echo "---" >> "$OUTPUT_FILE"
  echo "$host:" >> "$OUTPUT_FILE"
  jq -r 'to_entries | .[] | "\(.key): \(.value | tostring)"' "$file" | sed 's/^/  /g' >> "$OUTPUT_FILE"
done

# Clean up the temporary directory
rm -rf "$TEMP_DIR"
echo "Variables saved to $OUTPUT_FILE"

exit 0
```