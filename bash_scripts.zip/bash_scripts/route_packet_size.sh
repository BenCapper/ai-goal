# This script demonstrates how to use the 'ip route' command to manage routing based on packet size.
# It sets up two routing tables, one for small packets and one for large packets.
# Traffic is then routed based on the packet size using iptables rules.

# Define variables
SMALL_PACKET_MTU=1000  # Example MTU for small packets
LARGE_PACKET_MTU=1500  # Example MTU for large packets
ROUTING_TABLE_SMALL=100
ROUTING_TABLE_LARGE=200
INTERFACE="eth0" # Replace with your actual interface

# Flush existing rules to avoid conflicts (use with caution in production)
iptables -F
iptables -t mangle -F

# Clear any previously created routing tables (use with caution)
ip route flush table $ROUTING_TABLE_SMALL
ip route flush table $ROUTING_TABLE_LARGE

# Create routing tables (if they don't already exist).  The '|| true' prevents an error if the table already exists.
echo $ROUTING_TABLE_SMALL small_packets >> /etc/iproute2/rt_tables || true
echo $ROUTING_TABLE_LARGE large_packets >> /etc/iproute2/rt_tables || true

# Configure routes for small packets
ip route add default via 192.168.1.1 dev $INTERFACE table $ROUTING_TABLE_SMALL # Replace with your gateway IP
ip route add 192.168.1.0/24 dev $INTERFACE scope link table $ROUTING_TABLE_SMALL  # Replace with your network and device

# Configure routes for large packets
ip route add default via 192.168.1.2 dev $INTERFACE table $ROUTING_TABLE_LARGE # Replace with your other gateway IP
ip route add 192.168.1.0/24 dev $INTERFACE scope link table $ROUTING_TABLE_LARGE  # Replace with your network and device

# Add iptables rules to classify packets based on size
# Mangle table is used to mark packets and then route based on the mark.
iptables -t mangle -A PREROUTING -i $INTERFACE -p tcp --tcp-flags SYN,RST,FIN SYN -m length --length 0:$SMALL_PACKET_MTU -j MARK --set-mark $ROUTING_TABLE_SMALL
iptables -t mangle -A PREROUTING -i $INTERFACE -p udp -m length --length 0:$SMALL_PACKET_MTU -j MARK --set-mark $ROUTING_TABLE_SMALL
iptables -t mangle -A PREROUTING -i $INTERFACE -p icmp -m length --length 0:$SMALL_PACKET_MTU -j MARK --set-mark $ROUTING_TABLE_SMALL
iptables -t mangle -A PREROUTING -i $INTERFACE -p tcp --tcp-flags SYN,RST,FIN SYN -m length --length $SMALL_PACKET_MTU:$LARGE_PACKET_MTU -j MARK --set-mark $ROUTING_TABLE_LARGE
iptables -t mangle -A PREROUTING -i $INTERFACE -p udp -m length --length $SMALL_PACKET_MTU:$LARGE_PACKET_MTU -j MARK --set-mark $ROUTING_TABLE_LARGE
iptables -t mangle -A PREROUTING -i $INTERFACE -p icmp -m length --length $SMALL_PACKET_MTU:$LARGE_PACKET_MTU -j MARK --set-mark $ROUTING_TABLE_LARGE

# Add routing rules based on packet mark.
ip rule add fwmark $ROUTING_TABLE_SMALL table $ROUTING_TABLE_SMALL
ip rule add fwmark $ROUTING_TABLE_LARGE table $ROUTING_TABLE_LARGE

# Verify the rules
echo "Routing tables:"
ip route show table $ROUTING_TABLE_SMALL
ip route show table $ROUTING_TABLE_LARGE

echo "IP rules:"
ip rule list

echo "Iptables mangle table:"
iptables -t mangle -L

# File Usage:
# sudo bash route_packet_size.sh
```