# This script reverts a specific file to a previous commit using git.

# Check if the commit hash and file path are provided as arguments.
if [ $# -ne 2 ]; then
  echo "Usage: $0 <commit_hash> <file_path>"
  exit 1
fi

# Assign the arguments to variables.
commit_hash="$1"
file_path="$2"

# Check if the commit hash is valid.
if ! git cat-file -t "$commit_hash" > /dev/null 2>&1; then
  echo "Error: Invalid commit hash: $commit_hash"
  exit 1
fi

# Check if the file exists in the repository.
if ! git rev-parse --verify "$file_path" > /dev/null 2>&1; then
    echo "Error: File does not exist in the repository: $file_path"
    exit 1
fi

# Revert the file to the specified commit.
git checkout "$commit_hash" -- "$file_path"

# Add the reverted file to the staging area.
git add "$file_path"

# Print a success message.
echo "File '$file_path' reverted to commit '$commit_hash'."
```