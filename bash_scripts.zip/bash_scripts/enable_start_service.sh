# This script automates enabling and starting a specific service on a RHEL system.
# It also ensures the service starts on boot.

# Specify the service name here
SERVICE_NAME="your_service_name"

# Enable the service to start on boot
systemctl enable "$SERVICE_NAME"

# Start the service immediately
systemctl start "$SERVICE_NAME"

# Check if the service is running
if systemctl is-active --quiet "$SERVICE_NAME"; then
  echo "Service '$SERVICE_NAME' started and enabled successfully."
else
  echo "Failed to start and/or enable service '$SERVICE_NAME'."
  exit 1
fi

exit 0
```