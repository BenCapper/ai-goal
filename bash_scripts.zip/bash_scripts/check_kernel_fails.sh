# This script checks the last 20 lines of the kernel log (dmesg) for any lines containing the word "fail".
# It then pipes the output to awk to print each matching line.  The awk command essentially just echoes the input.
# This can be useful for monitoring recent kernel errors.

# Usage: ./check_kernel_fails.sh

tail -n 20 /var/log/dmesg | grep "fail" | awk '{print $0}'
```