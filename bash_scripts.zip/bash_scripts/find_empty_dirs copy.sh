# This script uses the find command to locate and print all empty directories
# within the current directory or a specified directory.

find . -type d -empty -print
```