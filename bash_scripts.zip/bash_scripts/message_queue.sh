# This script implements a simple message queue using named pipes (FIFOs).
# It allows multiple producers to add messages to the queue and multiple consumers to retrieve them.

# Create the FIFO if it doesn't exist
QUEUE_FIFO="my_queue"

if [ ! -p "$QUEUE_FIFO" ]; then
  mkfifo "$QUEUE_FIFO"
fi

# Function to add a message to the queue
enqueue() {
  local message="$1"
  echo "$message" >> "$QUEUE_FIFO"
}

# Function to retrieve a message from the queue
dequeue() {
  cat "$QUEUE_FIFO" | head -n 1
}

# Example Usage
# Producer:  enqueue "Message from producer 1"
# Consumer:  dequeue
```