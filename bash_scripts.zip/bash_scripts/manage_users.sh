# This script automates user account creation and management across multiple RHEL servers using LDAP.
# It reads user information from a CSV file and performs actions like creating, modifying, or deleting users.
# It assumes the LDAP server is already configured and reachable from the RHEL servers.
# It requires the `ldapsearch`, `ldapadd`, `ldapmodify`, and `ldapdelete` utilities.
# file usage: ./manage_users.sh -f users.csv -a create

# Configuration
CSV_FILE=""
ACTION=""
LDAP_SERVER="ldap.example.com"
LDAP_BASE_DN="dc=example,dc=com"
LDAP_BIND_DN="cn=admin,dc=example,dc=com"
LDAP_BIND_PASSWORD="admin_password" # Store securely, consider using a file or vault
USER_SHELL="/bin/bash"
USER_HOME_PREFIX="/home"

# Function to print usage information
usage() {
  echo "Usage: $0 -f <users.csv> -a <action>"
  echo "  -f <users.csv>: CSV file containing user information (username,firstname,lastname,email)"
  echo "  -a <action>: Action to perform (create, modify, delete)"
  exit 1
}

# Parse command-line arguments
while getopts "f:a:" opt; do
  case $opt in
    f)
      CSV_FILE="$OPTARG"
      ;;
    a)
      ACTION="$OPTARG"
      ;;
    \?)
      echo "Invalid option: -$OPTARG" >&2
      usage
      ;;
    :)
      echo "Option -$OPTARG requires an argument." >&2
      usage
      ;;
  esac
done

# Check if required arguments are provided
if [ -z "$CSV_FILE" ] || [ -z "$ACTION" ]; then
  usage
fi

# Check if CSV file exists
if [ ! -f "$CSV_FILE" ]; then
  echo "Error: CSV file '$CSV_FILE' not found."
  exit 1
fi

# Function to create a user in LDAP
create_user() {
  local username="$1"
  local firstname="$2"
  local lastname="$3"
  local email="$4"

  local user_dn="uid=$username,ou=People,$LDAP_BASE_DN"
  local user_home="$USER_HOME_PREFIX/$username"
  local uid_number=$(get_next_uid) # Function defined later to find available UID

  # Check if user already exists
  if ldapsearch -x -H ldap://$LDAP_SERVER -b "$LDAP_BASE_DN" -D "$LDAP_BIND_DN" -w "$LDAP_BIND_PASSWORD" "uid=$username" > /dev/null 2>&1; then
    echo "User '$username' already exists."
    return 1
  fi

  # Create LDAP entry
  cat <<EOF | ldapadd -x -H ldap://$LDAP_SERVER -D "$LDAP_BIND_DN" -w "$LDAP_BIND_PASSWORD"
dn: $user_dn
objectClass: inetOrgPerson
objectClass: posixAccount
objectClass: shadowAccount
uid: $username
cn: $firstname $lastname
givenName: $firstname
sn: $lastname
mail: $email
userPassword: {SSHA}password # Replace with hashed password
loginShell: $USER_SHELL
uidNumber: $uid_number
gidNumber: 100
homeDirectory: $user_home
shadowLastChange: 0
shadowMin: 0
shadowMax: 99999
shadowWarning: 7
EOF
  if [ $? -eq 0 ]; then
    echo "User '$username' created successfully."
  else
    echo "Error creating user '$username'."
    return 1
  fi

  # Create user home directory on servers (example using ssh)
  # You might want to iterate over a list of server hostnames
  # for server in server1 server2 server3; do
  #   ssh root@$server "useradd -m -d $user_home -s $USER_SHELL -u $uid_number $username"
  #   if [ $? -eq 0 ]; then
  #     echo "Home directory created on $server for user $username"
  #   else
  #     echo "Error creating home directory on $server for user $username"
  #   fi
  # done
  return 0
}

# Function to modify a user in LDAP (e.g., update email)
modify_user() {
  local username="$1"
  local firstname="$2"
  local lastname="$3"
  local email="$4"

  local user_dn="uid=$username,ou=People,$LDAP_BASE_DN"

  # Check if user exists
  if ! ldapsearch -x -H ldap://$LDAP_SERVER -b "$LDAP_BASE_DN" -D "$LDAP_BIND_DN" -w "$LDAP_BIND_PASSWORD" "uid=$username" > /dev/null 2>&1; then
    echo "User '$username' does not exist."
    return 1
  fi
  
  cat <<EOF | ldapmodify -x -H ldap://$LDAP_SERVER -D "$LDAP_BIND_DN" -w "$LDAP_BIND_PASSWORD"
dn: $user_dn
changetype: modify
replace: mail
mail: $email
-
replace: cn
cn: $firstname $lastname
-
replace: givenName
givenName: $firstname
-
replace: sn
sn: $lastname
EOF
  if [ $? -eq 0 ]; then
    echo "User '$username' modified successfully."
  else
    echo "Error modifying user '$username'."
    return 1
  fi
  return 0
}

# Function to delete a user from LDAP
delete_user() {
  local username="$1"
  local user_dn="uid=$username,ou=People,$LDAP_BASE_DN"

  # Check if user exists
  if ! ldapsearch -x -H ldap://$LDAP_SERVER -b "$LDAP_BASE_DN" -D "$LDAP_BIND_DN" -w "$LDAP_BIND_PASSWORD" "uid=$username" > /dev/null 2>&1; then
    echo "User '$username' does not exist."
    return 1
  fi
  
  ldapdelete -x -H ldap://$LDAP_SERVER -D "$LDAP_BIND_DN" -w "$LDAP_BIND_PASSWORD" "$user_dn"

  if [ $? -eq 0 ]; then
    echo "User '$username' deleted successfully."
  else
    echo "Error deleting user '$username'."
    return 1
  fi

  # Delete user home directory on servers (example using ssh)
  # You might want to iterate over a list of server hostnames
  # for server in server1 server2 server3; do
  #  ssh root@$server "userdel -r $username"
  #  if [ $? -eq 0 ]; then
  #     echo "Home directory deleted on $server for user $username"
  #   else
  #     echo "Error deleting home directory on $server for user $username"
  #   fi
  # done
  return 0
}

# Function to get the next available UID
get_next_uid() {
  # This is a placeholder.  In a real implementation, you would query LDAP
  # to find the highest existing UID and increment it.  You would also
  # need proper error handling and locking to prevent race conditions.
  # This is a very simplified example and is NOT suitable for production use.
  ldapsearch -x -H ldap://$LDAP_SERVER -b "$LDAP_BASE_DN" -D "$LDAP_BIND_DN" -w "$LDAP_BIND_PASSWORD" "objectClass=posixAccount" uidNumber | grep uidNumber | awk '{print $2}' | sort -n | tail -n 1
  LAST_UID=$?
  NEXT_UID=$((LAST_UID + 1))
  echo "$NEXT_UID"
}

# Process the CSV file
while IFS=',' read -r username firstname lastname email; do
  case "$ACTION" in
    create)
      create_user "$username" "$firstname" "$lastname" "$email"
      ;;
    modify)
      modify_user "$username" "$firstname" "$lastname" "$email"
      ;;
    delete)
      delete_user "$username"
      ;;
    *)
      echo "Error: Invalid action '$ACTION'."
      usage
      ;;
  esac
done < "$CSV_FILE"

# filename: manage_users.sh
# file usage: ./manage_users.sh -f users.csv -a create
```