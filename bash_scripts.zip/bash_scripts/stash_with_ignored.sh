# This script creates a Git stash with a specified name, including ignored files.
# It first checks if the stash name is provided as an argument.
# Then it uses the `git stash push` command with the `--include-untracked` and `-u` flags to include untracked and ignored files, respectively.
# Finally, it prints a success message indicating the stash name.

# Check if a stash name is provided as an argument
if [ -z "$1" ]; then
  echo "Usage: $0 <stash_name>"
  exit 1
fi

STASH_NAME="$1"

# Create the stash including untracked and ignored files
git stash push -u -m "$STASH_NAME"

# Check if the stash creation was successful
if [ $? -eq 0 ]; then
  echo "Stash '$STASH_NAME' created successfully including untracked and ignored files."
else
  echo "Failed to create stash '$STASH_NAME'."
fi

# Usage: ./stash_with_ignored.sh "my_stash_with_ignored"
```