# This script automates the process of setting up and managing a VPN client connection.
# It supports common VPN protocols like OpenVPN and WireGuard.
# It allows for easy connection, disconnection, and status checking.

# Configuration variables (customize these)
VPN_PROTOCOL="openvpn" # or "wireguard"
VPN_CONFIG_FILE="/etc/openvpn/client.conf" # Path to your OpenVPN configuration file
WIREGUARD_INTERFACE="wg0" # Name of your WireGuard interface (e.g., wg0)
WIREGUARD_CONFIG_FILE="/etc/wireguard/wg0.conf" # Path to your WireGuard configuration file
VPN_USER="your_vpn_username" # Your VPN username (if required)
VPN_PASSWORD="your_vpn_password" # Your VPN password (if required)

# Function to check if a command exists
command_exists() {
  command -v "$1" >/dev/null 2>&1
}

# Function to start the VPN connection
start_vpn() {
  echo "Starting VPN connection..."

  case "$VPN_PROTOCOL" in
    "openvpn")
      if ! command_exists openvpn; then
        echo "Error: OpenVPN is not installed. Please install it first."
        return 1
      fi

      if [ ! -f "$VPN_CONFIG_FILE" ]; then
        echo "Error: OpenVPN configuration file not found: $VPN_CONFIG_FILE"
        return 1
      fi

      # Pass username and password through stdin if needed
      if [ -n "$VPN_USER" ] && [ -n "$VPN_PASSWORD" ]; then
        echo "$VPN_PASSWORD" | sudo openvpn --config "$VPN_CONFIG_FILE" --auth-user-pass <(echo -e "$VPN_USER\n$VPN_PASSWORD") &
      else
        sudo openvpn --config "$VPN_CONFIG_FILE" &
      fi
      echo "OpenVPN started in the background."
      ;;
    "wireguard")
      if ! command_exists wg-quick; then
        echo "Error: WireGuard is not installed. Please install it first (wireguard-tools)."
        return 1
      fi
      if [ ! -f "$WIREGUARD_CONFIG_FILE" ]; then
          echo "Error: WireGuard configuration file not found: $WIREGUARD_CONFIG_FILE"
          return 1
      fi

      sudo wg-quick up "$WIREGUARD_INTERFACE"
      echo "WireGuard connection established."
      ;;
    *)
      echo "Error: Invalid VPN protocol specified.  Supported protocols: openvpn, wireguard."
      return 1
      ;;
  esac

  return 0
}

# Function to stop the VPN connection
stop_vpn() {
  echo "Stopping VPN connection..."

  case "$VPN_PROTOCOL" in
    "openvpn")
      if ! command_exists pgrep; then
        echo "Error: pgrep is not installed."
        return 1
      fi

      PID=$(pgrep openvpn)
      if [ -n "$PID" ]; then
        sudo kill "$PID"
        echo "OpenVPN process killed (PID: $PID)."
      else
        echo "OpenVPN is not running."
      fi
      ;;
    "wireguard")
      if ! command_exists wg-quick; then
        echo "Error: WireGuard is not installed. Please install it first (wireguard-tools)."
        return 1
      fi
      sudo wg-quick down "$WIREGUARD_INTERFACE"
      echo "WireGuard connection terminated."
      ;;
    *)
      echo "Error: Invalid VPN protocol specified. Supported protocols: openvpn, wireguard."
      return 1
      ;;
  esac

  return 0
}

# Function to check the VPN connection status
check_vpn_status() {
  echo "Checking VPN connection status..."

  case "$VPN_PROTOCOL" in
    "openvpn")
      if ! command_exists pgrep; then
        echo "Error: pgrep is not installed."
        return 1
      fi

      if pgrep openvpn > /dev/null; then
        echo "OpenVPN is running."
      else
        echo "OpenVPN is not running."
      fi
      ;;
    "wireguard")
      if ! command_exists wg; then
        echo "Error: WireGuard is not installed (wg)."
        return 1
      fi
      if ip addr show "$WIREGUARD_INTERFACE" > /dev/null 2>&1; then
        echo "WireGuard interface $WIREGUARD_INTERFACE is up."
      else
        echo "WireGuard interface $WIREGUARD_INTERFACE is down."
      fi
      ;;
    *)
      echo "Error: Invalid VPN protocol specified. Supported protocols: openvpn, wireguard."
      return 1
      ;;
  esac

  return 0
}

# Main script logic
case "$1" in
  "start")
    start_vpn
    ;;
  "stop")
    stop_vpn
    ;;
  "status")
    check_vpn_status
    ;;
  *)
    echo "Usage: $0 {start|stop|status}"
    exit 1
    ;;
esac

exit 0
```