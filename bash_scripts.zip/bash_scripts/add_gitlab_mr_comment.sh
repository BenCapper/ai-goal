#!/bin/bash

# This script uses curl to add a comment to a GitLab Merge Request
# You must set the following environment variables:
#   - GITLAB_TOKEN: Your GitLab personal access token (with api scope)
#   - GITLAB_PROJECT_ID: The ID of the GitLab project
#   - GITLAB_MR_ID: The ID of the Merge Request
#   - COMMENT_BODY: The comment to be added

# Check if environment variables are set
if [ -z "$GITLAB_TOKEN" ] || [ -z "$GITLAB_PROJECT_ID" ] || [ -z "$GITLAB_MR_ID" ] || [ -z "$COMMENT_BODY" ]; then
  echo "Error: GITLAB_TOKEN, GITLAB_PROJECT_ID, GITLAB_MR_ID and COMMENT_BODY must be set."
  exit 1
fi

# GitLab API endpoint for adding a comment to a merge request
API_ENDPOINT="https://gitlab.com/api/v4/projects/$GITLAB_PROJECT_ID/merge_requests/$GITLAB_MR_ID/notes"

# Create the JSON payload
PAYLOAD=$(printf '{"body": "%s"}' "$COMMENT_BODY")

# Use curl to make the API request
curl --request POST \
  --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
  --header "Content-Type: application/json" \
  --data "$PAYLOAD" \
  "$API_ENDPOINT"

# Print the return code for debugging
echo "Return code: $?"
```