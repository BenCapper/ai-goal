# This script checks the shell of a specified user against a list of allowed shells.

# Define the user to check
USER_TO_CHECK_SHELL="nobody"

# Define the allowed shells
ALLOWED_SHELLS=("/bin/bash" "/bin/sh" "/usr/bin/zsh" "/bin/dash")

# Iterate through the /etc/passwd file
while IFS= read -r PW_LINE_SHELL; do
  # Extract the username from the line
  USERNAME=$(echo "$PW_LINE_SHELL" | cut -d':' -f1)

  # Check if the username matches the user we're checking
  if [ "$USERNAME" = "$USER_TO_CHECK_SHELL" ]; then
    # Extract the shell from the line
    USER_SHELL=$(echo "$PW_LINE_SHELL" | cut -d':' -f7)

    # Check if the shell is in the allowed list
    SHELL_ALLOWED=false
    for ALLOWED_SHELL in "${ALLOWED_SHELLS[@]}"; do
      if [ "$USER_SHELL" = "$ALLOWED_SHELL" ]; then
        SHELL_ALLOWED=true
        break
      fi
    done

    # Print the result
    if [ "$SHELL_ALLOWED" = true ]; then
      echo "User $USER_TO_CHECK_SHELL has an allowed shell: $USER_SHELL"
    else
      echo "User $USER_TO_CHECK_SHELL has an unallowed shell: $USER_SHELL"
    fi
    exit 0  # Exit after finding the user
  fi
done < /etc/passwd

echo "User $USER_TO_CHECK_SHELL not found in /etc/passwd"
exit 1

# Usage: ./check_user_shell.sh
```