# This script demonstrates how to use the factor utility
# to print the prime factors of a number.

# Usage: ./factor_primes.sh <number>

number=$1

if [ -z "$number" ]; then
  echo "Please provide a number as an argument."
  exit 1
fi

if ! [[ "$number" =~ ^[0-9]+$ ]]; then
    echo "Invalid input: Input must be a positive integer."
    exit 1
fi

factor "$number"
# Usage: ./factor_primes.sh 123456
```