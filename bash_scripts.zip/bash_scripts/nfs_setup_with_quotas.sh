# This script automates the process of setting up and managing a basic NFS share with quotas.
# It will:
# 1. Install necessary packages (nfs-kernel-server, rpcbind, quota).
# 2. Create the shared directory.
# 3. Configure the NFS export.
# 4. Set up user and group quotas on the shared directory.
# 5. Restart necessary services.

# Define variables
SHARE_DIR="/nfs_share"
USER="testuser"
GROUP="testgroup"
USER_QUOTA="100M"
GROUP_QUOTA="500M"
NFS_CLIENT_NETWORK="192.168.1.0/24"  # Adjust this to your client network

# Check if the script is run as root
if [[ $EUID -ne 0 ]]; then
  echo "This script must be run as root."
  exit 1
fi

# Install necessary packages
echo "Installing required packages..."
apt update
apt install -y nfs-kernel-server rpcbind quota

# Create the shared directory
echo "Creating shared directory: $SHARE_DIR"
mkdir -p "$SHARE_DIR"
chown nobody:nogroup "$SHARE_DIR"

# Configure the NFS export
echo "Configuring NFS export..."
echo "$SHARE_DIR $NFS_CLIENT_NETWORK(rw,sync,no_subtree_check,no_root_squash)" >> /etc/exports

# Export the NFS share
exportfs -a

# Restart NFS server
echo "Restarting NFS server..."
systemctl restart nfs-kernel-server

# Set up quotas
echo "Setting up quotas..."

# Enable quotas on the filesystem
echo "Enabling quotas on the filesystem..."
mount | grep "$SHARE_DIR" | awk '{print $1}' | xargs -I {} sh -c 'if ! grep -q noquota /etc/fstab | grep {}; then umount {} && mount -o remount,usrquota,grpquota {}; fi'

#Remount all filesystems if changes were made to fstab.
mount -a

#Create User and Group
echo "Creating User and Group"
groupadd $GROUP
useradd -g $GROUP $USER

# Initialize quota system
echo "Initializing quota system..."
quotacheck -avug

# Turn quota on
echo "Turning quota on..."
quotaon -avug

# Set user quota
echo "Setting user quota for $USER to $USER_QUOTA..."
setquota -u "$USER" 0 "$USER_QUOTA" 0 0 /

# Set group quota
echo "Setting group quota for $GROUP to $GROUP_QUOTA..."
setquota -g "$GROUP" 0 "$GROUP_QUOTA" 0 0 /

# Report quota
echo "Quota report:"
repquota -avug

echo "NFS setup with quotas completed."
```