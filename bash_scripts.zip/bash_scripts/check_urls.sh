# This script iterates through a list of URLs and checks if they return a successful HTTP status code (2xx).
# It uses curl to fetch the HTTP status code and an if statement to determine if the code is within the 200-299 range.

# Usage: ./check_urls.sh

URLS=(
  "https://www.google.com"
  "https://www.example.com"
  "https://www.invalid-url.com"
  "https://httpstat.us/200"
  "https://httpstat.us/404"
)

for URL in "${URLS[@]}"; do
  STATUS_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$URL")

  if [[ "$STATUS_CODE" -ge 200 && "$STATUS_CODE" -lt 300 ]]; then
    echo "URL: $URL - Status: $STATUS_CODE - Success!"
  else
    echo "URL: $URL - Status: $STATUS_CODE - Failure!"
  fi
done

# Usage: ./check_urls.sh
```