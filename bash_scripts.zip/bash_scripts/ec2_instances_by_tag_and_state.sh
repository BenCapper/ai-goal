# This script lists all EC2 instances with a specific tag and a specific state.
# It requires the AWS CLI to be configured with appropriate credentials.

# Usage: ./ec2_instances_by_tag_and_state.sh <tag_key> <tag_value> <instance_state>

# Get the tag key, tag value, and instance state from the command line arguments.
TAG_KEY="$1"
TAG_VALUE="$2"
INSTANCE_STATE="$3"

# Check if the required arguments are provided.
if [ -z "$TAG_KEY" ] || [ -z "$TAG_VALUE" ] || [ -z "$INSTANCE_STATE" ]; then
  echo "Usage: ./ec2_instances_by_tag_and_state.sh <tag_key> <tag_value> <instance_state>"
  exit 1
fi

# Use the AWS CLI to filter EC2 instances based on the specified tag and state.
# The 'jq' utility is used to parse the JSON output and extract the instance IDs.
INSTANCE_IDS=$(aws ec2 describe-instances \
  --filters "Name=tag:${TAG_KEY},Values=${TAG_VALUE}" "Name=instance-state-name,Values=${INSTANCE_STATE}" \
  --query 'Reservations[*].Instances[*].InstanceId' \
  --output text)

# Check if any instances were found.
if [ -z "$INSTANCE_IDS" ]; then
  echo "No EC2 instances found with tag ${TAG_KEY}:${TAG_VALUE} and state ${INSTANCE_STATE}."
  exit 0
fi

# Print the instance IDs.
echo "EC2 Instance IDs with tag ${TAG_KEY}:${TAG_VALUE} and state ${INSTANCE_STATE}:"
echo "$INSTANCE_IDS"

# file usage: ./ec2_instances_by_tag_and_state.sh Environment Production running
```