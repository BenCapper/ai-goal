# This script demonstrates how to use ansible-vault to encrypt and decrypt a variable
# directly from the command line.  It requires ansible-vault to be installed
# and accessible in your PATH.

# Set the variable name and value to encrypt
VARIABLE_NAME="my_secret"
VARIABLE_VALUE="This is my super secret value!"
VAULT_PASSWORD_FILE=".vault_pass"

# Check if the vault password file exists. If not, create it.
if [ ! -f "$VAULT_PASSWORD_FILE" ]; then
  echo "Vault password file '$VAULT_PASSWORD_FILE' not found. Please create it."
  echo "You can use openssl rand -base64 32 > $VAULT_PASSWORD_FILE"
  exit 1
fi

# Encrypt the variable using ansible-vault
ENCRYPTED_VALUE=$(ansible-vault encrypt_string --vault-password-file="$VAULT_PASSWORD_FILE" "${VARIABLE_VALUE}" --name "${VARIABLE_NAME}" --output stdout)

echo "Encrypted value:"
echo "$ENCRYPTED_VALUE"

# Decrypt the variable using ansible-vault
DECRYPTED_VALUE=$(ansible-vault decrypt_string --vault-password-file="$VAULT_PASSWORD_FILE" "${ENCRYPTED_VALUE}" --output stdout)

echo ""
echo "Decrypted value:"
echo "$DECRYPTED_VALUE"

# Extract only the decrypted variable value, removing the variable name
EXTRACTED_VALUE=$(echo "$DECRYPTED_VALUE" | sed -n "s/^${VARIABLE_NAME}:\s*//p")

echo ""
echo "Extracted Value:"
echo "$EXTRACTED_VALUE"

# Verify the decrypted value matches the original value
if [ "$EXTRACTED_VALUE" = "$VARIABLE_VALUE" ]; then
  echo ""
  echo "Verification successful: Decrypted value matches original value."
else
  echo ""
  echo "Verification failed: Decrypted value does not match original value."
fi
```