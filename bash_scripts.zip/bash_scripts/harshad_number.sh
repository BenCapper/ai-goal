# This script checks if a number is a Harshad number (divisible by the sum of its digits).
# It prompts the user to enter a number, calculates the sum of its digits,
# and then checks if the number is divisible by the sum of its digits.

# Usage: ./harshad_number.sh

read -p "Enter a number: " NUMBER_TO_CHECK_HARSHAD

# Input validation
if ! [[ "$NUMBER_TO_CHECK_HARSHAD" =~ ^[0-9]+$ ]]; then
  echo "Error: Input must be a positive integer."
  exit 1
fi

# Calculate the sum of the digits
TEMP_NUMBER=$NUMBER_TO_CHECK_HARSHAD
SUM_OF_DIGITS=0

while [ "$TEMP_NUMBER" -gt 0 ]; do
  DIGIT=$((TEMP_NUMBER % 10))
  SUM_OF_DIGITS=$((SUM_OF_DIGITS + DIGIT))
  TEMP_NUMBER=$((TEMP_NUMBER / 10))
done

# Check if the sum of digits is zero
if [ "$SUM_OF_DIGITS" -eq 0 ]; then
  echo "Error: Sum of digits is zero. Cannot divide by zero."
  exit 1
fi

# Check if the number is divisible by the sum of its digits
if [ $((NUMBER_TO_CHECK_HARSHAD % SUM_OF_DIGITS)) -eq 0 ]; then
  echo "$NUMBER_TO_CHECK_HARSHAD is a Harshad number."
else
  echo "$NUMBER_TO_CHECK_HARSHAD is not a Harshad number."
fi
```