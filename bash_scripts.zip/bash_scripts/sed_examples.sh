# This script demonstrates various uses of the sed (stream editor) utility
# for filtering and transforming text.

# Example 1: Replace all occurrences of "old" with "new" in a file
# This will print the modified content to standard output.
sed 's/old/new/g' input.txt

# Example 2: Replace the first occurrence of "old" with "new" in each line
sed 's/old/new/' input.txt

# Example 3: Delete all lines containing the word "pattern"
sed '/pattern/d' input.txt

# Example 4: Print only lines containing the word "pattern"
sed -n '/pattern/p' input.txt

# Example 5: Replace "old" with "new" only in lines containing "pattern"
sed '/pattern/s/old/new/g' input.txt

# Example 6: Insert a line containing "new line" before each line containing "pattern"
sed '/pattern/i new line' input.txt

# Example 7: Append a line containing "new line" after each line containing "pattern"
sed '/pattern/a new line' input.txt

# Example 8: Replace the entire line containing "pattern" with "new line"
sed '/pattern/c new line' input.txt

# Example 9: Replace multiple patterns using ;
sed 's/pattern1/replacement1/g ; s/pattern2/replacement2/g' input.txt

# Example 10: Replace "pattern" with "replacement" and save the changes to a new file
sed 's/pattern/replacement/g' input.txt > output.txt

# Example 11: Replace "pattern" with "replacement" and save the changes in place
# Note: This option requires GNU sed or BSD sed. It may not be available on all systems.
# Using a temporary file is a more portable alternative:
# sed 's/pattern/replacement/g' input.txt > temp.txt && mv temp.txt input.txt
sed -i 's/pattern/replacement/g' input.txt

# Example 12: Using backreferences to reorder words
echo "hello world" | sed 's/\(hello\) \(world\)/\2 \1/'

# Example 13: Using a variable in sed command
pattern="hello"
replacement="goodbye"
sed "s/$pattern/$replacement/g" input.txt

# Example 14: Remove leading whitespace from each line
sed 's/^[ \t]*//' input.txt

# Example 15: Remove trailing whitespace from each line
sed 's/[ \t]*$//' input.txt

# Usage:
# chmod +x sed_examples.sh
# ./sed_examples.sh
# Create an input.txt file for the examples to work correctly.
```