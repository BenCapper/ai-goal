# This script displays the kernel version of the system.
# It uses the 'uname' command with the '-r' option to retrieve the kernel release information.

# Usage: ./kernel_version.sh

# Display the kernel version
echo "Kernel version: $(uname -r)"
```