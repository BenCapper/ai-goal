# This script iterates through all files in the current directory.
# It checks if the size of each file is greater than 1MB.
# If it is, it prints the filename and its size in bytes.

# Usage: ./find_large_files.sh

for file in *; do
  if [ -f "$file" ]; then
    size=$(stat -c %s "$file")
    if [ "$size" -gt 1048576 ]; then
      echo "File: $file, Size: $size bytes"
    fi
  fi
done
```