# This script reads a number from the user into the INPUT_MATH variable.
# It then uses an if statement with arithmetic expansion to check if the number is greater than 10.
# If it is, it prints a message saying so. Otherwise, it prints a different message.

# Usage: ./math_check.sh

read -p "Enter a number: " INPUT_MATH

if (( INPUT_MATH > 10 )); then
  echo "$INPUT_MATH is greater than 10."
else
  echo "$INPUT_MATH is not greater than 10."
fi
```