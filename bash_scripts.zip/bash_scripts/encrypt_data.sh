# This script encrypts data using an AWS KMS key.
# It takes the KMS key ID and the input file as arguments.
# The encrypted data is then stored in an output file.

# Usage: ./encrypt_data.sh <KMS_KEY_ID> <INPUT_FILE> <OUTPUT_FILE>

# Check if the correct number of arguments are provided
if [ $# -ne 3 ]; then
  echo "Usage: ./encrypt_data.sh <KMS_KEY_ID> <INPUT_FILE> <OUTPUT_FILE>"
  exit 1
fi

# Set variables
KMS_KEY_ID=$1
INPUT_FILE=$2
OUTPUT_FILE=$3

# Check if input file exists
if [ ! -f "$INPUT_FILE" ]; then
  echo "Error: Input file '$INPUT_FILE' not found."
  exit 1
fi

# Encrypt the data using KMS
aws kms encrypt \
  --key-id "$KMS_KEY_ID" \
  --plaintext fileb://"$INPUT_FILE" \
  --output text \
  --query CiphertextBlob | base64 --decode > "$OUTPUT_FILE"

# Check if the encryption was successful based on exit code
if [ $? -eq 0 ]; then
  echo "Data encrypted successfully and saved to '$OUTPUT_FILE'."
else
  echo "Error: Encryption failed."
  exit 1
fi
```