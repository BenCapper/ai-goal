# This script takes a directory as input and removes all files that have the
# same name but different extensions, keeping only one of them.

# Usage: ./remove_duplicate_extensions.sh <directory>

# Check if a directory is provided as an argument
if [ $# -ne 1 ]; then
  echo "Usage: $0 <directory>"
  exit 1
fi

directory="$1"

# Check if the directory exists
if [ ! -d "$directory" ]; then
  echo "Error: Directory '$directory' does not exist."
  exit 1
fi

# Create an associative array to store the base names and their extensions
declare -A base_names

# Loop through all files in the directory
find "$directory" -type f -print0 | while IFS= read -r -d $'\0' file; do
  # Extract the base name (filename without extension)
  base_name=$(basename "$file")
  base_name="${base_name%.*}"

  # Get the extension of the file
  extension="${file##*.}"

  # If the base name is already in the array, compare the extensions
  if [[ ${base_names[$base_name]} ]]; then
    # If the current file's extension is "preferred" (e.g., longer, or a specific type)
    # you can add logic here to determine which file to keep.
    # For simplicity, this script keeps the first file encountered.
    # You can replace the following lines with your preference logic.

    # Delete the current file if its extension is alphabetically later than the one already stored
    # or if the stored file still exists.
    if [[ "$extension" > "${base_names[$base_name]}" ]]; then
        #Delete this file and do not store it in the array
        echo "Removing $file (duplicate base name: $base_name, extension: $extension)"
        rm -f "$file"
    else
        #do nothing
        true
    fi

  else
    # Add the base name and extension to the array
    base_names[$base_name]="$extension"
  fi
done

echo "Duplicate file removal complete."
```