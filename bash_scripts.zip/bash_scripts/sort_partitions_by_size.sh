# This script uses the df -h command to display disk space usage in a human-readable format.
# It filters out the header line "Filesystem" using grep -v.
# The output is then piped to sort -k 3 -n to sort the partitions by size, using the 3rd column (size) numerically.

# Usage: ./sort_partitions_by_size.sh

df -h | grep -v "^Filesystem" | sort -k 3 -n
```