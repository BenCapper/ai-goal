# This script uses awk to filter lines from data.csv
# where the third field is greater than 100 and prints those lines.

awk -F',' '$3 > 100 {print}' data.csv
```