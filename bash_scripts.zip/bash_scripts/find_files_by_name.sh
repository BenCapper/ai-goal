# This script uses the find command to locate all files with a specific name
# in a given directory.

# Set the directory to search in
SEARCH_DIR="$1"

# Set the filename to search for
FILENAME="$2"

# Check if the directory and filename are provided as arguments
if [ -z "$SEARCH_DIR" ] || [ -z "$FILENAME" ]; then
  echo "Usage: $0 <directory> <filename>"
  exit 1
fi

# Use find to locate files with the specified name
find "$SEARCH_DIR" -type f -name "$FILENAME"

# Check the exit status of the find command and print an error message if it fails.
if [ $? -ne 0 ]; then
    echo "Error: Find command failed."
    exit 1
fi
```