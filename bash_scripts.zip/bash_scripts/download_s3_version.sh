# This script downloads a specific version of a file from an S3 bucket.
# It requires the AWS CLI to be configured with appropriate credentials.

# Usage: ./download_s3_version.sh <bucket_name> <s3_key> <version_id> <output_file>

# Script starts here

BUCKET_NAME="$1"
S3_KEY="$2"
VERSION_ID="$3"
OUTPUT_FILE="$4"

if [ -z "$BUCKET_NAME" ] || [ -z "$S3_KEY" ] || [ -z "$VERSION_ID" ] || [ -z "$OUTPUT_FILE" ]; then
  echo "Error: Missing required arguments."
  echo "Usage: ./download_s3_version.sh <bucket_name> <s3_key> <version_id> <output_file>"
  exit 1
fi

aws s3api get-object \
    --bucket "$BUCKET_NAME" \
    --key "$S3_KEY" \
    --version-id "$VERSION_ID" \
    "$OUTPUT_FILE"

if [ $? -eq 0 ]; then
  echo "Successfully downloaded '$S3_KEY' (version: $VERSION_ID) from '$BUCKET_NAME' to '$OUTPUT_FILE'."
else
  echo "Error: Failed to download '$S3_KEY' (version: $VERSION_ID) from '$BUCKET_NAME'."
  exit 1
fi

exit 0

# end of script

# example usage: ./download_s3_version.sh my-bucket my/file.txt VERSIONID output.txt
```