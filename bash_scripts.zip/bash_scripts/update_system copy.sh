# This script updates all packages on a RHEL system using dnf.
# It first checks for available updates and prompts the user for confirmation
# before proceeding with the upgrade.

# Usage: ./update_system.sh

# Check for available updates
dnf check-update

# Get the number of available updates
UPDATE_COUNT=$(dnf check-update | wc -l)

# Subtract the header lines from the update count
UPDATE_COUNT=$((UPDATE_COUNT - 2))

# Check if there are updates available
if [ "$UPDATE_COUNT" -gt 0 ]; then
  echo "There are $UPDATE_COUNT updates available."
  read -p "Do you want to proceed with the update? (y/n): " -n 1 -r
  echo    # (optional) move to a new line after the input
  if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Updating system..."
    sudo dnf update -y
    echo "System update completed."
  else
    echo "Update cancelled."
  fi
else
  echo "No updates available."
fi
```