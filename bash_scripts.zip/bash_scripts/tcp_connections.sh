# This script uses the ss command to list all established TCP connections.
# It filters the output to show only connections to or from a specific IP address or port provided as arguments.

# Usage: ./tcp_connections.sh <ip_address_or_port>

# Check if an argument is provided
if [ -z "$1" ]; then
  echo "Usage: $0 <ip_address_or_port>"
  exit 1
fi

# IP address or port to filter by
TARGET="$1"

# Use ss command to list established TCP connections and filter the output
ss -t state established | awk '$1=="tcp" && ($5 ~ "'"$TARGET"'" || $4 ~ "'"$TARGET"'")'
```