# This script parses a configuration file and applies network interface card (NIC) settings
# based on its content.  The configuration file should specify the interface name, IP address,
# netmask, gateway, and DNS servers.
#
# Example configuration file (nic.conf):
# INTERFACE=eth0
# IP_ADDRESS=192.168.1.100
# NETMASK=255.255.255.0
# GATEWAY=192.168.1.1
# DNS1=8.8.8.8
# DNS2=8.8.4.4

# Set the configuration file path
CONFIG_FILE="nic.conf"

# Check if the configuration file exists
if [ ! -f "$CONFIG_FILE" ]; then
  echo "Error: Configuration file '$CONFIG_FILE' not found."
  exit 1
fi

# Source the configuration file
source "$CONFIG_FILE"

# Check if the required variables are set
if [ -z "$INTERFACE" ] || [ -z "$IP_ADDRESS" ] || [ -z "$NETMASK" ]; then
  echo "Error: Missing required configuration parameters in '$CONFIG_FILE'."
  echo "Please ensure INTERFACE, IP_ADDRESS, and NETMASK are defined."
  exit 1
fi

# Configure the interface
echo "Configuring interface: $INTERFACE"

# Set the IP address and netmask
sudo ip addr flush dev "$INTERFACE"
sudo ip addr add "$IP_ADDRESS/$NETMASK" dev "$INTERFACE"
sudo ip link set dev "$INTERFACE" up

# Set the gateway (if defined)
if [ ! -z "$GATEWAY" ]; then
  echo "Setting gateway: $GATEWAY"
  sudo ip route add default via "$GATEWAY"
fi

# Set the DNS servers (if defined)
if [ ! -z "$DNS1" ] || [ ! -z "$DNS2" ]; then
  echo "Setting DNS servers"
  echo "nameserver $DNS1" | sudo tee /etc/resolv.conf > /dev/null
  if [ ! -z "$DNS2" ]; then
      echo "nameserver $DNS2" | sudo tee -a /etc/resolv.conf > /dev/null
  fi
else
  echo "No DNS servers specified, using existing configuration"
fi


echo "Network configuration applied successfully to interface: $INTERFACE"

exit 0
```