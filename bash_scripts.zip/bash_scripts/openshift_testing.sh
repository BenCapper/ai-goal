#
# This script automates testing of applications deployed in OpenShift as part of a CI/CD pipeline.
# It performs checks like application availability, basic functionality, and resource utilization.
# It uses `oc` command-line tool to interact with the OpenShift cluster.
#
# Usage: ./openshift_testing.sh <namespace> <application_name>

# Set variables
NAMESPACE="$1"
APP_NAME="$2"
ROUTE_NAME="${APP_NAME}-route" # Assume a route with <app_name>-route exists
TEST_URL=""
TEST_ENDPOINT="/health" # Basic health check endpoint
TIMEOUT=60 # Timeout in seconds

# Check if required parameters are provided
if [ -z "$NAMESPACE" ] || [ -z "$APP_NAME" ]; then
  echo "Error: Namespace and Application Name are required."
  exit 1
fi

# Function to check application availability
check_availability() {
  echo "Checking application availability..."

  # Get the route URL
  ROUTE_HOST=$(oc get route "$ROUTE_NAME" -n "$NAMESPACE" -o jsonpath='{.spec.host}')
  if [ -z "$ROUTE_HOST" ]; then
    echo "Error: Route '$ROUTE_NAME' not found in namespace '$NAMESPACE'."
    return 1
  fi

  TEST_URL="http://${ROUTE_HOST}${TEST_ENDPOINT}" #Construct http URL for testing
  
  echo "Testing URL: $TEST_URL"

  # Use curl to check the application's health endpoint
  if curl -s --fail --max-time $TIMEOUT "$TEST_URL" > /dev/null; then
    echo "Application is available."
    return 0
  else
    echo "Error: Application is not available."
    return 1
  fi
}

# Function to perform basic functionality tests (example)
perform_functionality_tests() {
  echo "Performing basic functionality tests..."
  # Add your application-specific tests here.
  # Example: Checking for specific data returned by an API endpoint.
  # This is a placeholder and needs to be adapted to your application.

  # Dummy test: Check if the app returns a 200 status code
  if curl -s -o /dev/null -w "%{http_code}" "$TEST_URL" | grep -q "200"; then
        echo "Basic functionality test passed."
        return 0
    else
        echo "Basic functionality test failed."
        return 1
  fi

}

# Function to check resource utilization (example)
check_resource_utilization() {
  echo "Checking resource utilization..."
  # Example: Check CPU and memory usage of the application's pod.
  # This is a placeholder and needs to be adapted to your application.

  POD_NAME=$(oc get pods -n "$NAMESPACE" -l app="$APP_NAME" -o jsonpath='{.items[0].metadata.name}')

  if [ -z "$POD_NAME" ]; then
    echo "Error: No pods found for application '$APP_NAME' in namespace '$NAMESPACE'."
    return 1
  fi
  
  # Get CPU Usage (requires metrics-server to be configured in OpenShift Cluster)
  CPU_USAGE=$(oc top pod "$POD_NAME" -n "$NAMESPACE" --no-headers | awk '{print $2}')

  # Get Memory Usage (requires metrics-server to be configured in OpenShift Cluster)
  MEMORY_USAGE=$(oc top pod "$POD_NAME" -n "$NAMESPACE" --no-headers | awk '{print $3}')
  
  if [ -z "$CPU_USAGE" ] || [ -z "$MEMORY_USAGE" ]; then
    echo "Warning: Could not fetch resource utilization data. Ensure metrics server is enabled in the OpenShift Cluster."
  else
    echo "CPU Usage: $CPU_USAGE"
    echo "Memory Usage: $MEMORY_USAGE"
  fi

  return 0

}

# Main execution flow
echo "Starting automated testing for application '$APP_NAME' in namespace '$NAMESPACE'..."

# Check application availability
if check_availability; then
  echo "Availability check passed."
else
  echo "Availability check failed."
  exit 1
fi

# Perform basic functionality tests
if perform_functionality_tests; then
  echo "Functionality tests passed."
else
  echo "Functionality tests failed."
  exit 1
fi

# Check resource utilization
check_resource_utilization # Non-critical test, does not exit on failure.

echo "Automated testing completed."
exit 0

# Usage: ./openshift_testing.sh <namespace> <application_name>
```