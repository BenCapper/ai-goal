# This script automates the process of backing up and restoring
# the system's desktop environment panel configurations.
# It supports XFCE, GNOME, and KDE Plasma desktop environments.

# Define backup directory
BACKUP_DIR="$HOME/panel_backups"

# Function to determine the desktop environment
get_desktop_environment() {
  if [[ -n "$XDG_CURRENT_DESKTOP" ]]; then
    echo "$XDG_CURRENT_DESKTOP"
  elif [[ -n "$GDMSESSION" ]]; then
    echo "$GDMSESSION"
  elif [[ -n "$DESKTOP_SESSION" ]]; then
    echo "$DESKTOP_SESSION"
  elif [[ -n "$DISPLAY" ]]; then
    # Fallback: Use WM-detect if no env variable is set
    DE=$(wmctrl -m | grep "Running under")
    DE="${DE##*Running under: }"
    DE="${DE%% *}"
    echo "$DE"
  else
    echo "Unknown"
  fi
}

# Function to backup panel configuration
backup_panel() {
  local desktop_env=$1
  local timestamp=$(date +%Y%m%d_%H%M%S)

  mkdir -p "$BACKUP_DIR"

  case "$desktop_env" in
    XFCE)
      # Backup XFCE panel configuration
      echo "Backing up XFCE panel configuration..."
      xfconf-query -c xfce4-panel -l > "$BACKUP_DIR/xfce4_panel_settings_$timestamp.txt"
      tar -czvf "$BACKUP_DIR/xfce4_panel_backup_$timestamp.tar.gz" ~/.config/xfce4/panel ~/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-panel.xml
      echo "XFCE panel configuration backed up to $BACKUP_DIR"
      ;;
    GNOME)
      # Backup GNOME panel configuration (using dconf)
      echo "Backing up GNOME panel configuration..."
      dconf dump /org/gnome/shell/extensions/dash-to-dock/ > "$BACKUP_DIR/gnome_panel_settings_$timestamp.dconf"
      dconf dump /org/gnome/shell/ > "$BACKUP_DIR/gnome_shell_settings_$timestamp.dconf"

      echo "GNOME panel configuration backed up to $BACKUP_DIR"
      ;;
    KDE)
      # Backup KDE Plasma panel configuration
      echo "Backing up KDE Plasma panel configuration..."
      tar -czvf "$BACKUP_DIR/kde_panel_backup_$timestamp.tar.gz" ~/.config/plasma-org.kde.plasma.desktop-appletsrc ~/.config/plasma-org.kde.plasma.shell.desktoprc ~/.config/kdeglobals
      echo "KDE Plasma panel configuration backed up to $BACKUP_DIR"
      ;;
    *)
      echo "Unsupported desktop environment: $desktop_env"
      exit 1
      ;;
  esac
}

# Function to restore panel configuration
restore_panel() {
  local desktop_env=$1
  local backup_file=$2

  if [ ! -f "$backup_file" ]; then
    echo "Backup file not found: $backup_file"
    exit 1
  fi

  case "$desktop_env" in
    XFCE)
      # Restore XFCE panel configuration
      echo "Restoring XFCE panel configuration from $backup_file..."
      tar -xzvf "$backup_file" -C ~
      xfce4-panel -r
      echo "XFCE panel configuration restored. Restarting panel..."

      ;;
    GNOME)
      # Restore GNOME panel configuration (using dconf)
      echo "Restoring GNOME panel configuration from $backup_file..."
      dconf load /org/gnome/shell/extensions/dash-to-dock/ < "$backup_file"
      dconf load /org/gnome/shell/ < "$backup_file"
      echo "GNOME panel configuration restored. Restarting GNOME Shell..."
      gnome-shell --replace &
      ;;
    KDE)
      # Restore KDE Plasma panel configuration
      echo "Restoring KDE Plasma panel configuration from $backup_file..."
      tar -xzvf "$backup_file" -C ~
      kquitapp5 plasmashell
      kstart5 plasmashell
      echo "KDE Plasma panel configuration restored. Restarting Plasma..."
      ;;
    *)
      echo "Unsupported desktop environment: $desktop_env"
      exit 1
      ;;
  esac
}

# Main script logic

if [ "$#" -eq 0 ]; then
  echo "Usage: $0 [backup|restore] [backup_file]"
  exit 1
fi

DESKTOP_ENV=$(get_desktop_environment)

if [ "$1" = "backup" ]; then
  backup_panel "$DESKTOP_ENV"
elif [ "$1" = "restore" ]; then
  if [ -z "$2" ]; then
    echo "Please specify the backup file to restore from."
    exit 1
  fi
  restore_panel "$DESKTOP_ENV" "$2"
else
  echo "Invalid option: $1.  Must be 'backup' or 'restore'."
  exit 1
fi

exit 0
```