# This script retrieves the deployment configurations in a specified OpenShift project.
# It uses the oc command-line tool to query the OpenShift API and extract the deployment configurations.

# Usage: ./get_deployment_configs.sh <project_name>

# Check if project name is provided
if [ -z "$1" ]; then
  echo "Error: Please provide the project name as an argument."
  echo "Usage: ./get_deployment_configs.sh <project_name>"
  exit 1
fi

PROJECT_NAME="$1"

# Authenticate to OpenShift (assumes oc is already configured)
# oc login ... #If you need to login, uncomment and configure this line

# Switch to the specified project
oc project "$PROJECT_NAME" 2>/dev/null || {
  echo "Error: Could not switch to project '$PROJECT_NAME'.  Check if the project exists and you have access."
  exit 1
}

# Get the deployment configurations in the current project and print them in YAML format
oc get dc -o yaml

# Example usage:
# ./get_deployment_configs.sh my-project
```