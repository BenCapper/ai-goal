# This script lists all config maps in a specific OpenShift project.
 # It uses the `oc` command-line tool.

 # Set the project name.  Change this to your desired project.
 PROJECT_NAME="my-project"

 # Check if the oc command is available
 if ! command -v oc &> /dev/null
 then
  echo "Error: oc command not found. Please install the OpenShift CLI."
  exit 1
 fi

 # Check if the user is logged in to OpenShift cluster
 if ! oc whoami &> /dev/null
 then
  echo "Error: Not logged in to OpenShift. Please log in using 'oc login'."
  exit 1
 fi

 # Get all configmaps in the specified project.
 oc get configmap -n "$PROJECT_NAME"
```