# This script demonstrates the use of shell functions for modularization,
# taking arguments, and returning values (through output). It provides
# basic arithmetic operations.

# Function to add two numbers.
# Arguments: num1, num2
# Returns: sum
add() {
  local num1=$1
  local num2=$2
  echo $((num1 + num2))
}

# Function to subtract two numbers.
# Arguments: num1, num2
# Returns: difference
subtract() {
  local num1=$1
  local num2=$2
  echo $((num1 - num2))
}

# Function to multiply two numbers.
# Arguments: num1, num2
# Returns: product
multiply() {
  local num1=$1
  local num2=$2
  echo $((num1 * num2))
}

# Function to divide two numbers.
# Arguments: num1, num2
# Returns: quotient (integer division)
divide() {
  local num1=$1
  local num2=$2
  if [[ $num2 -eq 0 ]]; then
    echo "Error: Division by zero!"
    return 1
  fi
  echo $((num1 / num2))
}

# Main function to parse arguments and call appropriate functions
main() {
  if [[ $# -lt 3 ]]; then
    echo "Usage: calculator.sh <num1> <operation> <num2>"
    echo "Operations: add, subtract, multiply, divide"
    return 1
  fi

  local num1=$1
  local operation=$2
  local num2=$3

  if ! [[ "$num1" =~ ^-?[0-9]+$ && "$num2" =~ ^-?[0-9]+$ ]]; then
    echo "Error: Invalid numbers. Please enter integers."
    return 1
  fi

  case "$operation" in
    "add")
      result=$(add "$num1" "$num2")
      echo "Result: $result"
      ;;
    "subtract")
      result=$(subtract "$num1" "$num2")
      echo "Result: $result"
      ;;
    "multiply")
      result=$(multiply "$num1" "$num2")
      echo "Result: $result"
      ;;
    "divide")
      result=$(divide "$num1" "$num2")
      if [[ $? -eq 0 ]]; then
        echo "Result: $result"
      fi
      ;;
    *)
      echo "Error: Invalid operation. Choose from add, subtract, multiply, divide."
      return 1
      ;;
  esac
}

# Call the main function with the script's arguments
main "$@"

# Usage: ./calculator.sh 10 add 5
#        ./calculator.sh 20 subtract 3
#        ./calculator.sh 5 multiply 4
#        ./calculator.sh 10 divide 2
```