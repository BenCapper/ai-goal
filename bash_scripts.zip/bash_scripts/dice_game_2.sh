# This script simulates a simple dice rolling game.
# The user guesses the sum of two dice rolls.
# The script continues until the user guesses correctly.

# Usage: ./dice_game.sh

while true; do
  # Roll two dice (random number between 1 and 6).
  die1=$((RANDOM % 6 + 1))
  die2=$((RANDOM % 6 + 1))

  # Calculate the sum of the dice.
  sum=$((die1 + die2))

  # Prompt the user to guess the sum.
  read -p "Guess the sum of two dice rolls (2-12): " guess

  # Check if the guess is valid (between 2 and 12).
  if ! [[ "$guess" =~ ^[0-9]+$ ]] || (( guess < 2 || guess > 12 )); then
    echo "Invalid guess. Please enter a number between 2 and 12."
    continue
  fi

  # Check if the guess is correct.
  if (( guess == sum )); then
    echo "Congratulations! You guessed correctly. The sum was $sum."
    break # Exit the loop if the guess is correct.
  else
    echo "Incorrect. The sum was $sum. Try again."
  fi
done
# usage: ./dice_game.sh
```