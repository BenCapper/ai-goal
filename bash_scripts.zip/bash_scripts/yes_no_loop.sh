# This script prompts the user for a "yes" or "no" response.
# It uses a while loop to keep prompting until a valid response is given.
# A case statement is used to handle the "yes" and "no" options (case-insensitive).

# Usage: ./yes_no_loop.sh

USER_RESPONSE_YESNO=""

while true; do
  read -p "Please enter 'yes' or 'no': " USER_RESPONSE_YESNO
  USER_RESPONSE_YESNO=$(echo "$USER_RESPONSE_YESNO" | tr '[:upper:]' '[:lower:]') # Convert input to lowercase

  case "$USER_RESPONSE_YESNO" in
    yes)
      echo "You answered yes."
      break # Exit the loop
      ;;
    no)
      echo "You answered no."
      break # Exit the loop
      ;;
    *)
      echo "Invalid input. Please enter 'yes' or 'no'."
      ;;
  esac
done
# Usage: ./yes_no_loop.sh
```