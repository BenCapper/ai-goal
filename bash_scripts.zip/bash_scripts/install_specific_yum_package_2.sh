# This script installs a specific version of a package using yum.
# It first checks if the specified version is available in the configured repositories.

# Usage: ./install_specific_yum_package.sh <package_name> <package_version>

# Check if the correct number of arguments is provided
if [ $# -ne 2 ]; then
  echo "Usage: $0 <package_name> <package_version>"
  exit 1
fi

# Assign the arguments to variables
package_name=$1
package_version=$2

# Check if the specified version is available in the repositories
available=$(yum list available "$package_name-$package_version" | grep "$package_name.$" | wc -l)

if [ "$available" -eq 0 ]; then
  echo "Error: Package $package_name version $package_version not found in available repositories."
  exit 1
fi

# Install the specified package version
echo "Installing $package_name-$package_version using yum..."
sudo yum install -y "$package_name-$package_version"

# Check if the installation was successful
if [ $? -eq 0 ]; then
  echo "Package $package_name-$package_version successfully installed."
else
  echo "Error: Failed to install $package_name-$package_version."
  exit 1
fi

exit 0
```