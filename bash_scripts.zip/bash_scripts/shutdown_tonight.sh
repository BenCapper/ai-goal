# This script schedules a shutdown of the system at 23:00 tonight using the 'at' command.
# It constructs the time string "23:00" and then uses 'at' to schedule the 'shutdown -h now' command.

TIME="23:00"

echo "Scheduling shutdown at $TIME tonight..."

echo "shutdown -h now" | at $TIME

echo "Shutdown scheduled."
```