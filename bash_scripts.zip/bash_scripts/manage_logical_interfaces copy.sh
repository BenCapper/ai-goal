# This script automates the creation and management of logical interfaces (aliases) in Linux.
# It allows you to add, remove, and list interface aliases.

# Function to display usage instructions
usage() {
  echo "Usage: $0 [options]"
  echo "Options:"
  echo "  -a <interface>:<alias_ip>/<cidr>  Add an interface alias (e.g., eth0:0:192.168.1.100/24)"
  echo "  -d <interface>:<alias_ip>        Delete an interface alias (e.g., eth0:0:192.168.1.100)"
  echo "  -l                              List existing interface aliases"
  echo "  -h                              Display this help message"
  exit 1
}

# Function to add an interface alias
add_alias() {
  local interface_alias="$1"
  local interface=$(echo "$interface_alias" | cut -d':' -f1)
  local alias_num=$(echo "$interface_alias" | cut -d':' -f2)
  local alias_ip=$(echo "$interface_alias" | cut -d':' -f3 | cut -d'/' -f1)
  local alias_cidr=$(echo "$interface_alias" | cut -d':' -f3 | cut -d'/' -f2)

  if [[ -z "$interface" || -z "$alias_num" || -z "$alias_ip" || -z "$alias_cidr" ]]; then
    echo "Error: Invalid interface alias format. Use <interface>:<alias_ip>/<cidr>"
    return 1
  fi

  # Check if the interface exists
  if ! ip link show "$interface" > /dev/null 2>&1; then
    echo "Error: Interface '$interface' does not exist."
    return 1
  fi

  # Check if the alias already exists
  if ip addr show "$interface":"$alias_num" > /dev/null 2>&1; then
    echo "Error: Alias '$interface":"$alias_num"' already exists."
    return 1
  fi

  # Add the interface alias
  sudo ip addr add "$alias_ip/$alias_cidr" dev "$interface" label "$interface":"$alias_num"

  if [ $? -eq 0 ]; then
    echo "Interface alias '$interface":"$alias_num"' added successfully with IP '$alias_ip/$alias_cidr'."
  else
    echo "Error: Failed to add interface alias '$interface":"$alias_num"'."
    return 1
  fi
}

# Function to delete an interface alias
delete_alias() {
  local interface_alias="$1"
  local interface=$(echo "$interface_alias" | cut -d':' -f1)
  local alias_num=$(echo "$interface_alias" | cut -d':' -f2)
  local alias_ip=$(echo "$interface_alias" | cut -d':' -f3)

  if [[ -z "$interface" || -z "$alias_num" || -z "$alias_ip" ]]; then
    echo "Error: Invalid interface alias format. Use <interface>:<alias_ip>"
    return 1
  fi
  
  # Check if the interface exists
  if ! ip link show "$interface" > /dev/null 2>&1; then
    echo "Error: Interface '$interface' does not exist."
    return 1
  fi

  # Check if the alias exists
  if ! ip addr show "$interface":"$alias_num" > /dev/null 2>&1; then
    echo "Error: Alias '$interface":"$alias_num"' does not exist."
    return 1
  fi

  # Delete the interface alias
  sudo ip addr del "$alias_ip" dev "$interface":"$alias_num"

  if [ $? -eq 0 ]; then
    echo "Interface alias '$interface":"$alias_num"' deleted successfully with IP '$alias_ip'."
  else
    echo "Error: Failed to delete interface alias '$interface":"$alias_num"'."
    return 1
  fi
}

# Function to list interface aliases
list_aliases() {
  ip addr | grep -E '^[0-9]+: ' | grep -v lo: | awk '{print $2}' | sed 's/://g' | while read -r interface; do
    ip addr show "$interface" | grep -oP "inet \K([0-9.]+/[0-9]+)" | while read -r ip_cidr; do
      echo "$interface: $ip_cidr"
    done
  done
}

# Parse command-line arguments
while getopts "a:d:lh" opt; do
  case "$opt" in
    a)
      add_alias "$OPTARG"
      ;;
    d)
      delete_alias "$OPTARG"
      ;;
    l)
      list_aliases
      ;;
    h)
      usage
      ;;
    \?)
      echo "Invalid option: -$OPTARG" >&2
      usage
      ;;
    :)
      echo "Option -$OPTARG requires an argument." >&2
      usage
      ;;
  esac
done

# If no arguments are provided, display usage
if [ $# -eq 0 ]; then
  usage
fi
```