# This script fetches the list of followers for the authenticated user on GitHub
# and limits the number of results.
#
# It uses the GitHub API and requires a personal access token (PAT) with 'read:user' scope.
# The PAT should be stored in an environment variable named GITHUB_TOKEN.
#
# Usage: ./github_followers.sh <limit>

# Check if GITHUB_TOKEN is set
if [ -z "$GITHUB_TOKEN" ]; then
  echo "Error: GITHUB_TOKEN environment variable not set."
  echo "Please set your GitHub Personal Access Token (PAT) with 'read:user' scope."
  exit 1
fi

# Get the limit from the command line argument
limit="$1"

# Check if limit is provided
if [ -z "$limit" ]; then
  echo "Error: Please provide a limit for the number of followers to fetch."
  echo "Usage: ./github_followers.sh <limit>"
  exit 1
fi

# GitHub API endpoint to get followers
api_url="https://api.github.com/user/followers"

# Fetch the followers using curl and jq, limiting the results
followers=$(curl -s -H "Authorization: token $GITHUB_TOKEN" "$api_url?per_page=$limit" | jq -r '.[].login')

# Check if the request was successful (e.g., token is valid)
if [[ "$followers" == "null" ]]; then
  echo "Error: Unable to fetch followers. Check your GITHUB_TOKEN and scopes."
  exit 1
fi

# Print the list of followers
if [ -n "$followers" ]; then
  echo "Followers:"
  echo "$followers"
else
  echo "No followers found or an error occurred."
fi

# Usage: ./github_followers.sh 10
```