# This script demonstrates how to use semanage fcontext -a -s -t -e to combine multiple SELinux context matching criteria.
# It adds a file context mapping that matches a specific SELinux user, role, type, and uses a regular expression to match filenames.

# Set SELinux context components
USER="user_u"
ROLE="role_r"
TYPE="type_t"
REGEX="/var/www/html/.*\.php" # Matches any PHP file under /var/www/html/

# Add the file context mapping
semanage fcontext -a -s "$USER" -r "$ROLE" -t "$TYPE" -e "$REGEX"

# Apply the changes (restorecon is just an example - you might need to apply it more specifically)
restorecon -v /var/www/html/*.php

# List the file context mappings to verify the new entry
semanage fcontext -l | grep "/var/www/html/.*\.php"

# cleanup (optional: remove the mapping)
# semanage fcontext -d -s "$USER" -r "$ROLE" -t "$TYPE" -e "$REGEX"
# restorecon -v /var/www/html/*.php
# semanage fcontext -l | grep "/var/www/html/.*\.php"

# usage: ./semanage_fcontext_complex.sh
```