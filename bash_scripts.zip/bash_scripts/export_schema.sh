# This script automates the export of a MySQL database schema.
# It uses mysqldump to generate a SQL file containing only the database structure (no data).

# Usage: ./export_schema.sh <database_name> <output_file>
# Example: ./export_schema.sh mydatabase mydatabase_schema.sql

# Check if the correct number of arguments is provided
if [ $# -ne 2 ]; then
  echo "Usage: ./export_schema.sh <database_name> <output_file>"
  exit 1
fi

# Assign the database name and output file name to variables
DATABASE_NAME=$1
OUTPUT_FILE=$2

# Check if database exists
if ! mysql -u root -e "SHOW DATABASES LIKE '$DATABASE_NAME'" | grep -q "$DATABASE_NAME"; then
    echo "Error: Database '$DATABASE_NAME' does not exist."
    exit 1
fi

# Export the database schema using mysqldump
mysqldump -u root -p --no-data --routines --triggers "$DATABASE_NAME" > "$OUTPUT_FILE"

# Check if the export was successful
if [ $? -eq 0 ]; then
  echo "Database schema for '$DATABASE_NAME' exported to '$OUTPUT_FILE' successfully."
else
  echo "Error: Failed to export database schema for '$DATABASE_NAME'."
  exit 1
fi

exit 0
```