# This script demonstrates parallel compression and decompression using gzip, bzip2, and xz.
# It creates a large dummy file, then compresses and decompresses it using each utility in parallel.
# File usage: ./parallel_compression.sh

# Create a large dummy file
dd if=/dev/urandom of=dummy_file.txt bs=1M count=100

# --- gzip ---
echo "Gzip compression and decompression:"
start=$(date +%s.%N)
gzip -c dummy_file.txt | pigz > dummy_file.txt.gz
end=$(date +%s.%N)
duration=$(echo "$end - $start" | bc)
echo "Gzip compression time: $duration seconds"

start=$(date +%s.%N)
pigz -d dummy_file.txt.gz > dummy_file_gzip_decompressed.txt
end=$(date +%s.%N)
duration=$(echo "$end - $start" | bc)
echo "Gzip decompression time: $duration seconds"

# --- bzip2 ---
echo "Bzip2 compression and decompression:"
start=$(date +%s.%N)
bzip2 -c dummy_file.txt | pbzip2 > dummy_file.txt.bz2
end=$(date +%s.%N)
duration=$(echo "$end - $start" | bc)
echo "Bzip2 compression time: $duration seconds"

start=$(date +%s.%N)
pbzip2 -d dummy_file.txt.bz2 > dummy_file_bzip2_decompressed.txt
end=$(date +%s.%N)
duration=$(echo "$end - $start" | bc)
echo "Bzip2 decompression time: $duration seconds"

# --- xz ---
echo "XZ compression and decompression:"
start=$(date +%s.%N)
xz -c dummy_file.txt | pxz > dummy_file.txt.xz
end=$(date +%s.%N)
duration=$(echo "$end - $start" | bc)
echo "XZ compression time: $duration seconds"

start=$(date +%s.%N)
pxz -d dummy_file.txt.xz > dummy_file_xz_decompressed.txt
end=$(date +%s.%N)
duration=$(echo "$end - $start" | bc)
echo "XZ decompression time: $duration seconds"

# Clean up
rm dummy_file.txt dummy_file.txt.gz dummy_file.txt.bz2 dummy_file.txt.xz dummy_file_gzip_decompressed.txt dummy_file_bzip2_decompressed.txt dummy_file_xz_decompressed.txt
```