# This script reads two numerical strings from the user.
# It then compares them numerically using an if statement.
# It stores the result in variables NUM_A_GREATER and NUM_B_GREATER

# Usage: ./compare_numbers.sh

read -p "Enter the first number: " num_a
read -p "Enter the second number: " num_b

if (( num_a > num_b )); then
  NUM_A_GREATER=1
  NUM_B_GREATER=0
  echo "$num_a is greater than $num_b"
elif (( num_a < num_b )); then
  NUM_A_GREATER=0
  NUM_B_GREATER=1
  echo "$num_a is less than $num_b"
else
  NUM_A_GREATER=0
  NUM_B_GREATER=0
  echo "$num_a is equal to $num_b"
fi
```