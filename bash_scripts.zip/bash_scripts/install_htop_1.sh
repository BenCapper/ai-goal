# This script installs the htop package on Ubuntu without prompting for confirmation.
# It updates the package lists and then installs htop using apt-get with the -y flag to automatically answer yes to any prompts.

# Update package lists
sudo apt-get update

# Install htop without prompting for confirmation
sudo apt-get install -y htop
```