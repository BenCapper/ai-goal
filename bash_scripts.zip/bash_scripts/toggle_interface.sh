# This script disables and enables a specified network interface.
# It uses the `ip link set` command to bring the interface down and then up.

# Usage: ./toggle_interface.sh <interface_name>

# Check if an interface name is provided.
if [ -z "$1" ]; then
  echo "Error: Please provide an interface name."
  echo "Usage: ./toggle_interface.sh <interface_name>"
  exit 1
fi

INTERFACE="$1"

# Disable the interface.
echo "Disabling interface $INTERFACE..."
sudo ip link set dev "$INTERFACE" down

# Check if the disable command was successful.
if [ $? -ne 0 ]; then
  echo "Error: Failed to disable interface $INTERFACE."
  exit 1
fi

# Enable the interface.
echo "Enabling interface $INTERFACE..."
sudo ip link set dev "$INTERFACE" up

# Check if the enable command was successful.
if [ $? -ne 0 ]; then
  echo "Error: Failed to enable interface $INTERFACE."
  exit 1
fi

echo "Interface $INTERFACE toggled successfully."
```