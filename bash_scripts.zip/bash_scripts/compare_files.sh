# This script reads a file path from a variable,
# checks if the file exists, and if so, compares it
# byte-by-byte with another specified file using cmp.

# Usage: FILE_TO_COMPARE=/path/to/file1.txt ./compare_files.sh /path/to/file2.txt

FILE_TO_COMPARE="$FILE_TO_COMPARE"
FILE_TO_COMPARE_TO="$1"


if [ -e "$FILE_TO_COMPARE" ]; then
  if cmp -s "$FILE_TO_COMPARE" "$FILE_TO_COMPARE_TO"; then
    echo "identical"
  else
    echo "different"
  fi
else
  echo "File '$FILE_TO_COMPARE' does not exist."
fi

# FILE_TO_COMPARE=/path/to/file1.txt ./compare_files.sh /path/to/file2.txt
```