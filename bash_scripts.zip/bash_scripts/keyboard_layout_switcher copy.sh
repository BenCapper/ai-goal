# This script parses a configuration file
# to apply specific keyboard layouts for different applications.

# Configuration file format:
# application_name=keyboard_layout
# Example:
# firefox=us
# gedit=fr

# Set the configuration file path
CONFIG_FILE="$HOME/.config/keyboard_layouts.conf"

# Function to get the active window title
get_active_window_title() {
  xprop -root _NET_ACTIVE_WINDOW | \
  awk '{id=substr($5,3,length($5)-3);system("xprop -id " id " WM_NAME")}' | \
  grep "WM_NAME(STRING)" | \
  cut -d '"' -f 2
}

# Function to set the keyboard layout
set_keyboard_layout() {
  local layout="$1"
  setxkbmap "$layout"
}

# Parse the configuration file and apply the layout
apply_layout() {
  local window_title
  window_title=$(get_active_window_title)

  # Read the configuration file line by line
  while IFS='=' read -r app_name layout; do
    # Check if the current window title matches the application name
    if [[ "$window_title" == *"$app_name"* ]]; then
      echo "Setting keyboard layout to $layout for $window_title"
      set_keyboard_layout "$layout"
      return
    fi
  done < "$CONFIG_FILE"

  # If no match is found, revert to the default layout (optional)
  # set_keyboard_layout "us"
}

# Main execution
if [ ! -f "$CONFIG_FILE" ]; then
  echo "Error: Configuration file not found: $CONFIG_FILE"
  exit 1
fi

# Continuously monitor and apply layout changes
while true; do
  apply_layout
  sleep 1 # Check every 1 second
done
```