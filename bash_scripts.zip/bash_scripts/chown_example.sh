# This script demonstrates how to use the chown utility to change the owner and group of a file.

# First, we create a dummy file to work with.
touch my_test_file.txt

# Display the current owner and group of the file.
echo "Before chown:"
ls -l my_test_file.txt

# Change the owner of the file to user 'newuser'.
# Make sure a user named 'newuser' exists, otherwise use a valid user.
sudo chown newuser my_test_file.txt

# Change the owner and group of the file to user 'newuser' and group 'newgroup'.
# Make sure a user named 'newuser' and a group 'newgroup' exist, otherwise use valid user and group.
sudo chown newuser:newgroup my_test_file.txt

# Display the new owner and group of the file.
echo "After chown:"
ls -l my_test_file.txt

# Change the group of the file to 'newgroup' while leaving the owner unchanged.
sudo chown :newgroup my_test_file.txt

echo "After changing group:"
ls -l my_test_file.txt

#Clean up the test file
rm my_test_file.txt

# Usage: ./chown_example.sh
```