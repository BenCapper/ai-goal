# This script automates the process of backing up and restoring the system's SSH server configuration.
# It backs up the sshd_config file and authorized_keys file, and restores them when needed.

# Define backup directory
BACKUP_DIR="/opt/ssh_backups"

# Define SSH configuration file
SSH_CONFIG="/etc/ssh/sshd_config"

# Define authorized_keys location
AUTH_KEYS="/home/$USER/.ssh/authorized_keys"

# Function to create a backup
backup_ssh_config() {
  # Create backup directory if it doesn't exist
  mkdir -p "$BACKUP_DIR"

  # Create timestamp for backup file
  TIMESTAMP=$(date +%Y%m%d_%H%M%S)

  # Backup SSH configuration file
  cp "$SSH_CONFIG" "$BACKUP_DIR/sshd_config_$TIMESTAMP"
  echo "SSH configuration backed up to: $BACKUP_DIR/sshd_config_$TIMESTAMP"

  # Backup authorized_keys file
  cp "$AUTH_KEYS" "$BACKUP_DIR/authorized_keys_$TIMESTAMP"
  echo "Authorized_keys backed up to: $BACKUP_DIR/authorized_keys_$TIMESTAMP"
}

# Function to restore from a backup
restore_ssh_config() {
  # Check if backup directory exists
  if [ ! -d "$BACKUP_DIR" ]; then
    echo "Backup directory not found: $BACKUP_DIR"
    return 1
  fi

  # Prompt user for which backup to restore from
  echo "Available backups:"
  ls -l "$BACKUP_DIR" | awk '{print $9}'

  read -p "Enter the name of the sshd_config backup file to restore (e.g., sshd_config_20231026_123456): " SSH_CONFIG_BACKUP_FILE
  read -p "Enter the name of the authorized_keys backup file to restore (e.g., authorized_keys_20231026_123456): " AUTH_KEYS_BACKUP_FILE


  # Check if the backup file exists
  if [ ! -f "$BACKUP_DIR/$SSH_CONFIG_BACKUP_FILE" ] || [ ! -f "$BACKUP_DIR/$AUTH_KEYS_BACKUP_FILE" ] ; then
    echo "Backup file not found: $BACKUP_DIR/$SSH_CONFIG_BACKUP_FILE or $BACKUP_DIR/$AUTH_KEYS_BACKUP_FILE"
    return 1
  fi

  # Stop the SSH service
  systemctl stop sshd

  # Restore the SSH configuration file
  cp "$BACKUP_DIR/$SSH_CONFIG_BACKUP_FILE" "$SSH_CONFIG"
  echo "SSH configuration restored from: $BACKUP_DIR/$SSH_CONFIG_BACKUP_FILE"

  # Restore authorized_keys file
  cp "$BACKUP_DIR/$AUTH_KEYS_BACKUP_FILE" "$AUTH_KEYS"
  echo "Authorized_keys restored from: $BACKUP_DIR/$AUTH_KEYS_BACKUP_FILE"

  # Set correct permissions.  Important for sshd_config
  chmod 600 "$SSH_CONFIG"
  chown root:root "$SSH_CONFIG"

  # Set correct permissions. Important for authorized_keys
  chmod 600 "$AUTH_KEYS"
  chown "$USER":"$USER" "$AUTH_KEYS"

  # Start the SSH service
  systemctl start sshd

  echo "SSH service restarted."
}

# Function to display help message
show_help() {
  echo "Usage: $0 [options]"
  echo "Options:"
  echo "  -b, --backup    Backup SSH configuration and authorized_keys"
  echo "  -r, --restore   Restore SSH configuration and authorized_keys from backup"
  echo "  -h, --help      Display this help message"
  echo ""
  echo "Example:"
  echo "  $0 -b          Backup SSH configuration and authorized_keys"
  echo "  $0 -r          Restore SSH configuration and authorized_keys from backup"
}

# Main script logic
while [ "$#" -gt 0 ]; do
  case "$1" in
    -b|--backup)
      backup_ssh_config
      exit 0
      ;;
    -r|--restore)
      restore_ssh_config
      exit 0
      ;;
    -h|--help)
      show_help
      exit 0
      ;;
    *)
      echo "Invalid option: $1"
      show_help
      exit 1
      ;;
  esac
  shift
done

# If no arguments are provided, show help
if [ "$#" -eq 0 ]; then
  show_help
  exit 1
fi
```