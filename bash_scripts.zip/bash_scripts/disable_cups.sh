# This script disables the CUPS printing service from starting at boot.
# It uses systemctl to stop the service and disable it.

# Stop the CUPS service
sudo systemctl stop cups

# Disable the CUPS service from starting at boot
sudo systemctl disable cups

echo "CUPS service has been stopped and disabled from starting at boot."
```