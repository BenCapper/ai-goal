#
# This script enforces branch naming conventions in a Git repository using a pre-push hook.
# It checks if the branch being pushed matches the defined naming convention.
# The script supports different conventions based on regex patterns.

# Define the allowed branch naming conventions (regex patterns)
# Examples:
#   feature/.*: Matches branches starting with "feature/"
#   bugfix/.*: Matches branches starting with "bugfix/"
#   hotfix/.*: Matches branches starting with "hotfix/"
#   release/.*: Matches branches starting with "release/"
#   ^(master|main)$: Matches only master or main branches
ALLOWED_BRANCH_PATTERNS=(
  "feature/.*"
  "bugfix/.*"
  "hotfix/.*"
  "release/.*"
  "^(master|main)$"
)

# Function to check if a branch name matches any of the allowed patterns
check_branch_name() {
  local branch_name="$1"
  local valid=0

  for pattern in "${ALLOWED_BRANCH_PATTERNS[@]}"; do
    if [[ "$branch_name" =~ $pattern ]]; then
      valid=1
      break
    fi
  done

  if [[ "$valid" -eq 0 ]]; then
    return 1 # Branch name is invalid
  else
    return 0 # Branch name is valid
  fi
}

# Iterate over the branches being pushed
while read local_ref local_sha remote_ref remote_sha; do
  # Extract the branch name from the local ref
  branch_name=$(echo "$local_ref" | sed 's#refs/heads/##')

  # Skip checking if deleting the branch
  if [ "$remote_sha" = "0000000000000000000000000000000000000000" ]; then
    continue
  fi

  # Check if the branch name is valid
  if ! check_branch_name "$branch_name"; then
    echo "ERROR: Branch name '$branch_name' does not match the allowed naming conventions."
    echo "Allowed patterns are:"
    for pattern in "${ALLOWED_BRANCH_PATTERNS[@]}"; do
      echo "  - $pattern"
    done
    exit 1
  fi
done

exit 0

# Usage:
# 1. Save this script to .git/hooks/pre-push
# 2. Make the script executable: chmod +x .git/hooks/pre-push
```