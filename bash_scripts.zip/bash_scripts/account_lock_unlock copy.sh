# This script takes a list of usernames from a file and either locks or unlocks their accounts based on user input.

# Function to lock an account
lock_account() {
  username=$1
  sudo passwd -l "$username"
  if [ $? -eq 0 ]; then
    echo "Account locked for user: $username"
  else
    echo "Failed to lock account for user: $username"
  fi
}

# Function to unlock an account
unlock_account() {
  username=$1
  sudo passwd -u "$username"
  if [ $? -eq 0 ]; then
    echo "Account unlocked for user: $username"
  else
    echo "Failed to unlock account for user: $username"
  fi
}

# Main script logic
if [ $# -ne 2 ]; then
  echo "Usage: $0 <username_file> <lock|unlock>"
  exit 1
fi

username_file=$1
action=$2

if [ ! -f "$username_file" ]; then
  echo "Error: Username file '$username_file' not found."
  exit 1
fi

if [[ "$action" != "lock" && "$action" != "unlock" ]]; then
  echo "Error: Action must be 'lock' or 'unlock'."
  exit 1
fi

while IFS= read -r username; do
  # Validate username (optional)
  if [[ ! "$username" =~ ^[a-zA-Z0-9._-]+$ ]]; then
    echo "Warning: Invalid username format: $username. Skipping."
    continue
  fi

  if [ "$action" == "lock" ]; then
    lock_account "$username"
  elif [ "$action" == "unlock" ]; then
    unlock_account "$username"
  fi
done < "$username_file"

exit 0
```