# This script demonstrates how to use valgrind's cachegrind tool for cache profiling.
# It compiles a simple C program, then runs it under valgrind with cachegrind,
# and finally analyzes the resulting cachegrind output file.

# Compile a simple C program (replace with your own C program).
gcc -Wall -O2 -o myprogram myprogram.c

# Run the compiled program under valgrind with cachegrind.
valgrind --tool=cachegrind ./myprogram

# Optional: Analyze the cachegrind output file (cachegrind.out.<pid>).
# cg_annotate cachegrind.out.<pid>

# File usage: ./cachegrind_example.sh
```