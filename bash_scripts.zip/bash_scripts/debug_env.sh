# This script demonstrates how to use GDB to examine environment variables of a running process.
# It first starts a simple program that prints environment variables and then pauses.
# Then, it uses GDB to attach to the process and print the values of specific environment variables.

# Usage: ./debug_env.sh

# Compile and run the C program in background
gcc -g env_program.c -o env_program
./env_program &
pid=$!
sleep 1 # Allow the program to start

# Use gdb to attach to the process
gdb -p $pid <<EOF
# Print environment variables
print getenv("HOME")
print getenv("USER")
print getenv("PATH")

# Detach from the process and quit gdb
detach
quit
EOF

# Kill the program
kill $pid
wait $pid

# Cleanup the executable
rm -f env_program

```

```c
// filename: env_program.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    printf("Starting the process...\n");
    printf("PID: %d\n", getpid());
    // Sleep to allow time for gdb to attach.
    sleep(60);
    printf("Exiting the process.\n");
    return 0;
}
```