# This script extracts data from a Google Bigtable instance and saves it to a CSV file in Cloud Storage.
# It uses the `cbt` command-line tool to read data from Bigtable.
# It then formats the data as CSV and uploads it to a specified Cloud Storage bucket.

# Set variables
PROJECT_ID="your-gcp-project-id"  # Replace with your GCP project ID
INSTANCE_ID="your-bigtable-instance-id"  # Replace with your Bigtable instance ID
TABLE_NAME="your-bigtable-table-name"  # Replace with your Bigtable table name
COLUMN_FAMILY="your-bigtable-column-family" # Replace with your column family
GCS_BUCKET="your-gcs-bucket"  # Replace with your GCS bucket name
GCS_FILE_PREFIX="bigtable-export" #File prefix for GCS upload.
TIMESTAMP=$(date +%Y%m%d%H%M%S)
GCS_FILE_NAME="${GCS_FILE_PREFIX}-${TIMESTAMP}.csv"
TEMP_FILE="/tmp/bigtable_data.txt"
CSV_HEADER="RowKey,ColumnFamily:Qualifier,Timestamp,Value" #Add CSV header

# Authenticate with Google Cloud (if needed - e.g., running on a VM without service account)
# gcloud auth activate-service-account --key-file=/path/to/your/service-account-key.json

# Create temp file
touch ${TEMP_FILE}

# Function to handle errors
error_exit() {
  echo "ERROR: $1" >&2
  exit 1
}

# Check if cbt is installed
if ! command -v cbt &> /dev/null
then
    error_exit "cbt command not found. Please install the Cloud Bigtable command-line tool."
fi

# Check if gcloud is installed
if ! command -v gsutil &> /dev/null
then
    error_exit "gsutil command not found. Please install the Cloud Storage command-line tool."
fi

# Read data from Bigtable using cbt
echo "Reading data from Bigtable..."
cbt -project=$PROJECT_ID -instance=$INSTANCE_ID read $TABLE_NAME > $TEMP_FILE || error_exit "Failed to read data from Bigtable."

# Format the data as CSV
echo "Formatting data as CSV..."
{
  echo "$CSV_HEADER"
  sed 's/ //g; s/^Row.\(.*=\)/\1,/g; s/column=\(.*:\(.*)\),timestamp=\(.*\),value=\(.*\)/\1:\2,\3,\4/g; s/^\(.*\),.*$/\1/g' $TEMP_FILE | sed '/^$/d'
} > /tmp/bigtable_data.csv || error_exit "Failed to format data as CSV."

# Upload the CSV file to Cloud Storage
echo "Uploading CSV file to Cloud Storage..."
gsutil cp /tmp/bigtable_data.csv gs://${GCS_BUCKET}/${GCS_FILE_NAME} || error_exit "Failed to upload file to Cloud Storage."

# Clean up the temporary file
echo "Cleaning up temporary files..."
rm -f $TEMP_FILE /tmp/bigtable_data.csv

echo "Data extraction and upload complete."
echo "File uploaded to gs://${GCS_BUCKET}/${GCS_FILE_NAME}"
exit 0
```