# This script uses curl to fetch the deployments for a given GitHub repository via the API
# and uses jq to list their statuses and environments.

# Check if the repository owner and name are provided as command line arguments.
if [ $# -ne 2 ]; then
  echo "Usage: $0 <repository_owner> <repository_name>"
  exit 1
fi

# Set the repository owner and name.
REPOSITORY_OWNER="$1"
REPOSITORY_NAME="$2"

# Set the GitHub API endpoint.
API_URL="https://api.github.com/repos/$REPOSITORY_OWNER/$REPOSITORY_NAME/deployments"

# Check if a GitHub token is set as an environment variable.
if [ -z "$GITHUB_TOKEN" ]; then
  echo "Error: GITHUB_TOKEN environment variable not set."
  echo "Please set your GitHub token as an environment variable to authenticate with the GitHub API."
  exit 1
fi

# Fetch the deployments using curl and jq.
curl -s -H "Accept: application/vnd.github+json" -H "Authorization: Bearer $GITHUB_TOKEN" "$API_URL" | \
jq -r '.[] | "\(.environment): \(.statuses[0].state)"'
```