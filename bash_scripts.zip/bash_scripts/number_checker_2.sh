# This script checks if a given number is divisible by both 3 and 5,
# and also if it's an even number greater than 30, using nested if statements.

# Usage: ./number_checker.sh <number>

number=$1

if [[ ! "$number" =~ ^[0-9]+$ ]]; then
  echo "Error: Input must be a non-negative integer."
  exit 1
fi

if (( number % 3 == 0 )); then
  if (( number % 5 == 0 )); then
    echo "$number is divisible by both 3 and 5."
  else
    echo "$number is divisible by 3, but not 5."
  fi

  if (( number % 2 == 0 )); then
    if (( number > 30 )); then
      echo "$number is an even number greater than 30."
    else
      echo "$number is an even number but not greater than 30."
    fi
  else
    echo "$number is not an even number."
  fi
else
  echo "$number is not divisible by 3."
fi
```