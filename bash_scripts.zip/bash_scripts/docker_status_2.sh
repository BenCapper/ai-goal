#
# This script lists all Docker containers and their current status.
# It uses the 'docker ps -a' command to retrieve the information
# and then formats the output to display the container ID, name, and status.

docker ps -a --format "table {{.ID}}\t{{.Names}}\t{{.Status}}"
```