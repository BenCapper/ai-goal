#
# This script automates the setup and management of a basic Open vSwitch (OVS) bridge
# with a specified datapath type.
# It checks if OVS is installed, creates a bridge, sets the datapath type, and then displays the bridge status.
#
# Usage: ./ovs_bridge_setup.sh <bridge_name> <datapath_type>

# Check if the script is run with root privileges
if [[ $EUID -ne 0 ]]; then
  echo "This script must be run as root."
  exit 1
fi

# Check if OVS is installed
if ! command -v ovs-vsctl &> /dev/null; then
  echo "Open vSwitch (OVS) is not installed. Please install it before running this script."
  echo "Example installation (Debian/Ubuntu): sudo apt-get update && sudo apt-get install openvswitch-switch"
  exit 1
fi

# Set default values if no arguments are provided
BRIDGE_NAME="${1:-br0}" # Default bridge name is br0
DATAPATH_TYPE="${2:-system}" # Default datapath type is system

# Check if bridge name and datapath type are provided
if [ -z "$BRIDGE_NAME" ] || [ -z "$DATAPATH_TYPE" ]; then
  echo "Error: Bridge name and datapath type must be provided."
  echo "Usage: ./ovs_bridge_setup.sh <bridge_name> <datapath_type>"
  exit 1
fi

# Create the OVS bridge if it doesn't exist
if ! ovs-vsctl br-exists "$BRIDGE_NAME"; then
  echo "Creating OVS bridge: $BRIDGE_NAME with datapath type: $DATAPATH_TYPE"
  ovs-vsctl add-br "$BRIDGE_NAME" -- set Bridge "$BRIDGE_NAME" datapath_type="$DATAPATH_TYPE"
  if [ $? -ne 0 ]; then
    echo "Error creating bridge $BRIDGE_NAME"
    exit 1
  fi
else
  echo "OVS bridge $BRIDGE_NAME already exists. Setting datapath type to $DATAPATH_TYPE if it's different."
  CURRENT_DATAPATH_TYPE=$(ovs-vsctl get Bridge "$BRIDGE_NAME" datapath_type)
  if [ "$CURRENT_DATAPATH_TYPE" != "$DATAPATH_TYPE" ]; then
     ovs-vsctl set Bridge "$BRIDGE_NAME" datapath_type="$DATAPATH_TYPE"
     if [ $? -ne 0 ]; then
       echo "Error setting datapath type for bridge $BRIDGE_NAME"
       exit 1
     fi
  else
    echo "Datapath type is already set to $DATAPATH_TYPE. No change made."
  fi
fi

# Display the bridge status
echo "OVS Bridge Status:"
ovs-vsctl show

exit 0
#Usage: ./ovs_bridge_setup.sh <bridge_name> <datapath_type>
```