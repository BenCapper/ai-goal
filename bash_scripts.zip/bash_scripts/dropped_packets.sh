# This script finds network interfaces with dropped packets using the 'ip' command.
# It then extracts the interface name and the number of dropped packets.

# Use: ./dropped_packets.sh

ip -s link show | grep "dropped" | awk '{print $2, $NF}'
```