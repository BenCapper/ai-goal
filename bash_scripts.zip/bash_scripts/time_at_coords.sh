# This script displays the current time in a user-specified list of geographical coordinates.
# It utilizes the 'geonames' command-line tool to retrieve timezone information
# based on latitude and longitude, and then uses 'date' with the obtained timezone
# to display the current time.

# Function to get the timezone ID for given coordinates
get_timezone() {
  local lat=$1
  local lon=$2
  local timezone_id

  timezone_id=$(geonames timezone lat=$lat long=$lon | awk -F= '$1=="timezoneId"{print $2}')

  if [ -z "$timezone_id" ]; then
    echo "Error: Could not retrieve timezone for coordinates ($lat, $lon)"
    return 1
  fi

  echo "$timezone_id"
  return 0
}

# Main script
if [ $# -eq 0 ]; then
  echo "Usage: $0 <lat1,lon1> <lat2,lon2> ..."
  echo "Example: $0 40.71,-74.01 34.05,-118.24"
  exit 1
fi

for coord in "$@"; do
  local lat=$(echo "$coord" | cut -d',' -f1)
  local lon=$(echo "$coord" | cut -d',' -f2)

  timezone_id=$(get_timezone "$lat" "$lon")

  if [ $? -ne 0 ]; then
    continue
  fi

  echo "Time at ($lat, $lon) - $timezone_id: $(TZ="$timezone_id" date)"
done

exit 0
```