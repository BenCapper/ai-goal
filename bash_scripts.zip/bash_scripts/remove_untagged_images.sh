# This script removes all untagged Docker images from the system.
# Untagged images are often referred to as "dangling" images.
# It uses `docker images` to list all images, filters for those with the tag "<none>",
# and then uses `docker rmi` to remove them.
# It's recommended to run this script periodically to free up disk space.

# Get a list of untagged images (those with tag "<none>").
UNTAGGED_IMAGES=$(docker images --filter "dangling=true" -q)

# Check if any untagged images were found.
if [ -z "$UNTAGGED_IMAGES" ]; then
  echo "No untagged images found."
else
  # Iterate over the list of untagged images and remove them.
  for IMAGE_ID in $UNTAGGED_IMAGES; do
    echo "Removing untagged image: $IMAGE_ID"
    docker rmi "$IMAGE_ID"
  done
fi

echo "Finished removing untagged images."
```