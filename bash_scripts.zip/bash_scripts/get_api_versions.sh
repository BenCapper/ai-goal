# This script uses the oc command-line tool to retrieve and list all supported API versions
# in the current OpenShift/Kubernetes cluster.

# Usage: ./get_api_versions.sh

oc api-versions
```