# This script takes a list of YouTube video URLs as input and downloads the audio track only for each video.
# It uses yt-dlp for downloading.

# Check if yt-dlp is installed
if ! command -v yt-dlp &> /dev/null
then
    echo "yt-dlp is not installed. Please install it before running this script."
    exit 1
fi

# Function to download audio from a single YouTube URL
download_audio() {
  local url=$1
  echo "Downloading audio from: $url"
  yt-dlp -x --audio-format mp3 -o '%(title)s.%(ext)s' "$url"
  echo "Finished downloading audio from: $url"
}

# Check if any URLs were provided as arguments
if [ $# -eq 0 ]; then
  echo "Usage: $0 <youtube_url_1> <youtube_url_2> ..."
  echo "Alternatively, provide a file containing URLs one per line: $0 -f <url_file>"
  exit 1
fi

# Handle the -f option for reading URLs from a file
if [ "$1" == "-f" ]; then
  if [ -z "$2" ]; then
    echo "Error: Please specify the file containing URLs."
    exit 1
  fi

  if [ ! -f "$2" ]; then
    echo "Error: File '$2' not found."
    exit 1
  fi

  while IFS= read -r url; do
    download_audio "$url"
  done < "$2"
else
  # Iterate over the provided URLs and download audio
  for url in "$@"; do
    download_audio "$url"
  done
fi

echo "All downloads completed."

exit 0
```