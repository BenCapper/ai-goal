#
# This script automates the deployment of a new database schema version.
# It connects to the database, applies schema changes from a SQL file,
# and logs the output of the schema update process.

# Configuration
DB_HOST="localhost"
DB_NAME="your_database_name"
DB_USER="your_db_user"
DB_PASSWORD="your_db_password"
SCHEMA_FILE="schema_update.sql"
LOG_FILE="schema_update.log"

# Function to log messages
log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"
  echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" # Also print to console
}

# Check if the schema file exists
if [ ! -f "$SCHEMA_FILE" ]; then
  log "Error: Schema file '$SCHEMA_FILE' not found."
  exit 1
fi

# Apply the schema changes
log "Applying schema changes from '$SCHEMA_FILE' to database '$DB_NAME'..."
mysql -h "$DB_HOST" -u "$DB_USER" -p"$DB_PASSWORD" "$DB_NAME" < "$SCHEMA_FILE" &> "$LOG_FILE"

# Check the exit code of the mysql command
if [ $? -eq 0 ]; then
  log "Schema update completed successfully."
else
  log "Error: Schema update failed. Check '$LOG_FILE' for details."
  exit 1
fi

exit 0
```