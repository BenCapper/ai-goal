# This script gathers selective facts from a specific host using Ansible's gather_subset.

# Check if Ansible is installed.
if ! command -v ansible &> /dev/null; then
  echo "Ansible is not installed. Please install Ansible before running this script."
  exit 1
fi

# Check if a host is provided as an argument.
if [ -z "$1" ]; then
  echo "Usage: $0 <hostname> [subset]"
  echo "Example: $0 webserver1 hardware"
  echo "Example: $0 webserver1 hardware,network"
  exit 1
fi

HOST=$1
SUBSET="${2:-all}" # default to "all" if no subset is provided

# Check if the host is reachable via Ansible. This assumes a basic Ansible inventory is already set up.
ansible -m ping "$HOST" > /dev/null 2>&1
if [ $? -ne 0 ]; then
  echo "Host '$HOST' is not reachable via Ansible. Check your inventory."
  exit 1
fi

# Gather facts using Ansible with the specified subset.
ansible "$HOST" -m setup -a "filter=ansible_* gather_subset=$SUBSET"

```