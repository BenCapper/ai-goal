# This script reads an XML file and extracts the value of a specific attribute
# from all elements with a given tag.

# Usage: ./extract_xml_attribute.sh <xml_file> <tag_name> <attribute_name>

# Check if the correct number of arguments is provided.
if [ $# -ne 3 ]; then
  echo "Usage: $0 <xml_file> <tag_name> <attribute_name>"
  exit 1
fi

# Assign the arguments to variables.
xml_file="$1"
tag_name="$2"
attribute_name="$3"

# Check if the XML file exists.
if [ ! -f "$xml_file" ]; then
  echo "Error: XML file '$xml_file' not found."
  exit 1
fi

# Use xmllint and xpath to extract the attribute values.
# The xpath expression searches for elements with the specified tag name
# and extracts the value of the specified attribute.
xpath_expression="//${tag_name}/@${attribute_name}"

# Execute the xmllint command and pipe the output to awk.
xmllint --xpath "$xpath_expression" "$xml_file" | awk -F'=' '{print $2}' | tr -d '"'

# Example Usage:
# ./extract_xml_attribute.sh data.xml item id
```