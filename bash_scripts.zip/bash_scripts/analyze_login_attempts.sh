# This script analyzes system audit logs for successful and failed login attempts.
# It generates a report of login activity by user and source IP address.

# Usage: ./analyze_login_attempts.sh <audit_log_file>

# Check if auditlog is present, if not show the location.
if ! command -v auditlog >/dev/null 2>&1; then
  echo "Error: auditlog is not installed."
  echo "Please install auditlog, e.g., using: apt-get install auditlog or yum install auditlog"
  exit 1
fi

if [ $# -ne 1 ]; then
  echo "Usage: $0 <audit_log_file>"
  exit 1
fi

AUDIT_LOG_FILE="$1"

if [ ! -f "$AUDIT_LOG_FILE" ]; then
  echo "Error: Audit log file '$AUDIT_LOG_FILE' not found."
  exit 1
fi

# Function to extract username from audit log message
extract_username() {
  grep "user=" "$1" | awk -F 'user=' '{print $2}' | awk -F ' ' '{print $1}'
}

# Function to extract source IP address from audit log message
extract_ip() {
  grep "addr=" "$1" | awk -F 'addr=' '{print $2}' | awk -F ' ' '{print $1}'
}


# Analyze successful login attempts
echo "Successful Login Attempts:"
echo "--------------------------"

grep "USER_LOGIN" "$AUDIT_LOG_FILE" |
while read -r line; do
  username=$(extract_username "$line")
  ip_address=$(extract_ip "$line")
  if [ -n "$username" ] && [ -n "$ip_address" ]; then
    echo "User: $username, IP: $ip_address"
  else
      username=$(grep "username=" "$line" | awk -F 'username=' '{print $2}' | awk -F ' ' '{print $1}')
      ip_address=$(grep "src=" "$line" | awk -F 'src="[[::ffff:]]*"?' '{print $2}' | awk -F '"' '{print $1}')
      if [ -n "$username" ] && [ -n "$ip_address" ]; then
        echo "User: $username, IP: $ip_address"
      else
        username=$(grep "acct=" "$line" | awk -F 'acct=' '{print $2}' | awk -F ' ' '{print $1}')
        ip_address=$(grep "a0=" "$line" | awk -F 'a0=' '{print $2}' | awk -F ' ' '{print $1}')

        if [ -n "$username" ] && [ -n "$ip_address" ]; then
          echo "User: $username, IP: $ip_address"
        fi

      fi
  fi
done | sort | uniq -c | sort -nr

echo ""

# Analyze failed login attempts
echo "Failed Login Attempts:"
echo "------------------------"

grep "USER_AUTH" "$AUDIT_LOG_FILE" | grep "res=failed" |
while read -r line; do
  username=$(extract_username "$line")
  ip_address=$(extract_ip "$line")
  if [ -n "$username" ] && [ -n "$ip_address" ]; then
    echo "User: $username, IP: $ip_address"
  else
      username=$(grep "username=" "$line" | awk -F 'username=' '{print $2}' | awk -F ' ' '{print $1}')
      ip_address=$(grep "src=" "$line" | awk -F 'src="[[::ffff:]]*"?' '{print $2}' | awk -F '"' '{print $1}')
      if [ -n "$username" ] && [ -n "$ip_address" ]; then
        echo "User: $username, IP: $ip_address"
      else
        username=$(grep "acct=" "$line" | awk -F 'acct=' '{print $2}' | awk -F ' ' '{print $1}')
        ip_address=$(grep "a0=" "$line" | awk -F 'a0=' '{print $2}' | awk -F ' ' '{print $1}')

        if [ -n "$username" ] && [ -n "$ip_address" ]; then
          echo "User: $username, IP: $ip_address"
        fi
      fi
  fi

done | sort | uniq -c | sort -nr

echo ""
```