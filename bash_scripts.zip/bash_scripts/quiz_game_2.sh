# This script simulates a simple quiz game.
# It allows the user to choose a category and then answers questions from that category.
# The quiz continues until the user chooses to quit.

# Usage: ./quiz_game.sh

# Function to ask a question and check the answer
ask_question() {
  local question="$1"
  local answer="$2"
  local user_answer

  echo "$question"
  read -p "Your answer: " user_answer

  if [[ "$user_answer" == "$answer" ]]; then
    echo "Correct!"
    return 0
  else
    echo "Incorrect. The correct answer is: $answer"
    return 1
  fi
}

# Quiz questions for different categories
declare -A questions
questions["math"]=(
  "What is 2 + 2?|4"
  "What is 10 / 2?|5"
  "What is 5 * 5?|25"
)
questions["history"]=(
  "When did World War II end?|1945"
  "Who was the first president of the United States?|George Washington"
  "When did the French Revolution start?|1789"
)
questions["science"]=(
  "What is the chemical symbol for water?|H2O"
  "What is the speed of light?|299792458 m/s"
  "What is the largest planet in our solar system?|Jupiter"
)

# Main quiz loop
while true; do
  # Display category options
  echo "Choose a category:"
  echo "1. Math"
  echo "2. History"
  echo "3. Science"
  echo "4. Quit"

  read -p "Enter your choice (1-4): " choice

  case "$choice" in
    1)
      category="math"
      ;;
    2)
      category="history"
      ;;
    3)
      category="science"
      ;;
    4)
      echo "Quitting the quiz. Goodbye!"
      exit 0
      ;;
    *)
      echo "Invalid choice. Please enter a number between 1 and 4."
      continue
      ;;
  esac

  # Ask questions from the selected category
  echo "Starting quiz in the $category category..."
  local question_count=${#questions[$category][@]}
  local correct_answers=0

  for i in $(seq 0 $((question_count - 1))); do
    local question_data="${questions[$category][$i]}"
    local question=$(echo "$question_data" | cut -d'|' -f1)
    local answer=$(echo "$question_data" | cut -d'|' -f2)

    if ask_question "$question" "$answer"; then
      ((correct_answers++))
    fi
  done

  echo "Quiz finished. You answered $correct_answers out of $question_count questions correctly."

done
```