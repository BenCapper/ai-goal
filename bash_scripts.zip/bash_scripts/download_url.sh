# This script downloads a file from a specified URL and saves it 
# with the filename derived from the URL.

# Check if a URL is provided as an argument
if [ -z "$1" ]; then
  echo "Usage: $0 <URL>"
  exit 1
fi

# Get the URL from the first argument
URL="$1"

# Extract the filename from the URL
FILENAME=$(basename "$URL")

# Use wget to download the file
wget -O "$FILENAME" "$URL"

# Check if the download was successful
if [ $? -eq 0 ]; then
  echo "File downloaded successfully to $FILENAME"
else
  echo "Error downloading file"
  exit 1
fi
```