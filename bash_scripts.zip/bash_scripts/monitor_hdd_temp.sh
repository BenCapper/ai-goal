# This script monitors the temperature of hard drives using hddtemp.
# It checks if any drive exceeds a critical temperature threshold and sends an alert if it does.

# Usage: ./monitor_hdd_temp.sh

# Configuration
CRITICAL_TEMP=55  # Degrees Celsius - Adjust as needed
LOG_FILE="/tmp/hdd_temp_monitor.log"
ALERT_EMAIL="your_email@example.com" # Change to your email address

# Function to get HDD temperatures using hddtemp
get_hdd_temps() {
  hddtemp /dev/sd? 2> /dev/null | awk -F ': ' '{print $4, $1}'
}

# Function to check temperatures and send alerts
check_temps() {
  while read -r temp drive; do
    temp=$(echo "$temp" | tr -d '°C') #Remove the degree C character.
    if [[ "$temp" -gt "$CRITICAL_TEMP" ]]; then
      echo "$(date) - WARNING: Drive $drive temperature is $temp°C (Critical threshold: $CRITICAL_TEMP°C)" | tee -a "$LOG_FILE"
      echo "Subject: HDD Temperature Alert" | cat - "$LOG_FILE" | mail -s "HDD Temperature Alert" "$ALERT_EMAIL"
    fi
  done < <(get_hdd_temps)
}

# Main script logic
if ! command -v hddtemp &> /dev/null; then
  echo "hddtemp is not installed. Please install it to use this script."
  exit 1
fi

check_temps
```