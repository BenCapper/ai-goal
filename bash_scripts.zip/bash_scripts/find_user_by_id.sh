# This script finds the username associated with a given user ID by iterating through /etc/passwd.
# It declares a variable USER_ID, reads each line of /etc/passwd into USER_INFO,
# then uses cut and an if statement to check if the line contains the specified USER_ID.
# If found, it extracts and prints the username.

# Usage: ./find_user_by_id.sh <user_id>

USER_ID=$1

if [ -z "$USER_ID" ]; then
  echo "Error: Please provide a user ID as an argument."
  exit 1
fi

while IFS=: read -r USERNAME _ UID _ _ _ _ ; do
  if [ "$UID" == "$USER_ID" ]; then
    echo "Username for UID $USER_ID: $USERNAME"
    exit 0
  fi
done < /etc/passwd

echo "User with ID $USER_ID not found in /etc/passwd"
exit 1
```