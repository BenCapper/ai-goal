# This script reads a string from the user and checks if it is a palindrome.
# It uses the 'rev' command to reverse the string and then compares it to the original string.
#
# Usage: ./palindrome_check.sh

# Read the string from the user.
read -p "Enter a string: " TEXT_TO_REVERSE

# Reverse the string using 'rev'.
REVERSED_TEXT=$(echo "$TEXT_TO_REVERSE" | rev)

# Check if the string is a palindrome using an if statement.
if [ "$TEXT_TO_REVERSE" = "$REVERSED_TEXT" ]; then
  echo "$TEXT_TO_REVERSE is a palindrome."
else
  echo "$TEXT_TO_REVERSE is not a palindrome."
fi
```