# This script checks the value of a variable representing a day of the week
# and prints a corresponding activity using an if-elif-else statement.
# Usage: ./day_activity.sh

# Set the day of the week (example)
day="Wednesday"

if [ "$day" = "Monday" ]; then
  echo "Monday - Start of the week"
elif [ "$day" = "Tuesday" ]; then
  echo "Tuesday - Getting things done"
elif [ "$day" = "Wednesday" ]; then
  echo "Wednesday - Hump day!"
elif [ "$day" = "Thursday" ]; then
  echo "Thursday - Almost there"
elif [ "$day" = "Friday" ]; then
  echo "Friday - Weekend is coming!"
elif [ "$day" = "Saturday" ]; then
  echo "Saturday - Time to relax"
elif [ "$day" = "Sunday" ]; then
  echo "Sunday - Get ready for the week"
else
  echo "Invalid day"
fi
# ./day_activity.sh
```