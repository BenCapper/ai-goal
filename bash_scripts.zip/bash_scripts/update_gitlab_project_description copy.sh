# This script updates the description of a GitLab project using the GitLab API.
# It requires the project ID and a personal access token with API access.
# Usage: ./update_gitlab_project_description.sh <project_id> <personal_access_token> "<new_description>"

#!/bin/bash

# Check if the correct number of arguments are provided
if [ $# -ne 3 ]; then
  echo "Usage: ./update_gitlab_project_description.sh <project_id> <personal_access_token> \"<new_description>\""
  exit 1
fi

# Assign arguments to variables
PROJECT_ID=$1
PERSONAL_ACCESS_TOKEN=$2
NEW_DESCRIPTION="$3"

# GitLab API endpoint for updating a project
API_ENDPOINT="https://gitlab.com/api/v4/projects/$PROJECT_ID"

# Construct the request data
DATA="description=$NEW_DESCRIPTION"

# Use curl to make the PUT request to update the project description
curl --request PUT \
     --header "PRIVATE-TOKEN: $PERSONAL_ACCESS_TOKEN" \
     --header "Content-Type: application/x-www-form-urlencoded" \
     --data "$DATA" \
     "$API_ENDPOINT"

# Check the exit code of curl
if [ $? -eq 0 ]; then
  echo "Project description updated successfully."
else
  echo "Failed to update project description."
fi

exit 0
```