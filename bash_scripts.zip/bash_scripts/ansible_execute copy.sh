# This script executes an Ansible playbook with specific SSH options:
 #   - Uses a specific SSH private key
 #   - Connects to a non-standard SSH port
 #   - Enables SSH agent forwarding
 #   - Sets a custom SSH timeout
 #   - Allows custom SSH options (e.g., StrictHostKeyChecking=no)

 #!/bin/bash

 # Set variables
 PLAYBOOK="your_playbook.yml" # Replace with your playbook file name
 INVENTORY="inventory"        # Replace with your inventory file name
 PRIVATE_KEY="/path/to/your/private_key" # Replace with your private key path
 SSH_PORT=2222                # Replace with your custom SSH port
 SSH_TIMEOUT=30               # Timeout in seconds
 SSH_OPTIONS="-o StrictHostKeyChecking=no" # Customize SSH options

 # Construct the ansible-playbook command
 ANSIBLE_COMMAND="ansible-playbook \
     -i ${INVENTORY} \
     --private-key ${PRIVATE_KEY} \
     -c paramiko \
     -e ansible_ssh_port=${SSH_PORT} \
     --timeout ${SSH_TIMEOUT} \
     -e ansible_ssh_common_args='${SSH_OPTIONS} -o ForwardAgent=yes' \
     ${PLAYBOOK}"

 # Execute the Ansible playbook
 echo "Executing Ansible playbook with custom SSH options..."
 eval ${ANSIBLE_COMMAND}

 # Check the exit code
 if [ $? -eq 0 ]; then
     echo "Ansible playbook executed successfully."
 else
     echo "Ansible playbook execution failed."
 fi
 ```