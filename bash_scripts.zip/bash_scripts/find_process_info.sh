# This script finds the process ID (PID) and full command line of a process 
# with a given name (provided as a command-line argument).

# Usage: ./find_process_info.sh <process_name>

# Check if the process name is provided as an argument
if [ -z "$1" ]; then
  echo "Usage: $0 <process_name>"
  exit 1
fi

# Use ps to find the PID and full command line of the process
pid=$(ps -ef | grep "$1" | grep -v grep | awk '{print $2}')
command=$(ps -ef | grep "$1" | grep -v grep | awk '{$1=$2=$3=$4=""; print $0}')

# Check if the process was found
if [ -z "$pid" ]; then
  echo "Process '$1' not found."
  exit 1
fi

# Print the PID and command
echo "Process Name: $1"
echo "PID: $pid"
echo "Command: $command"
```