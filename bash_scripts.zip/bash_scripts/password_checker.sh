# This script checks if a given string (password) meets specific criteria:
# 1. Length between 8 and 12 characters.
# 2. Contains at least one uppercase letter.
# 3. Contains at least one lowercase letter.
# 4. Contains at least one digit.
# Usage: ./password_checker.sh <password>

# Get the password from the command line argument.
password="$1"

# Check if the password is provided.
if [ -z "$password" ]; then
  echo "Error: Please provide a password as an argument."
  exit 1
fi

# Get the length of the password.
length=${#password}

# Check if the length is within the acceptable range (8-12).
if [ "$length" -ge 8 ]; then
  if [ "$length" -le 12 ]; then

    # Check for uppercase letter.
    if [[ "$password" =~ [A-Z] ]]; then

      # Check for lowercase letter.
      if [[ "$password" =~ [a-z] ]]; then

        # Check for digit.
        if [[ "$password" =~ [0-9] ]]; then

          echo "Password is valid."
          exit 0
        else
          echo "Password must contain at least one digit."
          exit 1
        fi

      else
        echo "Password must contain at least one lowercase letter."
        exit 1
      fi

    else
      echo "Password must contain at least one uppercase letter."
      exit 1
    fi

  else
    echo "Password must be no more than 12 characters."
    exit 1
  fi
else
  echo "Password must be at least 8 characters."
  exit 1
fi
```