# This script fetches all changes from a remote Git repository without merging them into the current branch.

# Check if the remote name is provided as an argument. If not, default to "origin".
remote="${1:-origin}"

# Fetch all changes from the specified remote.
# The --all flag fetches all branches and tags.
# The --prune flag removes any remote-tracking references that no longer exist on the remote.
git fetch --all --prune "$remote"

echo "Successfully fetched changes from remote: $remote"
```