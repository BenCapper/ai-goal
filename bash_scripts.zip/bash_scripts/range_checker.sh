# This script reads a number from the user and checks if it falls within one of three predefined ranges.
# It uses an if-elif-else statement for the comparison.
# usage: ./range_checker.sh

# Read the input number from the user.
read -p "Enter a number: " INPUT_VALUE

# Check if the input is a valid integer
if ! [[ "$INPUT_VALUE" =~ ^-?[0-9]+$ ]]; then
  echo "Error: Input must be an integer."
  exit 1
fi

# Define the ranges.
RANGE1_LOWER=1
RANGE1_UPPER=10
RANGE2_LOWER=20
RANGE2_UPPER=30
RANGE3_LOWER=40
RANGE3_UPPER=50

# Check which range the input value falls into.
if (( INPUT_VALUE >= RANGE1_LOWER && INPUT_VALUE <= RANGE1_UPPER )); then
  echo "$INPUT_VALUE is within the range $RANGE1_LOWER-$RANGE1_UPPER."
elif (( INPUT_VALUE >= RANGE2_LOWER && INPUT_VALUE <= RANGE2_UPPER )); then
  echo "$INPUT_VALUE is within the range $RANGE2_LOWER-$RANGE2_UPPER."
elif (( INPUT_VALUE >= RANGE3_LOWER && INPUT_VALUE <= RANGE3_UPPER )); then
  echo "$INPUT_VALUE is within the range $RANGE3_LOWER-$RANGE3_UPPER."
else
  echo "$INPUT_VALUE is outside all defined ranges."
fi
```