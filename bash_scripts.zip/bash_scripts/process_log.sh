# This script reads a log file line by line.
# It filters the lines based on a specific timestamp format.
# Only lines that start with the timestamp format are printed.

# Usage: ./process_log.sh <log_file>

if [ $# -ne 1 ]; then
  echo "Usage: $0 <log_file>"
  exit 1
fi

log_file="$1"
timestamp_format="^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}"

if [ ! -f "$log_file" ]; then
  echo "Error: Log file '$log_file' not found."
  exit 1
fi

while IFS= read -r line; do
  if [[ "$line" =~ $timestamp_format ]]; then
    echo "$line"
  fi
done < "$log_file"

# ./process_log.sh mylog.log
```