# This script retrieves artifacts from a specific GitLab job in a pipeline,
# filters them by name using a regular expression, and downloads the matching artifacts.

# Set variables
GITLAB_URL="https://gitlab.com" # Replace with your GitLab instance URL if not gitlab.com
GITLAB_TOKEN="YOUR_GITLAB_TOKEN" # Replace with your GitLab personal access token
PROJECT_ID="YOUR_PROJECT_ID" # Replace with your GitLab project ID
PIPELINE_ID="YOUR_PIPELINE_ID" # Replace with the ID of the pipeline
JOB_NAME="YOUR_JOB_NAME" # Replace with the name of the job whose artifacts you want
ARTIFACT_REGEX=".*\.log" # Replace with the regular expression to filter artifacts by name
DOWNLOAD_DIR="./artifacts" # Directory to download the artifacts to

# Create the download directory if it doesn't exist
mkdir -p "$DOWNLOAD_DIR"

# Get the job ID
JOB_ID=$(curl --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
            "$GITLAB_URL/api/v4/projects/$PROJECT_ID/pipelines/$PIPELINE_ID/jobs" | \
            jq -r ".[] | select(.name == \"$JOB_NAME\") | .id")

# Check if the job ID was found
if [ -z "$JOB_ID" ]; then
  echo "Error: Job with name '$JOB_NAME' not found in pipeline '$PIPELINE_ID'."
  exit 1
fi

# Get the list of artifacts
ARTIFACTS=$(curl --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
              "$GITLAB_URL/api/v4/projects/$PROJECT_ID/jobs/$JOB_ID/artifacts" | \
              jq -r '.[].name')

# Iterate over the artifacts and download matching ones
for ARTIFACT in $ARTIFACTS; do
  if [[ "$ARTIFACT" =~ $ARTIFACT_REGEX ]]; then
    echo "Downloading artifact: $ARTIFACT"
    curl --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
         --output "$DOWNLOAD_DIR/$ARTIFACT" \
         "$GITLAB_URL/api/v4/projects/$PROJECT_ID/jobs/$JOB_ID/artifacts/$ARTIFACT"
  else
    echo "Skipping artifact: $ARTIFACT (does not match regex)"
  fi
done

echo "Artifact download complete. Files saved to: $DOWNLOAD_DIR"
```