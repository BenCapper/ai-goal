# This script lists all Custom Resource Definitions (CRDs) in the OpenShift cluster
# using the 'oc get crd' command.

oc get crd
```