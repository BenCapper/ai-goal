# This script implements a basic file versioning tool.
# It tracks changes to text files by creating numbered backups.
# It allows users to revert to previous versions.
#
# Usage: ./version_control.sh <command> <file> [version]
# Commands:
#   init <file>     : Initialize version control for the given file.
#   track <file>    : Create a new version of the file.
#   revert <file> <version> : Revert the file to the specified version.
#   history <file>  : Show the version history of the file.

# Configuration
BACKUP_DIR=".versions"

# Function to initialize version control for a file
init_file() {
  local file="$1"

  if [ ! -f "$file" ]; then
    echo "Error: File '$file' does not exist."
    return 1
  fi

  if [ ! -d "$BACKUP_DIR" ]; then
    mkdir "$BACKUP_DIR"
  fi

  if [ -f "$BACKUP_DIR/$file.version" ]; then
    echo "Error: Version control already initialized for '$file'."
    return 1
  fi

  echo "1" > "$BACKUP_DIR/$file.version" # Initial version number
  cp "$file" "$BACKUP_DIR/$file.1"
  echo "Initialized version control for '$file'."
  return 0
}

# Function to track a new version of a file
track_file() {
  local file="$1"

  if [ ! -f "$BACKUP_DIR/$file.version" ]; then
    echo "Error: Version control not initialized for '$file'."
    return 1
  fi

  local version=$(cat "$BACKUP_DIR/$file.version")
  local new_version=$((version + 1))

  cp "$file" "$BACKUP_DIR/$file.$new_version"
  echo "$new_version" > "$BACKUP_DIR/$file.version"
  echo "Created version $new_version for '$file'."
  return 0
}

# Function to revert a file to a specific version
revert_file() {
  local file="$1"
  local version="$2"

  if [ ! -f "$BACKUP_DIR/$file.version" ]; then
    echo "Error: Version control not initialized for '$file'."
    return 1
  fi

  if [ ! -f "$BACKUP_DIR/$file.$version" ]; then
    echo "Error: Version '$version' does not exist for '$file'."
    return 1
  fi

  cp "$BACKUP_DIR/$file.$version" "$file"
  echo "Reverted '$file' to version $version."
  return 0
}

# Function to display the version history of a file
history_file() {
  local file="$1"

  if [ ! -f "$BACKUP_DIR/$file.version" ]; then
    echo "Error: Version control not initialized for '$file'."
    return 1
  fi

  echo "Version history for '$file':"
  local current_version=$(cat "$BACKUP_DIR/$file.version")
  for i in $(seq 1 "$current_version"); do
    if [ -f "$BACKUP_DIR/$file.$i" ]; then
      echo "  Version $i"
    fi
  done
  return 0
}

# Main execution block
if [ $# -lt 2 ]; then
  echo "Usage: $0 <command> <file> [version]"
  exit 1
fi

local command="$1"
local file="$2"

case "$command" in
  init)
    init_file "$file"
    ;;
  track)
    track_file "$file"
    ;;
  revert)
    if [ $# -lt 3 ]; then
      echo "Usage: $0 revert <file> <version>"
      exit 1
    fi
    local version="$3"
    revert_file "$file" "$version"
    ;;
  history)
    history_file "$file"
    ;;
  *)
    echo "Error: Invalid command '$command'."
    echo "Usage: $0 <command> <file> [version]"
    exit 1
    ;;
esac

exit 0
```