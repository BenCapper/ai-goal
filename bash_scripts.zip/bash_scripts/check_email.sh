# This script reads a line from standard input,
# then uses an if statement with regular expression
# matching to check if the line contains an email address.

# Usage: ./check_email.sh

read -r DATA

if [[ "$DATA" =~ [a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,} ]]; then
  echo "Line contains an email address."
else
  echo "Line does not contain an email address."
fi
```