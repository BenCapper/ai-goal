#
# This script demonstrates how to send an XML payload to an API endpoint
# using curl with the POST method. It sets the Content-Type header to
# indicate that the request body contains XML data.

# API endpoint URL
API_URL="https://example.com/api/endpoint"

# XML payload
XML_DATA='<?xml version="1.0" encoding="UTF-8"?>
<data>
  <item>
    <name>Example</name>
    <value>123</value>
  </item>
</data>'

# Send the POST request with XML data using curl
curl -X POST \
     -H "Content-Type: application/xml" \
     -d "$XML_DATA" \
     "$API_URL"
```