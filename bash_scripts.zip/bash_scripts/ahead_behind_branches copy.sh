# This script uses git to list all branches that are both ahead and behind the remote.

# Fetch the latest information from the remote.
git fetch origin

# Get the names of all local branches.
local_branches=$(git branch | awk '{print $1}')

# Iterate through each local branch.
for branch in $local_branches; do
  # Determine if the branch is ahead and behind the remote.
  ahead=$(git rev-list --count origin/$(echo $branch | tr -d '*') ..$(echo $branch | tr -d '*'))
  behind=$(git rev-list --count $(echo $branch | tr -d '*') ..origin/$(echo $branch | tr -d '*'))

  # If the branch is both ahead and behind, print its name.
  if [[ $ahead -gt 0 && $behind -gt 0 ]]; then
    echo "$branch"
  fi
done
```