# This script lists all role bindings for a specific role across all namespaces
# and outputs them in JSON format with indentation.  It includes the subjects,
# the role kind, API group, the namespace of the role binding, and any annotations or labels
# on the role binding.

# Usage: ./list_rolebindings.sh <role-name>

# Check if the role name is provided as an argument
if [ -z "$1" ]; then
  echo "Usage: ./list_rolebindings.sh <role-name>"
  exit 1
fi

role_name="$1"

# Get all role bindings in all namespaces and filter by the specified role name
# Output in JSON format with indentation.
oc get rolebinding --all-namespaces -o json | jq --arg role_name "$role_name" '.items[] | select(.roleRef.name == $role_name) | {metadata, subjects, roleRef}'
```