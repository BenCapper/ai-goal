# This script automates backups of etcd in a Kubernetes cluster.
# It retrieves the etcd endpoints and TLS credentials,
# then creates a backup using etcdctl and stores it in a specified directory.

# Configuration
BACKUP_DIR="/opt/etcd-backups"  # Directory to store backups
ETCDCTL_IMAGE="quay.io/coreos/etcd:v3.5.9" # etcdctl image version
SNAPSHOT_NAME="etcd_snapshot_$(date +%Y%m%d_%H%M%S).db" # Snapshot naming format
NAMESPACE="kube-system" # Namespace where etcd pods run
POD_LABEL="component=etcd" # Label to identify etcd pods

# Ensure the backup directory exists
mkdir -p "$BACKUP_DIR"

# Get the etcd endpoints
ETCD_ENDPOINTS=$(kubectl get pods -n "$NAMESPACE" -l "$POD_LABEL" -o jsonpath='{.items[*].status.podIP}' | tr ' ' ',')

# Get the etcd TLS secrets
CA_CERT=$(kubectl get secrets -n "$NAMESPACE" -o jsonpath="{.items[?(@.type==\"Opaque\" && @.metadata.labels.etcd-ca==\"true\")].data['ca.crt']}" | base64 -d)
CERT=$(kubectl get secrets -n "$NAMESPACE" -o jsonpath="{.items[?(@.type==\"Opaque\" && @.metadata.labels.etcd-ca==\"true\")].data['tls.crt']}" | base64 -d)
KEY=$(kubectl get secrets -n "$NAMESPACE" -o jsonpath="{.items[?(@.type==\"Opaque\" && @.metadata.labels.etcd-ca==\"true\")].data['tls.key']}" | base64 -d)

# Create temporary files for TLS certificates and key
CA_CERT_FILE=$(mktemp)
CERT_FILE=$(mktemp)
KEY_FILE=$(mktemp)

echo "$CA_CERT" > "$CA_CERT_FILE"
echo "$CERT" > "$CERT_FILE"
echo "$KEY" > "$KEY_FILE"

# Take the etcd snapshot
docker run --rm \
  -v "$BACKUP_DIR:/backup" \
  -v "$CA_CERT_FILE:/etc/etcd/ca.crt" \
  -v "$CERT_FILE:/etc/etcd/etcd.crt" \
  -v "$KEY_FILE:/etc/etcd/etcd.key" \
  "$ETCDCTL_IMAGE" etcdctl \
  --endpoints="$ETCD_ENDPOINTS" \
  --cacert="/etc/etcd/ca.crt" \
  --cert="/etc/etcd/etcd.crt" \
  --key="/etc/etcd/etcd.key" \
  --dial-timeout=5s \
  snapshot save /backup/"$SNAPSHOT_NAME"

# Clean up temporary files
rm "$CA_CERT_FILE" "$CERT_FILE" "$KEY_FILE"

echo "Etcd snapshot saved to $BACKUP_DIR/$SNAPSHOT_NAME"

# Optional: Add logic to rotate backups (remove older backups)

# Example rotation: Keep only the last 7 backups
find "$BACKUP_DIR" -type f -name "etcd_snapshot_*.db" -print0 | sort -z -r | tail -n +8 -z | xargs -0 rm -f

echo "Backup rotation complete (keeping last 7 backups)"
```