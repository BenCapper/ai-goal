# This script performs a traceroute to a list of IP addresses
# provided in a file. It iterates through each IP address
# and executes the traceroute command, saving the output to a file
# named after the IP address.

# Usage: ./traceroute_ips.sh <input_file>

# Check if an input file is provided
if [ $# -ne 1 ]; then
  echo "Usage: ./traceroute_ips.sh <input_file>"
  exit 1
fi

# Input file containing the list of IP addresses
INPUT_FILE="$1"

# Check if the input file exists
if [ ! -f "$INPUT_FILE" ]; then
  echo "Error: Input file '$INPUT_FILE' not found."
  exit 1
fi

# Read each IP address from the input file
while IFS= read -r ip; do
  # Sanitize the IP address for use as a filename
  FILENAME=$(echo "$ip" | tr . _)

  # Perform traceroute and save the output to a file
  echo "Performing traceroute to $ip..."
  traceroute "$ip" > "traceroute_$FILENAME.txt"

  # Check the exit status of traceroute
  if [ $? -eq 0 ]; then
    echo "Traceroute to $ip completed successfully. Output saved to traceroute_$FILENAME.txt"
  else
    echo "Traceroute to $ip failed."
  fi

done < "$INPUT_FILE"

echo "Traceroute process completed for all IPs."
```