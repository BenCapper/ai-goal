# This script extracts the DNS server IP addresses from /etc/resolv.conf.
# It first reads the file, then removes comments (lines starting with '#'),
# and finally extracts the IP addresses using awk.

# Usage: ./get_dns_servers.sh

cat /etc/resolv.conf | grep -v "^#" | awk '/nameserver/ {print $2}'
```