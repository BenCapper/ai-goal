# This script monitors the system's load average.
# It checks the 1-minute load average and sends a warning message
# if it exceeds a predefined threshold.

# Usage: ./load_monitor.sh

# Define the threshold for the load average
THRESHOLD=1.0

# Get the 1-minute load average
LOAD_AVG=$(uptime | awk '{print $(NF-2)}')

# Check if the load average exceeds the threshold
if [[ $(echo "$LOAD_AVG > $THRESHOLD" | bc) -eq 1 ]]; then
  echo "Warning: Load average ($LOAD_AVG) exceeds threshold ($THRESHOLD)"
fi
```