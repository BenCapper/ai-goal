# This script runs the my_long_script.sh in the background
# and redirects its standard output and standard error to the my_script.log file.

./my_long_script.sh &> my_script.log &
```