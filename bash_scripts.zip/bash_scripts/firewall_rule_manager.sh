# This script manages firewall rules on a RHEL system using firewalld.
# It allows traffic on a specific port range for a specific IP address.
#
# Usage: sudo ./firewall_rule_manager.sh <IP_ADDRESS> <PORT_RANGE_START> <PORT_RANGE_END>

# Check if the script is run with root privileges
if [[ $EUID -ne 0 ]]; then
  echo "This script must be run as root. Use sudo."
  exit 1
fi

# Check if the correct number of arguments are provided
if [[ $# -ne 3 ]]; then
  echo "Usage: sudo ./firewall_rule_manager.sh <IP_ADDRESS> <PORT_RANGE_START> <PORT_RANGE_END>"
  exit 1
fi

# Assign arguments to variables
IP_ADDRESS=$1
PORT_RANGE_START=$2
PORT_RANGE_END=$3

# Check if the port range is valid
if ! [[ "$PORT_RANGE_START" =~ ^[0-9]+$ ]] || ! [[ "$PORT_RANGE_END" =~ ^[0-9]+$ ]]; then
  echo "Error: Port range start and end must be integers."
  exit 1
fi

if (( PORT_RANGE_START > PORT_RANGE_END )); then
    echo "Error: Port range start must be less than or equal to port range end."
    exit 1
fi

# Define the zone (default to public)
ZONE="public"

# Rule description
DESCRIPTION="Allow traffic from $IP_ADDRESS on ports $PORT_RANGE_START-$PORT_RANGE_END"


# Add the rich rule to allow traffic on the specified port range from the specified IP address
firewall-cmd --permanent --zone="$ZONE" --add-rich-rule="rule family=ipv4 source address=$IP_ADDRESS port port=$PORT_RANGE_START-$PORT_RANGE_END protocol=tcp accept comment=\"$DESCRIPTION\""

# Reload the firewall to apply the changes
firewall-cmd --reload

echo "Firewall rule added successfully."
echo "Traffic from $IP_ADDRESS on ports $PORT_RANGE_START-$PORT_RANGE_END (TCP) is now allowed."

#Example usage: sudo ./firewall_rule_manager.sh 192.168.1.100 8080 8090
```