# This script labels multiple nodes in OpenShift based on a complex selector using oc label node.
# It takes a complex selector and a new key-value pair as input.

# Check if the correct number of arguments is provided.
if [ $# -ne 2 ]; then
  echo "Usage: $0 '<key1>=<value1>,<key2>!=<value2>' '<new-key>=<new-value>'"
  echo "Example: $0 'environment=production,region!=us-east-1' 'node.openshift.io/purpose=worker'"
  exit 1
fi

# Assign arguments to variables.
selector="$1"
label="$2"

# Construct the oc label command.
command="oc label node -l '$selector' '$label'"

# Execute the command.
echo "Executing command: $command"
eval $command

# Check the exit code.
if [ $? -eq 0 ]; then
  echo "Nodes labeled successfully."
else
  echo "Failed to label nodes."
  exit 1
fi

exit 0
```