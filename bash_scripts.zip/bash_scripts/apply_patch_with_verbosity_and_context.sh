# This script applies a git patch with a specified verbosity level and context.
# It takes the patch file path, verbosity level, and context lines as arguments.

# Check if the correct number of arguments are provided
if [ $# -ne 3 ]; then
  echo "Usage: $0 <patch_file> <verbosity_level> <context_lines>"
  echo "  <patch_file>: Path to the patch file."
  echo "  <verbosity_level>: Verbosity level (e.g., -v, -vv, -vvv). Use '' for none."
  echo "  <context_lines>: Number of context lines to show in diff (e.g., 3)."
  exit 1
fi

# Assign arguments to variables
PATCH_FILE="$1"
VERBOSITY="$2"
CONTEXT_LINES="$3"

# Check if the patch file exists
if [ ! -f "$PATCH_FILE" ]; then
  echo "Error: Patch file '$PATCH_FILE' not found."
  exit 1
fi

# Apply the patch with specified verbosity and context
echo "Applying patch '$PATCH_FILE' with verbosity '$VERBOSITY' and context '$CONTEXT_LINES'..."
git apply $VERBOSITY --context="$CONTEXT_LINES" "$PATCH_FILE"

# Check the exit status of the git apply command
if [ $? -eq 0 ]; then
  echo "Patch applied successfully."
else
  echo "Error: Failed to apply patch."
  exit 1
fi

exit 0
```