# This script automates the management of GitLab project group links and permissions using the GitLab API.
# It allows you to add, update, or delete group links for a given project.
# Usage: ./gitlab_group_link_manager.sh

# Configuration
GITLAB_URL="https://gitlab.example.com" # Replace with your GitLab instance URL
PRIVATE_TOKEN="YOUR_PRIVATE_TOKEN" # Replace with your GitLab private token (with API access)
PROJECT_ID="YOUR_PROJECT_ID" # Replace with your Project ID (numerical ID, not path)

# Function to check if jq is installed
check_jq() {
  if ! command -v jq &> /dev/null
  then
    echo "Error: jq is not installed. Please install it using your package manager (e.g., sudo apt install jq)."
    exit 1
  fi
}

# Function to add/update a group link
add_group_link() {
  GROUP_ID="$1" # numerical Group ID
  ACCESS_LEVEL="$2" # numerical Access Level (e.g., 30 for Developer, 40 for Maintainer)
  EXPIRES_AT="$3" # optional YYYY-MM-DD format. Leave empty string "" to not set expiration

  if [[ -z "$GROUP_ID" || -z "$ACCESS_LEVEL" ]]; then
    echo "Error: Group ID and Access Level are required."
    return 1
  fi

  if [[ ! "$ACCESS_LEVEL" =~ ^[0-9]+$ ]]; then
    echo "Error: Access Level must be a number."
    return 1
  fi

  API_ENDPOINT="$GITLAB_URL/api/v4/projects/$PROJECT_ID/group_links"
  DATA="group_id=$GROUP_ID&group_access=$ACCESS_LEVEL"

  if [[ ! -z "$EXPIRES_AT" ]]; then
    DATA="$DATA&expires_at=$EXPIRES_AT"
  fi

  RESPONSE=$(curl --header "PRIVATE-TOKEN: $PRIVATE_TOKEN" --request POST --data "$DATA" "$API_ENDPOINT")

  if echo "$RESPONSE" | jq -e '.message' &> /dev/null; then
      echo "Error adding/updating group link: $(echo "$RESPONSE" | jq .message)"
      return 1
  else
      echo "Successfully added/updated group link. Response: $RESPONSE"
      return 0
  fi
}

# Function to delete a group link
delete_group_link() {
  GROUP_ID="$1"

  if [[ -z "$GROUP_ID" ]]; then
    echo "Error: Group ID is required."
    return 1
  fi

  API_ENDPOINT="$GITLAB_URL/api/v4/projects/$PROJECT_ID/group_links/$GROUP_ID"
  RESPONSE=$(curl --header "PRIVATE-TOKEN: $PRIVATE_TOKEN" --request DELETE "$API_ENDPOINT")

  if [[ "$RESPONSE" == "" ]]; then
    echo "Successfully deleted group link for group ID $GROUP_ID."
    return 0
  else
    echo "Error deleting group link: $RESPONSE"
    return 1
  fi
}

# Function to list group links
list_group_links() {
  API_ENDPOINT="$GITLAB_URL/api/v4/projects/$PROJECT_ID/group_links"
  RESPONSE=$(curl --header "PRIVATE-TOKEN: $PRIVATE_TOKEN" "$API_ENDPOINT")

  if echo "$RESPONSE" | jq -e '.' &> /dev/null; then
      echo "Group Links: $(echo "$RESPONSE" | jq .)"
  else
      echo "Error fetching group links: $RESPONSE"
      return 1
  fi
}

# Main Script Logic
check_jq # Verify jq is installed

if [ $# -eq 0 ]; then
  echo "Usage: $0 <command> [options]"
  echo "Commands:"
  echo "  add <group_id> <access_level> [<expires_at>]  - Add or update a group link."
  echo "  delete <group_id>                             - Delete a group link."
  echo "  list                                          - List group links."
  exit 1
fi

COMMAND="$1"
shift

case "$COMMAND" in
  add)
    GROUP_ID="$1"
    ACCESS_LEVEL="$2"
    EXPIRES_AT="${3:-""}" # Optional expiration date. If empty, it will not be set.

    add_group_link "$GROUP_ID" "$ACCESS_LEVEL" "$EXPIRES_AT"
    ;;
  delete)
    GROUP_ID="$1"
    delete_group_link "$GROUP_ID"
    ;;
  list)
    list_group_links
    ;;
  *)
    echo "Invalid command: $COMMAND"
    echo "Usage: $0 <command> [options]"
    echo "Commands:"
    echo "  add <group_id> <access_level> [<expires_at>]  - Add or update a group link."
    echo "  delete <group_id>                             - Delete a group link."
    echo "  list                                          - List group links."
    exit 1
    ;;
esac

# File usage: ./gitlab_group_link_manager.sh add 123 40 2024-12-31
# File usage: ./gitlab_group_link_manager.sh delete 123
# File usage: ./gitlab_group_link_manager.sh list
```