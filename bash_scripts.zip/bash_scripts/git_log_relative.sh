# This script uses git to display the commit history
# of a repository with relative dates, making it easier
# to understand when changes were made.

git log --pretty=format:"%h %ad | %s%d [%an]" --graph --date=relative
```