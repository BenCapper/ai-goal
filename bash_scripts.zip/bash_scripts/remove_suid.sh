# This script removes the SUID bit from the specified script.
# The SUID bit, when set on an executable file, allows the file to be executed with the privileges of the owner of the file.
# Removing the SUID bit reduces the risk of privilege escalation if the script contains vulnerabilities.

chmod u-s my_script.sh
```