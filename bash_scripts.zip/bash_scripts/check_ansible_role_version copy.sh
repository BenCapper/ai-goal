# This script checks if a specific Ansible role meets a minimum version requirement.
# It uses ansible-galaxy to inspect the role's version and compares it to the provided minimum version.

# Usage: ./check_ansible_role_version.sh <role_name> <minimum_version>

# Example: ./check_ansible_role_version.sh geerlingguy.nginx 1.2.3

set -e

ROLE_NAME="$1"
MINIMUM_VERSION="$2"

# Check if the role name and minimum version are provided as arguments
if [ -z "$ROLE_NAME" ] || [ -z "$MINIMUM_VERSION" ]; then
  echo "Usage: $0 <role_name> <minimum_version>"
  exit 1
fi

# Function to get the version of an Ansible role using ansible-galaxy
get_role_version() {
  ansible-galaxy role info "$1" | grep "version:" | awk '{print $2}' | tr -d '"'
}

# Get the current version of the Ansible role
CURRENT_VERSION=$(get_role_version "$ROLE_NAME")

# Check if the role version was successfully retrieved
if [ -z "$CURRENT_VERSION" ]; then
  echo "Error: Could not determine the version of role '$ROLE_NAME'."
  exit 1
fi

# Function to compare two version strings
version_compare() {
  local v1="$1"
  local v2="$2"
  local IFS=.
  local -a arr1 arr2
  read -r -a arr1 <<< "$v1"
  read -r -a arr2 <<< "$v2"

  local i=0
  while [ $i -lt ${#arr1[@]} ] || [ $i -lt ${#arr2[@]} ]; do
    local part1=${arr1[$i]:-0}
    local part2=${arr2[$i]:-0}
    if [ "$part1" -gt "$part2" ]; then
      return 1 # v1 > v2
    elif [ "$part1" -lt "$part2" ]; then
      return 2 # v1 < v2
    fi
    ((i++))
  done
  return 0 # v1 == v2
}

# Compare the current version with the minimum required version
version_compare "$CURRENT_VERSION" "$MINIMUM_VERSION"
RESULT=$?

# Determine the outcome based on the version comparison
if [ "$RESULT" -eq 0 ]; then
  echo "Role '$ROLE_NAME' version ($CURRENT_VERSION) meets the minimum requirement ($MINIMUM_VERSION)."
  exit 0
elif [ "$RESULT" -eq 1 ]; then
  echo "Role '$ROLE_NAME' version ($CURRENT_VERSION) meets the minimum requirement ($MINIMUM_VERSION)."
  exit 0
else
  echo "Error: Role '$ROLE_NAME' version ($CURRENT_VERSION) is older than the minimum required version ($MINIMUM_VERSION)."
  exit 1
fi
```