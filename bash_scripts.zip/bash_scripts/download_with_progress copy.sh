# This script uses curl to download a file from a URL with progress output.
# It takes the URL as a command-line argument.

# Check if a URL is provided as an argument
if [ -z "$1" ]; then
  echo "Usage: $0 <URL>"
  exit 1
fi

URL="$1"

# Extract filename from URL
FILENAME=$(basename "$URL")

# Download the file with progress bar
curl -o "$FILENAME" -# "$URL"

# Check if the download was successful
if [ $? -eq 0 ]; then
  echo "Download complete: $FILENAME"
else
  echo "Download failed."
fi
```