# This script checks for the Node.js executable and verifies its version.
# It iterates through potential executable names ("node" and "nodejs"),
# attempting to find a valid Node.js installation. If found, it checks
# if the version meets a minimum requirement.

# Usage: ./check_node_version.sh

NODE_VERSION="16.0.0"

for NODE_BIN in "node" "nodejs"; do
  if command -v "$NODE_BIN" >/dev/null 2>&1; then
    # Check if the executable exists
    if "$NODE_BIN" -v &> /dev/null; then
      # Get the version number
      NODE_ACTUAL_VERSION=$("$NODE_BIN" -v | sed 's/[^0-9.]*//g')

      # Compare versions (using version comparison)
      if [[ $(printf '%s\n' "$NODE_VERSION" "$NODE_ACTUAL_VERSION" | sort -V | head -n 1) == "$NODE_ACTUAL_VERSION" ]]; then
        echo "Node.js version $NODE_ACTUAL_VERSION found (using '$NODE_BIN'). Version is greater than or equal to required version $NODE_VERSION"
        exit 0
      else
        echo "Node.js version $NODE_ACTUAL_VERSION found (using '$NODE_BIN'). Version is less than required version $NODE_VERSION"
      fi
    else
      echo "Error: Could not determine Node.js version using '$NODE_BIN'"
    fi
  fi
done

echo "Node.js executable not found or version insufficient."
exit 1

# Example Usage:
# ./check_node_version.sh
```