# This script reads a number from the user.
# It then checks if the number is within a specific range (10-20).
# If the number is within the range, it prints "Within range".
# Otherwise, it prints "Outside range".

# Usage: ./range_check.sh

read -p "Enter a number: " INPUT_NUMBER_RANGE

if (( INPUT_NUMBER_RANGE >= 10 && INPUT_NUMBER_RANGE <= 20 )); then
  echo "Within range"
else
  echo "Outside range"
fi
```