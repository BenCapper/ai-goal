#
# This script compares the differences between the current branch and a specified branch using git.
# It takes the target branch name as an argument.

# Check if a branch name is provided as an argument.
if [ $# -eq 0 ]; then
  echo "Usage: $0 <target_branch>"
  exit 1
fi

# Get the target branch name from the command line argument.
TARGET_BRANCH="$1"

# Check if the target branch exists.
if ! git show-ref --verify --quiet refs/heads/"$TARGET_BRANCH"; then
  echo "Error: Branch '$TARGET_BRANCH' does not exist."
  exit 1
fi

# Get the current branch name.
CURRENT_BRANCH=$(git branch --show-current)

# Check if we are on a branch.
if [ -z "$CURRENT_BRANCH" ]; then
  echo "Error: Not currently on a branch."
  exit 1
fi

# Show the differences between the current branch and the target branch.
echo "Showing differences between $CURRENT_BRANCH and $TARGET_BRANCH:"
git diff "$TARGET_BRANCH"

exit 0
```