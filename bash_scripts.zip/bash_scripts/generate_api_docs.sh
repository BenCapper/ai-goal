# This script automates the generation of API documentation from code annotations
# within a Git repository. It assumes the presence of a tool that can parse
# code and generate documentation from specific annotation formats (e.g., JSDoc, Swagger, etc.).
# This script requires git, the documentation generation tool (e.g., jsdoc, swagger-cli, etc.)
# and optionally pandoc for format conversion.

# Usage: ./generate_api_docs.sh <repository_path> <output_directory> <documentation_tool> [options]

# Set default values
REPOSITORY_PATH="${1:-.}"
OUTPUT_DIRECTORY="${2:-docs}"
DOCUMENTATION_TOOL="${3:-jsdoc}" # Example: jsdoc, swagger-cli
OPTIONS="${@:4}" # Pass remaining arguments as options to the documentation tool

# Check if the repository path exists and is a Git repository
if [ ! -d "${REPOSITORY_PATH}/.git" ]; then
  echo "Error: ${REPOSITORY_PATH} is not a valid Git repository."
  exit 1
fi

# Create the output directory if it doesn't exist
mkdir -p "${OUTPUT_DIRECTORY}"

# Generate documentation using the specified tool
echo "Generating documentation using ${DOCUMENTATION_TOOL} in ${REPOSITORY_PATH} and storing it in ${OUTPUT_DIRECTORY}"

case "${DOCUMENTATION_TOOL}" in
  jsdoc)
    # Example usage with JSDoc
    # Assumes jsdoc.conf.json exists in the repository root or OPTIONS contains its path
    if [ -f "${REPOSITORY_PATH}/jsdoc.conf.json" ]; then
      jsdoc -c "${REPOSITORY_PATH}/jsdoc.conf.json" -d "${OUTPUT_DIRECTORY}" "${REPOSITORY_PATH}"
    else
      jsdoc -d "${OUTPUT_DIRECTORY}" ${OPTIONS} "${REPOSITORY_PATH}"
    fi
    ;;
  swagger-cli)
    # Example usage with Swagger CLI (assuming Swagger/OpenAPI definition files exist)
    swagger-cli bundle "${REPOSITORY_PATH}/swagger.yaml" -o "${OUTPUT_DIRECTORY}/swagger.json" -t json
    ;;
  *)
    echo "Error: Unsupported documentation tool: ${DOCUMENTATION_TOOL}"
    echo "Please specify a valid tool (e.g., jsdoc, swagger-cli)."
    exit 1
    ;;
esac

echo "Documentation generated successfully in ${OUTPUT_DIRECTORY}"

# Optional: Convert the output to a different format (e.g., Markdown) using Pandoc
# if [ -x "$(command -v pandoc)" ]; then
#   echo "Converting documentation to Markdown using Pandoc..."
#   find "${OUTPUT_DIRECTORY}" -name "*.html" -print0 | while IFS= read -r -d $'\0' file; do
#     outfile="${file%.html}.md"
#     pandoc -s -f html -t markdown "${file}" -o "${outfile}"
#     rm "${file}"
#   done
#   echo "Documentation converted to Markdown."
# fi

exit 0

# File Usage:
# ./generate_api_docs.sh /path/to/repo /path/to/output jsdoc -r
# ./generate_api_docs.sh /path/to/repo /path/to/output swagger-cli
```