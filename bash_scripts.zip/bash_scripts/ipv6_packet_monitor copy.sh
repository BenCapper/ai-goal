# This script monitors the number of IPv6 packets received and transmitted on a specified network interface.
# It uses the 'ip' command to retrieve the interface statistics and reports the packet counts.

# Specify the network interface to monitor (e.g., eth0, enp0s3)
INTERFACE="eth0"

# Function to get the IPv6 packet statistics for the given interface
get_ipv6_stats() {
  local rx_packets=$(ip -s -6 link show "$INTERFACE" | awk '/RX:/{print $2}')
  local tx_packets=$(ip -s -6 link show "$INTERFACE" | awk '/TX:/{print $2}')

  if [[ -z "$rx_packets" || -z "$tx_packets" ]]; then
    echo "Error: Could not retrieve IPv6 packet statistics for interface $INTERFACE."
    return 1
  fi

  echo "Interface: $INTERFACE"
  echo "IPv6 Packets Received: $rx_packets"
  echo "IPv6 Packets Transmitted: $tx_packets"
  return 0
}

# Main execution block
if ! ip -6 link show "$INTERFACE" > /dev/null 2>&1; then
  echo "Error: Interface $INTERFACE not found or does not support IPv6."
  exit 1
fi

get_ipv6_stats

exit 0
```