# This script displays the commit history of the current Git repository.
# It shows the commit hash, author, date, and commit message for the last 10 commits.

# Usage: ./git_history.sh

# Get the last 10 commits and format the output
git log --pretty=format:"%h - %an, %ad : %s" --date=short -n 10
```