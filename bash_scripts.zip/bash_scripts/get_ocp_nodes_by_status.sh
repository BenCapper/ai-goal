#
# This script retrieves the nodes in an OpenShift cluster and filters them based on their status.
# It takes a status as an argument and prints the names of the nodes with that status.
#
# Usage: ./get_ocp_nodes_by_status.sh <status>

# Check if a status argument is provided
if [ -z "$1" ]; then
  echo "Error: Please provide a status to filter by."
  echo "Usage: ./get_ocp_nodes_by_status.sh <status>"
  exit 1
fi

STATUS="$1"

# Get the nodes in the cluster and filter by status
oc get nodes -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{.status.conditions[?(@.type=="Ready")].status}{"\n"}{end}' | grep "\ttrue" | awk '{print $1}'
```