# This script creates a new Kubernetes namespace using kubectl.
# It takes the namespace name as an argument.
# If no argument is provided, it prints a usage message and exits.

# Check if a namespace name is provided as an argument.
if [ -z "$1" ]; then
  echo "Usage: $0 <namespace_name>"
  exit 1
fi

# Assign the namespace name to a variable.
NAMESPACE_NAME="$1"

# Create the namespace.
kubectl create namespace "$NAMESPACE_NAME"

# Check the exit status of the kubectl command.
if [ $? -eq 0 ]; then
  echo "Namespace '$NAMESPACE_NAME' created successfully."
else
  echo "Failed to create namespace '$NAMESPACE_NAME'."
  exit 1
fi

exit 0
```