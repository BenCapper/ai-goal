# This script iterates through a sequence of numbers using a for loop.
# It checks if each number is not equal to 0, 1, and 2 using an if statement with logical AND.
# If the condition is met, it prints the number followed by a specific message.

# Usage: ./check_numbers.sh

for i in {0..5}
do
  if [[ $i -ne 0 && $i -ne 1 && $i -ne 2 ]]; then
    echo "$i is not equal to 0 and also not equal to 1 and also not equal to 2"
  fi
done
# ./check_numbers.sh
```