# This script checks the network latency to a list of hosts.
# It uses the ping command to measure the round-trip time (RTT) to each host.
# The script takes a file as input, where each line contains a hostname or IP address.
# It then iterates through the list of hosts, pings each one, and displays the average latency.
#
# Usage: ./check_latency.sh hosts.txt

# Input file containing a list of hosts
HOST_FILE=$1

# Check if the host file is provided
if [ -z "$HOST_FILE" ]; then
  echo "Error: Please provide a host file as an argument."
  echo "Usage: ./check_latency.sh hosts.txt"
  exit 1
fi

# Check if the host file exists
if [ ! -f "$HOST_FILE" ]; then
  echo "Error: Host file '$HOST_FILE' not found."
  exit 1
fi

# Read each line from the host file
while IFS= read -r host; do
  # Remove leading and trailing whitespace
  host=$(echo "$host" | tr -d '[:space:]')

  # Skip empty lines and comments
  if [ -z "$host" ] || [[ "$host" == \#* ]]; then
    continue
  fi

  # Ping the host and extract the average RTT
  ping_output=$(ping -c 4 "$host" 2>&1)

  # Check if ping was successful
  if echo "$ping_output" | grep -q "Destination Host Unreachable"; then
    echo "Host '$host' is unreachable."
  else
    # Extract the average RTT using awk
    avg_rtt=$(echo "$ping_output" | awk '/rtt min\/avg\/max\/mdev/ {print $4}' | cut -d'/' -f2)

    # Check if the average RTT was successfully extracted
    if [ -z "$avg_rtt" ]; then
      echo "Error: Could not determine latency for host '$host'."
    else
      echo "Latency to '$host': $avg_rtt ms"
    fi
  fi
done < "$HOST_FILE"
```