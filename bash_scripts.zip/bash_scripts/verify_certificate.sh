# This script demonstrates how to use openssl to verify a signed X.509 certificate against a CA.
# It assumes you have the certificate to be verified (certificate.pem) and the CA certificate (ca.pem).
# It will print verification information to the console.

# Usage: ./verify_certificate.sh

# Define the certificate and CA file paths
CERTIFICATE="certificate.pem"
CA_CERTIFICATE="ca.pem"

# Check if the certificate and CA files exist
if [ ! -f "$CERTIFICATE" ]; then
  echo "Error: Certificate file '$CERTIFICATE' not found."
  exit 1
fi

if [ ! -f "$CA_CERTIFICATE" ]; then
  echo "Error: CA certificate file '$CA_CERTIFICATE' not found."
  exit 1
fi

# Verify the certificate against the CA using openssl verify
openssl verify -CAfile "$CA_CERTIFICATE" "$CERTIFICATE"

# The openssl verify command returns 0 if the certificate is valid and non-zero otherwise.
# The output will indicate whether the verification was successful or if any errors were encountered.
```