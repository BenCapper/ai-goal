# This script retrieves and analyzes Security Context Constraints (SCCs) in an OpenShift cluster.
# It extracts key security-related attributes from each SCC and presents them in a human-readable format.
# The script aims to provide insights into the security configuration of the cluster, highlighting potential vulnerabilities or misconfigurations.

# Retrieve SCC information
scc_data=$(oc get scc -o wide)

# Check if oc command is available
if ! command -v oc &> /dev/null; then
  echo "Error: 'oc' command not found. Please ensure the OpenShift CLI is installed and configured."
  exit 1
fi

# Check if there is any SCC
if [[ -z "$scc_data" ]]; then
  echo "No Security Context Constraints (SCCs) found."
  exit 0
fi


# Function to extract a column from a line
get_column() {
  local line="$1"
  local column_number="$2"
  echo "$line" | awk "{print \$$column_number}"
}


# Function to analyze and report on an SCC
analyze_scc() {
  local scc_name="$1"
  local scc_line="$2"


  echo "--------------------------------------------------"
  echo "SCC Name: $scc_name"
  echo "--------------------------------------------------"

  # Allowed Capabilities
  local allowed_capabilities=$(get_column "$scc_line" 3)
  echo "  Allowed Capabilities: $allowed_capabilities"
  echo "    - Security Implication: Determines the Linux capabilities available to the container.  Unrestricted capabilities (e.g., 'ALL') significantly increase the container's privileges and potential for security breaches."

  # Volumes
  local volumes=$(get_column "$scc_line" 4)
  echo "  Volumes: $volumes"
  echo "    - Security Implication: Controls the types of volumes that can be mounted. Allowing sensitive volumes (e.g., 'hostPath') can grant containers access to the host system, posing a significant security risk."

  # SELinux Context
  local selinux_context=$(get_column "$scc_line" 5)
  echo "  SELinux Context: $selinux_context"
  echo "    - Security Implication: Defines the SELinux security labeling for the container. 'MustRunAs' enforces a specific SELinux context.  'Any' provides less security."

  # RunAsUser
  local run_as_user=$(get_column "$scc_line" 6)
  echo "  Run As User: $run_as_user"
  echo "    - Security Implication:  Specifies the user ID under which the container will run. 'MustRunAsRange' or 'MustRunAs' enforces running as specific user, minimizing the risk associated with running as root."
  echo "      'RunAsAny' is the least secure option."

  # FSGroup
  local fsgroup=$(get_column "$scc_line" 7)
  echo "  FSGroup: $fsgroup"
  echo "    - Security Implication: Specifies the GID applied to volume directories and files belonging to the volume when it is mounted. If not correctly configured, may cause permission issues for the container's processes."

  # Supplemental Groups
  local supplemental_groups=$(get_column "$scc_line" 8)
  echo "  Supplemental Groups: $supplemental_groups"
  echo "    - Security Implication:  Specifies additional groups a process belongs to.  Incorrect configuration can lead to unexpected access to resources."

  echo ""
}

# Process each SCC
header_skipped=0
while IFS= read -r line; do
    # Skip the header line
    if [[ $header_skipped -eq 0 ]]; then
        header_skipped=1
        continue
    fi
    
    # Extract the SCC name
    scc_name=$(echo "$line" | awk '{print $1}')

    # Analyze the SCC
    analyze_scc "$scc_name" "$line"
done <<< "$scc_data"
```