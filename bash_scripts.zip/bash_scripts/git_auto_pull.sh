# This script checks for new commits on a remote Git repository and,
# if found, pulls the changes into the local repository.
# It optionally performs a fast-forward merge if possible.

# Usage: ./git_auto_pull.sh <remote_name> <branch_name>

REMOTE="${1:-origin}"
BRANCH="${2:-main}"

# Fetch the latest changes from the remote repository.
echo "Fetching latest changes from ${REMOTE}/${BRANCH}..."
git fetch $REMOTE $BRANCH > /dev/null 2>&1

# Get the current commit hash of the local branch.
LOCAL_HEAD=$(git rev-parse HEAD)

# Get the commit hash of the remote branch.
REMOTE_HEAD=$(git rev-parse $REMOTE/$BRANCH)

# Compare the local and remote commit hashes.
if [ "$LOCAL_HEAD" != "$REMOTE_HEAD" ]; then
  echo "New commits found on ${REMOTE}/${BRANCH}."

  # Try to fast-forward merge.
  echo "Attempting fast-forward merge..."
  git merge --ff-only $REMOTE/$BRANCH 2>/dev/null

  if [ $? -eq 0 ]; then
    echo "Fast-forward merge successful."
  else
    echo "Fast-forward merge failed. Performing a regular pull."
    # Pull the changes from the remote repository.
    git pull $REMOTE $BRANCH
  fi
else
  echo "No new commits found on ${REMOTE}/${BRANCH}."
fi

# Usage: ./git_auto_pull.sh <remote_name> <branch_name>
```