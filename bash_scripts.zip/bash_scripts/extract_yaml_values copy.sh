# This script reads a YAML file, extracts values based on nested keys,
# and prints the extracted values.

# Install required tools (if not already installed)
# sudo apt-get update
# sudo apt-get install -y yq

# Check if yq is installed
if ! command -v yq &> /dev/null
then
    echo "yq could not be found.  Please install it first."
    echo "  sudo apt-get update && sudo apt-get install -y yq"
    exit 1
fi

# Input YAML file
YAML_FILE=$1

# Check if YAML file is provided
if [ -z "$YAML_FILE" ]; then
  echo "Usage: $0 <yaml_file> <key1>.<key2>..."
  exit 1
fi

# Check if YAML file exists
if [ ! -f "$YAML_FILE" ]; then
  echo "Error: YAML file '$YAML_FILE' not found."
  exit 1
fi

# Key path to extract (dot notation)
KEY_PATH=$2

# Check if key path is provided
if [ -z "$KEY_PATH" ]; then
  echo "Usage: $0 <yaml_file> <key1>.<key2>..."
  exit 1
fi

# Extract the value using yq
VALUE=$(yq e ".$KEY_PATH" "$YAML_FILE")

# Check if the extraction was successful and handle possible errors
if [ $? -ne 0 ]; then
    echo "Error extracting value for key '$KEY_PATH'."
    exit 1
fi

# Print the extracted value
echo "$VALUE"
```