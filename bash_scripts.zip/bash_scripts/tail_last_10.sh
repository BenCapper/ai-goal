# This script displays the last 10 lines of a specified file.
# It uses the tail command with the -n option to achieve this.

tail -n 10 "$1"
```