#
# This script interacts with an API that requires API keys in both headers and query parameters.
# It handles different error codes, implements a retry mechanism with exponential backoff,
# logs retry attempts, handles rate limiting, and breaks out of retries after a maximum number of attempts or a total timeout.
#
# Usage: ./api_interaction.sh <API_ENDPOINT> <API_KEY_HEADER> <API_KEY_QUERY_PARAM> <DATA>

# Configuration
API_ENDPOINT="$1"
API_KEY_HEADER="$2"
API_KEY_QUERY_PARAM="$3"
DATA="$4"
MAX_RETRIES=5
INITIAL_BACKOFF=1 # seconds
TOTAL_TIMEOUT=60 # seconds

# Logging function
log() {
  echo "$(date +'%Y-%m-%d %H:%M:%S') - $1"
}

# Function to call the API with retry logic
call_api() {
  local attempt=0
  local backoff=$INITIAL_BACKOFF
  local start_time=$(date +%s)

  while true; do
    attempt=$((attempt + 1))
    log "Attempt $attempt: Calling API endpoint: $API_ENDPOINT"

    # Construct the query parameters with the API key
    API_URL="${API_ENDPOINT}?api_key=${API_KEY_QUERY_PARAM}"

    # Call the API using curl with the API key in the header and request body
    RESPONSE=$(curl -s -w "%{http_code}" -X POST \
      -H "X-API-Key: ${API_KEY_HEADER}" \
      -H "Content-Type: application/json" \
      -d "$DATA" \
      "${API_URL}")

    HTTP_CODE=$(echo "$RESPONSE" | tail -n 1)
    RESPONSE_BODY=$(echo "$RESPONSE" | head -n -1)


    log "Attempt $attempt: HTTP Status Code: $HTTP_CODE"

    # Handle different HTTP status codes
    case "$HTTP_CODE" in
      200)
        log "Attempt $attempt: API call successful. Response: $RESPONSE_BODY"
        echo "$RESPONSE_BODY"
        return 0
        ;;
      400)
        log "Attempt $attempt: Error: Bad Request.  No retry."
        echo "Error: Bad Request.  No retry. Response: $RESPONSE_BODY"
        return 1
        ;;
      401)
        log "Attempt $attempt: Error: Unauthorized.  No retry."
        echo "Error: Unauthorized.  No retry. Response: $RESPONSE_BODY"
        return 1
        ;;
      403)
        log "Attempt $attempt: Error: Forbidden.  No retry."
        echo "Error: Forbidden.  No retry. Response: $RESPONSE_BODY"
        return 1
        ;;
      429)
        log "Attempt $attempt: Rate limited."
        retry_after=$(echo "$RESPONSE_BODY" | jq -r '.retry_after') #example json: {"error": "Rate limited", "retry_after": 60}

        if [[ -n "$retry_after" ]]; then
            log "Attempt $attempt: Waiting for $retry_after seconds based on Retry-After header."
            sleep "$retry_after"
        else
            log "Attempt $attempt: Retry-After header not found, using exponential backoff."
            sleep "$backoff"
        fi
        ;;
      500|502|503)
        log "Attempt $attempt: Server error. Retrying..."
        sleep "$backoff"
        ;;
      *)
        log "Attempt $attempt: Unexpected error. HTTP Code: $HTTP_CODE, Response: $RESPONSE_BODY Retrying..."
        sleep "$backoff"
        ;;
    esac

    # Check if maximum retries reached
    if [[ $attempt -ge $MAX_RETRIES ]]; then
      log "Maximum retries reached. Aborting."
      echo "Error: Maximum retries reached after $MAX_RETRIES attempts."
      return 1
    fi

    # Check if total timeout reached
    local elapsed_time=$(( $(date +%s) - $start_time ))
    if [[ $elapsed_time -ge $TOTAL_TIMEOUT ]]; then
      log "Total timeout reached. Aborting."
      echo "Error: Total timeout reached after $TOTAL_TIMEOUT seconds."
      return 1
    fi

    # Exponential backoff
    backoff=$((backoff * 2))

  done
}

# Main execution
if call_api; then
  log "API interaction completed successfully."
else
  log "API interaction failed."
  exit 1
fi

exit 0

# file usage: ./api_interaction.sh "https://example.com/api" "header_api_key" "query_api_key" '{"key": "value"}'
```