# This script performs a full repository integrity check using git fsck.
# It uses the --full and --strict options to ensure a thorough and strict check.

# Usage: ./git_fsck_full_strict.sh

# Perform a full and strict repository check.
git fsck --full --strict

# Check the exit code to determine if any errors were found.
if [ $? -eq 0 ]; then
  echo "Repository integrity check passed."
else
  echo "Repository integrity check failed.  See output above for details."
fi
```