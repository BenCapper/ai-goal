# This script demonstrates how to use the systemd-run command to execute commands as systemd units.
# It shows several examples, including running a simple command, assigning a name to the unit,
# and specifying resource limits.

# Example 1: Run a simple command as a transient systemd unit.
# The unit will be removed automatically after the command finishes.
echo "Running a simple command as a transient systemd unit..."
systemd-run --transient --unit simple_command sleep 5
echo "Simple command finished."

# Example 2: Run a command and give it a specific name.
# This makes it easier to monitor and manage the unit.
echo "Running a command with a specific name..."
systemd-run --transient --unit named_command bash -c "echo 'This is the named command running...' && sleep 3 && echo 'Named command finished.'"
echo "Named command submitted."

# Example 3: Run a command with resource limits (CPU and Memory).
# This can prevent the command from consuming excessive resources.
echo "Running a command with resource limits..."
systemd-run --transient --unit limited_command --property CPUQuota=20% --property MemoryMax=100M bash -c "echo 'This is the limited command running...' && sleep 2 && echo 'Limited command finished.'"
echo "Limited command submitted."

# Example 4: Run a command that persists after the user logs out
echo "Running a command that persists after user logs out"
systemd-run --user --unit persistent_command sleep 60

# Example 5: Run a command as a background process. This doesn't block the script execution
echo "Running command in background"
systemd-run --unit background_command --wait sleep 10 &

# Example 6: Run a command that shows error handling.
echo "Running command showing error handling"
systemd-run --unit error_command --collect echo "Error message" >&2; exit 1

# Example 7: Run a command with a timer. This creates a timer that will trigger the command
# at a specific interval.

# systemd-run --on-calendar="*-*-* 12:00:00" --unit timed_command echo "It is noon!"

# Usage: ./systemd_run_example.sh
```