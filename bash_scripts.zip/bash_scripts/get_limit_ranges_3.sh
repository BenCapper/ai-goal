#
# This script retrieves and displays the limit ranges for all OpenShift namespaces.
# It uses the oc command-line tool to fetch the limit ranges in YAML format
# and then uses yq to extract and print the relevant information, including namespace and limit range name.
#

# Check if oc command is available
if ! command -v oc &> /dev/null; then
  echo "Error: oc command not found. Please ensure OpenShift CLI is installed and configured."
  exit 1
fi

# Check if yq command is available
if ! command -v yq &> /dev/null; then
  echo "Error: yq command not found. Please ensure yq is installed. (e.g., 'sudo apt install yq' or 'brew install yq')"
  exit 1
fi

# Get all limit ranges from all namespaces in YAML format
ALL_LIMIT_RANGES=$(oc get limitranges --all-namespaces -o yaml)

# Extract and print the namespace and limit range name for each limit range using yq
echo "$ALL_LIMIT_RANGES" | yq e '.items[] | "Namespace: \(.metadata.namespace), LimitRange: \(.metadata.name)"' -

# file usage: ./get_limit_ranges.sh
```