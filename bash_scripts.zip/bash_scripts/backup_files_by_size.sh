# This script automates backing up files within a specified size range from a directory.
# It takes the source directory, destination directory, minimum size (in bytes), and maximum size (in bytes) as arguments.
# It then finds all files within that size range and copies them to the destination directory.
# If destination directory doesn't exist, it creates it.
# It also handles basic error checking for the input arguments.

# Usage: ./backup_files_by_size.sh <source_directory> <destination_directory> <min_size_bytes> <max_size_bytes>

# Check if the correct number of arguments are provided
if [ $# -ne 4 ]; then
  echo "Usage: ./backup_files_by_size.sh <source_directory> <destination_directory> <min_size_bytes> <max_size_bytes>"
  exit 1
fi

# Assign arguments to variables
source_dir="$1"
dest_dir="$2"
min_size="$3"
max_size="$4"

# Check if source directory exists
if [ ! -d "$source_dir" ]; then
  echo "Error: Source directory '$source_dir' does not exist."
  exit 1
fi

# Check if min_size and max_size are valid numbers
if ! [[ "$min_size" =~ ^[0-9]+$ ]] || ! [[ "$max_size" =~ ^[0-9]+$ ]]; then
    echo "Error: Minimum and maximum sizes must be integers."
    exit 1
fi

# Check if min_size is less than or equal to max_size
if [ "$min_size" -gt "$max_size" ]; then
  echo "Error: Minimum size must be less than or equal to maximum size."
  exit 1
fi

# Create destination directory if it doesn't exist
if [ ! -d "$dest_dir" ]; then
  mkdir -p "$dest_dir"
  if [ $? -ne 0 ]; then
    echo "Error: Failed to create destination directory '$dest_dir'."
    exit 1
  fi
fi

# Find files within the specified size range and copy them to the destination directory
find "$source_dir" -type f -size +"${min_size}c" -size -"${max_size}c" -exec cp -p {} "$dest_dir" \;

# Check if the copy command was successful. If find returned nothing, the exit code is still 0
if [ $? -eq 0 ]; then
  echo "Backup completed successfully."
else
  echo "Error: An error occurred during the backup process."
  exit 1
fi

exit 0
```