#
# This script monitors network traffic on each interface, logs packet details,
# calculates average bandwidth usage, triggers alerts based on thresholds,
# identifies top communicating hosts, visualizes bandwidth usage, and
# saves data to a database for historical analysis.

# Configuration
INTERFACE="eth0" # Default interface to monitor.  Change as needed.
LOG_FILE="network_monitor.log"
DATABASE_FILE="network_data.db"
BANDWIDTH_THRESHOLD_MBPS=10 # Bandwidth threshold in Mbps
ALERT_DURATION_SEC=60 # Duration to exceed threshold before alerting
SAMPLE_INTERVAL_SEC=5 # Sample interval in seconds
TOP_N=10 # Number of top hosts to display
PLOT_TOOL="gnuplot" # Default plotting tool.  'gnuplot' is assumed.  Install if needed.
TIMESTAMP_FORMAT="%Y-%m-%d %H:%M:%S"
# Database Setup
SQLITE_CMD="sqlite3" # Assumes sqlite3 is installed
DB_INIT_SQL="
CREATE TABLE IF NOT EXISTS network_data (
    timestamp DATETIME,
    interface TEXT,
    tx_packets INTEGER,
    rx_packets INTEGER,
    tx_bytes INTEGER,
    rx_bytes INTEGER,
    protocol TEXT,
    src_ip TEXT,
    src_port INTEGER,
    dest_ip TEXT,
    dest_port INTEGER
);
"


# Function to get current timestamp
get_timestamp() {
  date +"$TIMESTAMP_FORMAT"
}

# Function to get interface name
get_interface() {
  read -p "Enter the network interface to monitor (e.g., eth0, en0): " INTERFACE
  if ! ip link show "$INTERFACE" > /dev/null 2>&1; then
    echo "Error: Interface '$INTERFACE' not found. Using default 'eth0'."
    INTERFACE="eth0"
  fi
  echo "Monitoring interface: $INTERFACE"
}

# Function to capture network traffic and log details
capture_traffic() {
  tcpdump -i "$INTERFACE" -n -q -tttt -l | while read line; do
    timestamp=$(get_timestamp)
    protocol=""
    src_ip=""
    src_port=""
    dest_ip=""
    dest_port=""

    # Extract relevant information based on traffic type (TCP or UDP)
    if [[ "$line" == *'IP'* ]]; then
      if [[ "$line" == *'tcp'* ]]; then
        protocol="TCP"
        src_ip=$(echo "$line" | awk '{split($3, a, "."); print a[1] "." a[2] "." a[3] "." a[4]}')
        src_port=$(echo "$line" | awk '{split($3, a, "."); split(a[5], b, ":"); print b[1]}')
        dest_ip=$(echo "$line" | awk '{split($5, a, "."); print a[1] "." a[2] "." a[3] "." a[4]}')
        dest_port=$(echo "$line" | awk '{split($5, a, "."); split(a[5], b, ":"); print b[1]}')

      elif [[ "$line" == *'udp'* ]]; then
        protocol="UDP"
        src_ip=$(echo "$line" | awk '{split($3, a, "."); print a[1] "." a[2] "." a[3] "." a[4]}')
        src_port=$(echo "$line" | awk '{split($3, a, "."); split(a[5], b, ":"); print b[1]}')
        dest_ip=$(echo "$line" | awk '{split($5, a, "."); print a[1] "." a[2] "." a[3] "." a[4]}')
        dest_port=$(echo "$line" | awk '{split($5, a, "."); split(a[5], b, ":"); print b[1]}')
      else
        protocol="OTHER"
        src_ip="N/A"
        src_port="N/A"
        dest_ip="N/A"
        dest_port="N/A"
      fi

      packet_size=$(echo "$line" | awk '{for (i=1; i<=NF; i++) if ($i=="length") print $(i+1)}')

      echo "$timestamp - Interface: $INTERFACE, Protocol: $protocol, Size: $packet_size bytes, Source: $src_ip:$src_port, Destination: $dest_ip:$dest_port" >> "$LOG_FILE"
      log_to_database "$timestamp" "$INTERFACE" "$protocol" "$packet_size" "$src_ip" "$src_port" "$dest_ip" "$dest_port"
    fi
  done
}

# Function to log data to the database
log_to_database() {
  local timestamp="$1"
  local interface="$2"
  local protocol="$3"
  local packet_size="$4"
  local src_ip="$5"
  local src_port="$6"
  local dest_ip="$7"
  local dest_port="$8"

  # Retrieve packet counts and byte counts from interface statistics
  tx_packets=$(cat /sys/class/net/"$INTERFACE"/statistics/tx_packets)
  rx_packets=$(cat /sys/class/net/"$INTERFACE"/statistics/rx_packets)
  tx_bytes=$(cat /sys/class/net/"$INTERFACE"/statistics/tx_bytes)
  rx_bytes=$(cat /sys/class/net/"$INTERFACE"/statistics/rx_bytes)

  $SQLITE_CMD "$DATABASE_FILE" "INSERT INTO network_data (timestamp, interface, tx_packets, rx_packets, tx_bytes, rx_bytes, protocol, src_ip, src_port, dest_ip, dest_port) VALUES ('$timestamp', '$interface', $tx_packets, $rx_packets, $tx_bytes, $rx_bytes, '$protocol', '$src_ip', $src_port, '$dest_ip', $dest_port);"
}

# Function to calculate average bandwidth usage
calculate_bandwidth() {
  local prev_rx_bytes=0
  local prev_tx_bytes=0

  # Initialize previous byte counts from current values.
  prev_rx_bytes=$(cat /sys/class/net/"$INTERFACE"/statistics/rx_bytes)
  prev_tx_bytes=$(cat /sys/class/net/"$INTERFACE"/statistics/tx_bytes)

  while true; do
    sleep "$SAMPLE_INTERVAL_SEC"

    local current_rx_bytes=$(cat /sys/class/net/"$INTERFACE"/statistics/rx_bytes)
    local current_tx_bytes=$(cat /sys/class/net/"$INTERFACE"/statistics/tx_bytes)

    local rx_bytes_diff=$((current_rx_bytes - prev_rx_bytes))
    local tx_bytes_diff=$((current_tx_bytes - prev_tx_bytes))

    local total_bytes_diff=$((rx_bytes_diff + tx_bytes_diff))
    local bandwidth_mbps=$(echo "scale=3; $total_bytes_diff * 8 / $SAMPLE_INTERVAL_SEC / 1000000" | bc)

    echo "$(get_timestamp) - Bandwidth Usage: $bandwidth_mbps Mbps"

    # Check for exceeding the threshold
    if (( $(echo "$bandwidth_mbps > $BANDWIDTH_THRESHOLD_MBPS" | bc -l) )); then
        echo "$(get_timestamp) - ALERT: Bandwidth usage exceeds $BANDWIDTH_THRESHOLD_MBPS Mbps!"
    fi

    # Update previous byte counts
    prev_rx_bytes="$current_rx_bytes"
    prev_tx_bytes="$current_tx_bytes"
  done
}

# Function to find top communicating hosts based on bandwidth usage
find_top_hosts() {
  echo "Top $TOP_N communicating hosts (Destination IP addresses):"
  tcpdump -i "$INTERFACE" -n -q | awk -F "." '{print $1"."$2"."$3"."$4}' | sort | uniq -c | sort -nr | head -n "$TOP_N"
}

# Function to visualize bandwidth usage
visualize_bandwidth() {
  echo "Visualizing bandwidth usage with $PLOT_TOOL..."
  # This is a basic example. Adjust as needed. Requires gnuplot to be installed.
  # The exact commands will depend on the plotting tool used.
  {
  echo "set terminal dumb size 60,20"
  echo "set title 'Network Bandwidth Usage'"
  echo "set xlabel 'Time'"
  echo "set ylabel 'Bandwidth (Mbps)'"
  echo "plot '-' using 1:2 with lines title 'Bandwidth'"
  } > plot_script.gp

  # Get bandwidth readings for gnuplot
  while true; do
    local current_rx_bytes=$(cat /sys/class/net/"$INTERFACE"/statistics/rx_bytes)
    local current_tx_bytes=$(cat /sys/class/net/"$INTERFACE"/statistics/tx_bytes)
    local timestamp=$(date +%s)  # Unix timestamp for simplicity in plotting
    echo "$timestamp $((current_rx_bytes + current_tx_bytes))"
    sleep $SAMPLE_INTERVAL_SEC
  done | awk '{printf "%s %.3f\n", strftime("%H:%M:%S", $1), ($2 - prev_bytes) * 8 / '$SAMPLE_INTERVAL_SEC' / 1000000; prev_bytes = $2}' prev_bytes=0 | tail -n 30 | gnuplot -persist plot_script.gp
}

# Main execution
# Get interface name
get_interface

# Initialize database
$SQLITE_CMD "$DATABASE_FILE" "$DB_INIT_SQL"

# Start capturing traffic in the background
capture_traffic &

# Calculate bandwidth usage in the background
calculate_bandwidth &

# Find top communicating hosts
find_top_hosts

# Visualize bandwidth usage
visualize_bandwidth

# Keep script running. You can remove this or adjust the sleep duration.
while true; do
  sleep 3600 # Sleep for an hour, adjust as needed.
done


# Usage: ./network_monitor.sh
```