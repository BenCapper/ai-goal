# This script executes an Ansible playbook, specifying a custom SSH port for connections.
# It takes the playbook file, inventory file, and SSH port as command-line arguments.

# Check if the correct number of arguments are provided.
if [ $# -ne 3 ]; then
  echo "Usage: $0 <playbook.yml> <inventory_file> <ssh_port>"
  exit 1
fi

# Assign command-line arguments to variables.
PLAYBOOK=$1
INVENTORY=$2
SSH_PORT=$3

# Check if the playbook and inventory files exist.
if [ ! -f "$PLAYBOOK" ]; then
  echo "Error: Playbook file '$PLAYBOOK' not found."
  exit 1
fi

if [ ! -f "$INVENTORY" ]; then
  echo "Error: Inventory file '$INVENTORY' not found."
  exit 1
fi

# Execute the Ansible playbook with the specified SSH port.
ansible-playbook -i "$INVENTORY" "$PLAYBOOK" -e "ansible_ssh_port=$SSH_PORT"

# Check the exit code of the ansible-playbook command.
if [ $? -ne 0 ]; then
  echo "Error: Ansible playbook execution failed."
  exit 1
fi

echo "Ansible playbook executed successfully."
exit 0
```