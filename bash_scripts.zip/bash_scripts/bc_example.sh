# This script demonstrates how to use the bc utility
# for arbitrary-precision arithmetic in a bash script.
# It shows examples of basic arithmetic operations,
# setting the scale for decimal places, and using functions.

# Example 1: Basic addition
result=$(echo "10 + 5" | bc)
echo "10 + 5 = $result"

# Example 2: Subtraction and multiplication
result=$(echo "20 - 7 * 2" | bc)
echo "20 - 7 * 2 = $result"

# Example 3: Division with default scale (0)
result=$(echo "10 / 3" | bc)
echo "10 / 3 (default scale) = $result"

# Example 4: Division with scale set to 2
result=$(echo "scale=2; 10 / 3" | bc)
echo "10 / 3 (scale=2) = $result"

# Example 5: Using variables
a=15
b=4
result=$(echo "scale=3; $a / $b" | bc)
echo "$a / $b (scale=3) = $result"

# Example 6: Defining a function in bc to calculate square root (approximate)
result=$(echo "scale=10; define sqrt(x) { return(x^(1/2)); } sqrt(2)" | bc -l)
echo "sqrt(2) (scale=10) = $result"

# Example 7: More complex expressions
result=$(echo "scale=5; (3.14159 * 2.5 * 2.5) / 2 + 10" | bc)
echo "(3.14159 * 2.5 * 2.5) / 2 + 10 (scale=5) = $result"

# File usage: bash bc_example.sh
```