# This script uses curl to fetch the releases for a given GitHub repository
# via the API and uses jq to list their tag names and release names.

# Check if the repository name is provided as an argument
if [ $# -eq 0 ]; then
  echo "Usage: $0 <owner/repo>"
  exit 1
fi

# Repository name from the first argument
REPO=$1

# GitHub API endpoint for releases
API_URL="https://api.github.com/repos/$REPO/releases"

# Fetch releases using curl and extract tag_name and name using jq
curl -s "$API_URL" | jq -r '.[].tag_name + " - " + .name'
```