# This script fetches pull requests from a GitHub repository using the GitHub API,
# filters them by state (open or closed), and sorts them by the number of comments.

# Usage: ./fetch_prs.sh <owner> <repo> <state>
# <owner>: The owner of the repository (e.g., 'octocat')
# <repo>: The name of the repository (e.g., 'Spoon-Knife')
# <state>: The state of the pull requests (open or closed)

# Check if the correct number of arguments is provided
if [ $# -ne 3 ]; then
  echo "Usage: ./fetch_prs.sh <owner> <repo> <state>"
  echo "Example: ./fetch_prs.sh octocat Spoon-Knife open"
  exit 1
fi

owner="$1"
repo="$2"
state="$3"

# Validate state
if [[ "$state" != "open" && "$state" != "closed" ]]; then
  echo "Error: State must be 'open' or 'closed'"
  exit 1
fi

# GitHub API endpoint for pull requests
api_url="https://api.github.com/repos/$owner/$repo/pulls?state=$state"

# Fetch the pull requests using curl and jq
prs=$(curl -s "$api_url" | jq -c '.')

# Check if curl or jq is installed
if ! command -v curl &> /dev/null; then
    echo "Error: curl is not installed. Please install it."
    exit 1
fi

if ! command -v jq &> /dev/null; then
    echo "Error: jq is not installed. Please install it."
    exit 1
fi

# Extract relevant information and sort by number of comments
prs_sorted=$(echo "$prs" | jq -c '.[] | {number: .number, title: .title, comments: .comments}' | sort -k3 -rn)

# Print the sorted pull requests
echo "$prs_sorted"
```