# This script takes a text file as input and replaces multiple
# different strings with their corresponding replacements.
# The mappings are defined in a separate file (mappings.txt)

# Input file
input_file="$1"

# Mappings file
mappings_file="mappings.txt"

# Check if input file exists
if [ ! -f "$input_file" ]; then
  echo "Error: Input file '$input_file' not found."
  exit 1
fi

# Check if mappings file exists
if [ ! -f "$mappings_file" ]; then
  echo "Error: Mappings file '$mappings_file' not found."
  exit 1
fi

# Read mappings from the mappings file and perform replacements
while IFS='=' read -r search replace; do
  # Escape special characters in the search string for sed
  escaped_search=$(printf '%s\n' "$search" | sed 's/[&/]/\\&/g')
  sed -i "s/$escaped_search/$replace/g" "$input_file"
done < "$mappings_file"

echo "Replacements completed in '$input_file'."

exit 0
```