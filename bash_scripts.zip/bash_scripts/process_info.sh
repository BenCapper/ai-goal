# This script takes a list of process IDs (PIDs) as input
# and displays detailed information about each process using the `ps` command.

# Usage: ./process_info.sh <PID1> <PID2> <PID3> ...

# Check if any PIDs are provided as arguments
if [ $# -eq 0 ]; then
  echo "Error: No process IDs provided."
  echo "Usage: ./process_info.sh <PID1> <PID2> <PID3> ..."
  exit 1
fi

# Iterate through the provided PIDs
for pid in "$@"; do
  # Check if the PID is a valid integer
  if ! [[ "$pid" =~ ^[0-9]+$ ]]; then
    echo "Error: Invalid process ID: $pid (must be a number)"
    continue
  fi

  # Display information about the process using ps
  echo "-----------------------------------------"
  echo "Process ID: $pid"
  ps -p "$pid" -o pid,user,pcpu,pmem,vsz,rss,tty,stat,start,time,command
done
```