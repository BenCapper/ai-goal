#
# This script connects to a database (MySQL assumed) and retrieves the schema
# of a specified table, then generates a markdown representation of the table
# structure.  It requires the database name, username, password, and table name
# as command-line arguments.

# Usage: ./db_schema_to_markdown.sh <db_name> <db_user> <db_password> <table_name>

DB_NAME="$1"
DB_USER="$2"
DB_PASSWORD="$3"
TABLE_NAME="$4"

if [ -z "$DB_NAME" ] || [ -z "$DB_USER" ] || [ -z "$DB_PASSWORD" ] || [ -z "$TABLE_NAME" ]; then
  echo "Usage: ./db_schema_to_markdown.sh <db_name> <db_user> <db_password> <table_name>"
  exit 1
fi

# Get the table schema using MySQL's DESCRIBE command.
SCHEMA=$(mysql -u"$DB_USER" -p"$DB_PASSWORD" -D"$DB_NAME" -s -N -e "DESCRIBE $TABLE_NAME;")

# Check if the DESCRIBE command returned an error.
if [ $? -ne 0 ]; then
    echo "Error: Could not retrieve schema for table '$TABLE_NAME'."
    exit 1
fi

# Output the markdown header.
echo "## Table: $TABLE_NAME"
echo ""
echo "| Column Name | Data Type | Nullable | Key | Default | Extra |"
echo "|---|---|---|---|---|---|"

# Parse the schema and output the markdown table rows.
while IFS=$'\t' read -r Field Type Null Key Default Extra; do
  echo "| $Field | $Type | $Null | $Key | $Default | $Extra |"
done <<< "$SCHEMA"
```