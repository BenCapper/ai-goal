# This script takes a directory as input and removes all hidden files and directories within it.
# Hidden files and directories are those whose names start with a dot (.).

#!/bin/bash

# Check if a directory is provided as an argument
if [ $# -eq 0 ]; then
  echo "Usage: $0 <directory>"
  exit 1
fi

# The directory to process
directory="$1"

# Check if the directory exists
if [ ! -d "$directory" ]; then
  echo "Error: Directory '$directory' does not exist."
  exit 1
fi

# Find all hidden files and directories within the directory and remove them
find "$directory" -maxdepth 1 -name ".*" -print0 | while IFS= read -r -d $'\0' item; do
  # Avoid removing the directory itself (. and ..)
  if [ "$item" != "$directory/." ] && [ "$item" != "$directory/.." ]; then
    rm -rf "$item"
    echo "Removed: $item"
  fi
done

echo "Finished removing hidden files and directories from '$directory'."
```