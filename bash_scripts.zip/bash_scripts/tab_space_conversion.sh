# This script demonstrates the usage of the `expand` and `unexpand` utilities
# to convert tabs to spaces and spaces to tabs, respectively.

# Create a sample file with tabs and spaces
cat > sample.txt <<EOF
This line	has tabs.
This   line  has spaces.
This line has both	tabs  and  spaces.
EOF

# Expand tabs to spaces using expand
echo "Expanding tabs to spaces:"
expand sample.txt > expanded.txt
cat expanded.txt

# Unexpand spaces to tabs using unexpand
echo "\nUnexpanding spaces to tabs:"
unexpand expanded.txt > unexpanded.txt
cat unexpanded.txt

# Clean up the files
rm sample.txt expanded.txt unexpanded.txt

# File usage: ./tab_space_conversion.sh
```