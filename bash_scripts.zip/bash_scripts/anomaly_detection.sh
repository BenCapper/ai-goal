#
# This script reads a log file line by line, extracts numerical fields using awk,
# and checks if any of the fields deviate significantly from their historical average.
# It uses a while loop to process each log entry and an if statement to detect anomalies.
#
# Usage: ./anomaly_detection.sh logfile.log

# Set the log file to be analyzed
LOG_FILE="$1"

# Define thresholds for anomaly detection (adjust as needed)
THRESHOLD=2.0

# Define an array to store the historical averages for each field
declare -A averages
declare -A sums
declare -A counts

# Function to calculate the average of a field
calculate_average() {
  local field_index="$1"
  local total_sum=${sums[$field_index]}
  local total_count=${counts[$field_index]}
  if [[ -n "$total_sum" && -n "$total_count" && "$total_count" -gt 0 ]]; then
    echo "$((total_sum / total_count))"
  else
    echo "0"
  fi
}

# Initialize arrays with default values
initialize_averages() {
  for i in {1..5}; do # Assume we're extracting 5 fields. Adjust as needed.
    sums[$i]=0
    counts[$i]=0
    averages[$i]=0  # Start with default average of 0, can be initialized from file.
  done
}

#Update the averages
update_averages() {
    local field_index="$1"
    local new_value="$2"
    sums[$field_index]=$(( ${sums[$field_index]} + $new_value ))
    counts[$field_index]=$(( ${counts[$field_index]} + 1 ))
    averages[$field_index]=$(calculate_average "$field_index")
}


# Initialize the arrays
initialize_averages

# Read the log file line by line
while IFS= read -r LOG_ENTRY_ANOMALY; do
  # Extract numerical fields using awk (adjust the awk command as needed)
  field1=$(echo "$LOG_ENTRY_ANOMALY" | awk '{print $1}')
  field2=$(echo "$LOG_ENTRY_ANOMALY" | awk '{print $2}')
  field3=$(echo "$LOG_ENTRY_ANOMALY" | awk '{print $3}')
  field4=$(echo "$LOG_ENTRY_ANOMALY" | awk '{print $4}')
  field5=$(echo "$LOG_ENTRY_ANOMALY" | awk '{print $5}')

  #Validate that fields can be parsed as numbers
  if ! [[ "$field1" =~ ^-?[0-9]+$ ]]; then field1=0; fi
  if ! [[ "$field2" =~ ^-?[0-9]+$ ]]; then field2=0; fi
  if ! [[ "$field3" =~ ^-?[0-9]+$ ]]; then field3=0; fi
  if ! [[ "$field4" =~ ^-?[0-9]+$ ]]; then field4=0; fi
  if ! [[ "$field5" =~ ^-?[0-9]+$ ]]; then field5=0; fi


  # Convert fields to integers
  field1=$((field1))
  field2=$((field2))
  field3=$((field3))
  field4=$((field4))
  field5=$((field5))

  # Check if any of the fields deviate significantly from their historical average
  anomaly_detected=0

  # Update averages
  update_averages 1 "$field1"
  update_averages 2 "$field2"
  update_averages 3 "$field3"
  update_averages 4 "$field4"
  update_averages 5 "$field5"

  average1=${averages[1]}
  average2=${averages[2]}
  average3=${averages[3]}
  average4=${averages[4]}
  average5=${averages[5]}

  if [[ $(echo "abs($field1 - $average1) > $THRESHOLD * $average1" | bc) -eq 1 ]] && [[ "$average1" -ne 0 ]]; then
    echo "Anomaly detected in field 1: Value=$field1, Average=$average1"
    anomaly_detected=1
  fi

  if [[ $(echo "abs($field2 - $average2) > $THRESHOLD * $average2" | bc) -eq 1 ]] && [[ "$average2" -ne 0 ]]; then
    echo "Anomaly detected in field 2: Value=$field2, Average=$average2"
    anomaly_detected=1
  fi

  if [[ $(echo "abs($field3 - $average3) > $THRESHOLD * $average3" | bc) -eq 1 ]] && [[ "$average3" -ne 0 ]]; then
    echo "Anomaly detected in field 3: Value=$field3, Average=$average3"
    anomaly_detected=1
  fi

  if [[ $(echo "abs($field4 - $average4) > $THRESHOLD * $average4" | bc) -eq 1 ]] && [[ "$average4" -ne 0 ]]; then
    echo "Anomaly detected in field 4: Value=$field4, Average=$average4"
    anomaly_detected=1
  fi

  if [[ $(echo "abs($field5 - $average5) > $THRESHOLD * $average5" | bc) -eq 1 ]] && [[ "$average5" -ne 0 ]]; then
    echo "Anomaly detected in field 5: Value=$field5, Average=$average5"
    anomaly_detected=1
  fi

  # Optional: Print the log entry if an anomaly was detected
  if [[ "$anomaly_detected" -eq 1 ]]; then
    echo "Log Entry: $LOG_ENTRY_ANOMALY"
  fi

done < "$LOG_FILE"

# End of script
```