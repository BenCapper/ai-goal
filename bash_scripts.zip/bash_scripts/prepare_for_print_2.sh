#
# This script demonstrates how to use the 'pr' utility to format files for printing.
# It includes adding headers, footers, line numbering, and pagination.

# Usage: ./prepare_for_print.sh input_file output_file

# Input file
INPUT_FILE="$1"

# Output file
OUTPUT_FILE="$2"

# Check if input and output files are provided
if [ -z "$INPUT_FILE" ] || [ -z "$OUTPUT_FILE" ]; then
  echo "Usage: ./prepare_for_print.sh input_file output_file"
  exit 1
fi

# Check if input file exists
if [ ! -f "$INPUT_FILE" ]; then
  echo "Error: Input file '$INPUT_FILE' not found."
  exit 1
fi


# Format the file using pr with options:
# -h "My Document" : Set the header to "My Document"
# -l 60            : Set the page length to 60 lines
# -n             : Add line numbering
# -t             : Suppress the default header and trailer
# -w 78            : Set the line width to 78 characters
# +1             : Begin printing with page 1 (default)
# | head -n 60: Limit the output to 60 lines per page (can also use pr +1)
#  > $OUTPUT_FILE: Redirect the output to the specified output file

pr -h "Formatted Output of: $INPUT_FILE" -l 60 -n -t -w 78 "$INPUT_FILE" > "$OUTPUT_FILE"

echo "File '$INPUT_FILE' formatted and saved to '$OUTPUT_FILE'"

# Example usage: ./prepare_for_print.sh input.txt output.txt
```