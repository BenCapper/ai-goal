# This script takes a list of filenames as input and archives each file
# into a separate compressed tar.gz file.  The archive name will be the
# same as the original filename with a ".tar.gz" extension.

# Check if any filenames are provided as arguments
if [ $# -eq 0 ]; then
  echo "Usage: $0 <file1> <file2> ..."
  exit 1
fi

# Iterate through each filename provided as an argument
for file in "$@"; do
  # Check if the file exists
  if [ ! -f "$file" ]; then
    echo "Error: File '$file' not found."
    continue # Skip to the next file
  fi

  # Create the archive filename
  archive_name="$file.tar.gz"

  # Create the compressed archive using tar and gzip
  tar -czvf "$archive_name" "$file"

  # Check if the archive was created successfully
  if [ $? -eq 0 ]; then
    echo "Successfully archived '$file' to '$archive_name'"
  else
    echo "Error: Failed to archive '$file' to '$archive_name'"
  fi
done

exit 0
```