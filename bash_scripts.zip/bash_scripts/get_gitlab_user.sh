# This script uses curl to fetch user details from the GitLab API
# and jq to extract and display the user's name and status.

# Set variables for the GitLab API endpoint, private token, and user ID.
GITLAB_URL="https://gitlab.com/api/v4"
GITLAB_TOKEN="YOUR_GITLAB_PRIVATE_TOKEN" # Replace with your actual token
USER_ID="$1"

# Check if a user ID is provided as an argument.
if [ -z "$USER_ID" ]; then
  echo "Usage: $0 <user_id>"
  exit 1
fi

# Construct the API endpoint URL.
API_ENDPOINT="$GITLAB_URL/users/$USER_ID"

# Use curl to fetch the user details from the GitLab API.
# The -s option makes curl silent (no progress bar).
# The -H option sets the private token in the header for authentication.
USER_DETAILS=$(curl -s -H "PRIVATE-TOKEN: $GITLAB_TOKEN" "$API_ENDPOINT")

# Check if the curl command was successful. In case of an error, the user details will be empty.
if [ -z "$USER_DETAILS" ]; then
    echo "Error: Could not fetch user details. Check your GitLab token and user ID."
    exit 1
fi

# Use jq to extract the name and state of the user from the JSON response.
# The .name and .state filters select the corresponding fields.
NAME=$(echo "$USER_DETAILS" | jq -r '.name')
STATUS=$(echo "$USER_DETAILS" | jq -r '.state')

# Display the user's name and status.
echo "Name: $NAME"
echo "Status: $STATUS"
```