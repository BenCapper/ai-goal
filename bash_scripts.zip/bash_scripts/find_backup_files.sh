# This script finds all files with the .bak extension
# starting from the root directory and redirects both
# standard output and standard error to the backup_files.log file.

find / -name "*.bak" &> backup_files.log
```