# This script uses curl to interact with an API that returns a 307 Temporary Redirect response.
# It follows the redirect with the original method and body, limiting the number of redirects and logging the redirect chain.

# Set the initial URL
URL="http://httpbin.org/status/307" # Example URL that returns a 307 redirect

# Set the maximum number of redirects to follow
MAX_REDIRECTS=5

# Initialize variables
redirect_count=0
current_url="$URL"
redirect_chain=() # Array to store the redirect chain

# Data to send in the request body (example)
DATA='{"key": "value"}'

# Function to perform the curl request and handle redirects
follow_redirect() {
  local url="$1"
  local data="$2"

  echo "Requesting: $url"

  # Use curl with --location to follow redirects and --max-redirs to limit redirects
  # We also use -v for verbose output to capture the redirect information, and --data to send the body

  response=$(curl -v -s --location --max-redirs "$MAX_REDIRECTS" \
                 --data "$data" "$url" 2>&1) # Capture both stdout and stderr for parsing

  # Check for errors
  if [[ $? -ne 0 ]]; then
    echo "Error: curl command failed."
    exit 1
  fi

  # Extract redirect URL from the verbose output.  This is brittle, but effective.
  #  A more robust solution would involve parsing the headers directly.

  redirect_url=$(echo "$response" | grep '< Location:' | sed 's/< Location: //g' | head -n 1)

  if [[ -n "$redirect_url" ]]; then
    redirect_chain+=("$redirect_url")
    echo "Redirected to: $redirect_url"
    return 0 # Signal a redirect happened
  else
    echo "Final response:"
    echo "$response"
    return 1 # Signal no redirect happened; final response received
  fi
}

# Main loop to follow redirects
while [[ $redirect_count -lt $MAX_REDIRECTS ]]; do
  redirect_count=$((redirect_count + 1))
  if follow_redirect "$current_url" "$DATA"; then
    # No redirect happened; break out of the loop
    break
  else
    # Update the current URL for the next iteration
    current_url="${redirect_chain[-1]}" # Get the last element of the redirect_chain
  fi
done

# Print the redirect chain
echo "Redirect Chain:"
for url in "${redirect_chain[@]}"; do
  echo "  $url"
done

exit 0
```