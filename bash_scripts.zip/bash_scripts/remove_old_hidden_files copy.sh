# This script takes a directory as input and removes all hidden files
# that were last modified before a specified date.

# Usage: ./remove_old_hidden_files.sh <directory> <date_YYYY-MM-DD>

# Check if the correct number of arguments are provided
if [ $# -ne 2 ]; then
  echo "Usage: $0 <directory> <date_YYYY-MM-DD>"
  exit 1
fi

directory="$1"
date_str="$2"

# Check if the directory exists
if [ ! -d "$directory" ]; then
  echo "Error: Directory '$directory' does not exist."
  exit 1
fi

# Check if the date is in the correct format (YYYY-MM-DD)
if ! [[ "$date_str" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}$ ]]; then
  echo "Error: Invalid date format. Use YYYY-MM-DD."
  exit 1
fi

# Convert the date to seconds since epoch
cutoff_timestamp=$(date -d "$date_str" +%s)

# Find all hidden files in the directory that were modified before the cutoff date
find "$directory" -type f -name ".*" -print0 | while IFS= read -r -d $'\0' file; do
  # Get the last modification time of the file in seconds since epoch
  modification_timestamp=$(stat -c %Y "$file")

  # Compare the modification time with the cutoff time
  if [ "$modification_timestamp" -lt "$cutoff_timestamp" ]; then
    # Remove the file
    rm -f "$file"
    echo "Removed: $file"
  fi
done

echo "Done."
exit 0
```