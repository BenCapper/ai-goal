# This script demonstrates how to use curl and wget with options for handling cookies and authentication.
# It shows examples of saving cookies, sending cookies, and authenticating using both utilities.

# Usage: ./curl_wget_example.sh

# --- Curl Examples ---

# 1. Saving Cookies to a File
echo "--- Curl: Saving Cookies ---"
curl -c cookies.txt "https://httpbin.org/cookies/set?name=value"
cat cookies.txt # Displaying the cookies.txt file

# 2. Sending Cookies from a File
echo "--- Curl: Sending Cookies ---"
curl -b cookies.txt "https://httpbin.org/cookies"

# 3. Authentication (Basic)
echo "--- Curl: Basic Authentication ---"
curl -u user:password "https://httpbin.org/basic-auth/user/password"

# 4. Authentication (Digest)
echo "--- Curl: Digest Authentication ---"
curl --digest -u user:password "https://httpbin.org/digest-auth/auth/user/password"

# --- Wget Examples ---

# 1. Saving Cookies to a File (Requires --save-cookies)
echo "--- Wget: Saving Cookies ---"
wget --save-cookies cookies_wget.txt "https://httpbin.org/cookies/set?name_wget=value_wget" -q -O /dev/null # -q for quiet, -O to discard output
cat cookies_wget.txt # Displaying the cookies_wget.txt file

# 2. Sending Cookies from a File (Requires --load-cookies)
echo "--- Wget: Sending Cookies ---"
wget --load-cookies cookies_wget.txt "https://httpbin.org/cookies" -q -O wget_output.txt # -q for quiet, -O to save output
cat wget_output.txt # Displaying the wget_output file

# 3. Authentication
echo "--- Wget: Authentication ---"
wget --http-user=user --http-password=password "https://httpbin.org/basic-auth/user/password" -q -O wget_auth_output.txt # -q for quiet, -O to save output
cat wget_auth_output.txt # Displaying the wget_auth_output file

# Clean up example files
rm -f cookies.txt cookies_wget.txt wget_output.txt wget_auth_output.txt
```