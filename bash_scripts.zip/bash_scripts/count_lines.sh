# This script takes a directory as input and counts the lines of code in each file within that directory.
# It ignores empty lines and lines containing only comments.

# Check if a directory is provided as an argument
if [ $# -eq 0 ]; then
  echo "Usage: $0 <directory>"
  exit 1
fi

# Directory to process
directory="$1"

# Check if the directory exists
if [ ! -d "$directory" ]; then
  echo "Error: Directory '$directory' not found."
  exit 1
fi

# Iterate through each file in the directory
find "$directory" -type f -print0 | while IFS= read -r -d $'\0' file; do
  # Count lines of code, excluding empty lines and lines containing only comments
  line_count=$(grep -vc "^[[:space:]]*(\/\/.*|\#.*)?$" "$file")

  # Print the file name and the line count
  echo "$file: $line_count"
done
```