#
# This script merges files side-by-side using paste, adding line numbers to each file's output.
#
# It takes a variable number of file arguments.
# For each file, it uses 'nl' to add line numbers, then pastes the result.
# Finally, it handles the case where the number of files is less than 2 by exiting with an error message.

if [ $# -lt 2 ]; then
  echo "Usage: $0 file1 file2 [file3 ...]" >&2
  exit 1
fi

paste <(nl "$1") $(
  shift
  for file in "$@"; do
    echo "<(nl \"\$file\")"
  done
) | bash -s

```