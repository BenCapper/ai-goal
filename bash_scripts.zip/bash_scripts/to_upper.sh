# This script uses the tr command to convert lowercase characters to uppercase characters.
# It reads input from standard input and writes the converted output to standard output.

tr '[:lower:]' '[:upper:]'
```