# This script retrieves applied cluster resource quotas across all namespaces in OpenShift.
# It calculates the percentage of usage for CPU and Memory, and the usage for Pods.
# The output is then formatted and sorted by CPU usage percentage in descending order.

oc get appliedclusterresourcequota --all-namespaces -o custom-columns=NAMESPACE:.metadata.namespace,CPU_USAGE:".status.used.cpu / .status.hard.cpu * 100",MEMORY_USAGE:".status.used.memory / .status.hard.memory * 100",PODS_USAGE:".status.used.pods / .status.hard.pods" | sort -k 2 -n -r
```