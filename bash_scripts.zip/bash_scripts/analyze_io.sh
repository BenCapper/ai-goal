# This script monitors the I/O read and write rates of a specific process
# and triggers an alert if the rates exceed predefined thresholds.
# usage: ./analyze_io.sh <PID> <READ_THRESHOLD_KB> <WRITE_THRESHOLD_KB>

# Get the PID and thresholds from command line arguments.
PROCESS_TO_ANALYZE_IO_RATE=$1
READ_THRESHOLD_KB=$2
WRITE_THRESHOLD_KB=$3

# Check if PID and thresholds are provided.
if [ -z "$PROCESS_TO_ANALYZE_IO_RATE" ] || [ -z "$READ_THRESHOLD_KB" ] || [ -z "$WRITE_THRESHOLD_KB" ]; then
  echo "Usage: $0 <PID> <READ_THRESHOLD_KB> <WRITE_THRESHOLD_KB>"
  exit 1
fi

# Check if the PID is a number.
if ! [[ "$PROCESS_TO_ANALYZE_IO_RATE" =~ ^[0-9]+$ ]]; then
  echo "Error: PID must be a number."
  exit 1
fi

# Check if the READ_THRESHOLD_KB is a number.
if ! [[ "$READ_THRESHOLD_KB" =~ ^[0-9]+$ ]]; then
  echo "Error: READ_THRESHOLD_KB must be a number."
  exit 1
fi

# Check if the WRITE_THRESHOLD_KB is a number.
if ! [[ "$WRITE_THRESHOLD_KB" =~ ^[0-9]+$ ]]; then
  echo "Error: WRITE_THRESHOLD_KB must be a number."
  exit 1
fi

# Function to send an alert.
alert() {
  message="$1"
  echo "ALERT: $message" >&2 # Send alert to stderr.  Could also send an email, etc.
}

# Main loop to monitor I/O rates.
while true; do
  # Use iostat to get I/O statistics for the process.
  iostat -p "$PROCESS_TO_ANALYZE_IO_RATE" 1 2 | awk -v pid="$PROCESS_TO_ANALYZE_IO_RATE" -v read_threshold="$READ_THRESHOLD_KB" -v write_threshold="$WRITE_THRESHOLD_KB" '
    BEGIN {
      # Skip the first two lines.
      skip = 2;
    }
    {
      if (skip > 0) {
        skip--;
        next;
      }

      # Extract the process name, read rate, and write rate.
      if ($1 == pid) {
        read_rate = $6;  # rkB/s
        write_rate = $7; # wkB/s

        # Check if the read rate exceeds the threshold.
        if (read_rate > read_threshold) {
          printf("Read rate: %.2f KB/s exceeds threshold: %d KB/s\n", read_rate, read_threshold);
          system("bash -c 'date; echo \"Read rate exceeded!\"'"); # Execute a separate command to avoid awk limitations.
        }

        # Check if the write rate exceeds the threshold.
        if (write_rate > write_threshold) {
          printf("Write rate: %.2f KB/s exceeds threshold: %d KB/s\n", write_rate, write_threshold);
          system("bash -c 'date; echo \"Write rate exceeded!\"'"); # Execute a separate command to avoid awk limitations.
        }
      }
    }
  '

  # Wait for a short interval before checking again (iostat interval is 1 second).
  sleep 1
done

# Example usage:
# ./analyze_io.sh 1234 1000 500
```