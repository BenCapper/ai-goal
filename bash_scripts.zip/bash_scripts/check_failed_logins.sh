# This script iterates through a list of usernames and checks if they had any failed login attempts
# using the 'last -i -x' command.

# USAGE: ./check_failed_logins.sh username1 username2 username3 ...

usernames=("$@")

for username in "${usernames[@]}"; do
  # Use last -i -x to check for failed login attempts for the current username.
  # last -i shows IP addresses, and -x shows shutdown entries and logins that did not succeed.
  if last -i -x | grep "authentication failure\|invalid user" | grep "$username" > /dev/null; then
    echo "Failed login attempts found for user: $username"
  else
    echo "No failed login attempts found for user: $username"
  fi
done
```