# This script applies a git patch with a specified line number offset.
# It takes the patch file, the offset value, and optionally the target directory as input.

# Function to display usage instructions
usage() {
  echo "Usage: $0 <patch_file> <line_offset> [target_directory]"
  echo "  patch_file: The path to the patch file."
  echo "  line_offset: The line number offset to apply."
  echo "  target_directory: (Optional) The directory to apply the patch in. Defaults to the current directory."
  exit 1
}

# Check for the correct number of arguments
if [ $# -lt 2 ] || [ $# -gt 3 ]; then
  usage
fi

# Assign arguments to variables
patch_file="$1"
line_offset="$2"

# Check if the offset is a valid number
if ! [[ "$line_offset" =~ ^-?[0-9]+$ ]]; then
  echo "Error: Line offset must be an integer."
  usage
fi

# Set target directory or default to current directory
if [ $# -eq 3 ]; then
  target_directory="$3"
else
  target_directory="."
fi

# Check if the patch file exists
if [ ! -f "$patch_file" ]; then
  echo "Error: Patch file '$patch_file' not found."
  exit 1
fi

# Apply the patch with the specified offset
echo "Applying patch '$patch_file' with offset '$line_offset' to directory '$target_directory'..."
git apply --directory="$target_directory" --reject --whitespace=fix --index --recount --unidiff-zero -p0 < "$patch_file" --offset="$line_offset"

# Check the exit code
if [ $? -eq 0 ]; then
  echo "Patch applied successfully."
else
  echo "Patch application failed. Check the .rej files for conflicts."
  exit 1
fi

exit 0
```