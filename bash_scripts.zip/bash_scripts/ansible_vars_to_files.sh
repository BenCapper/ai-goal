# This script runs an Ansible playbook and then extracts all registered variables
# from each host, saving them to separate files named after the host.

# Check if Ansible playbook is provided as an argument
if [ -z "$1" ]; then
  echo "Usage: $0 <ansible_playbook.yml>"
  exit 1
fi

PLAYBOOK="$1"

# Run the Ansible playbook
ansible-playbook "$PLAYBOOK"

# Extract registered variables for each host and save to files
for host in $(ansible-inventory --list-hosts all); do
  echo "Extracting variables for host: $host"

  # Use ansible-playbook with --step to pause after each task
  # and register variables.

  # Create a temporary file to store the output
  temp_file=$(mktemp)

  ansible-playbook -i inventory "$PLAYBOOK" -l "$host" --step --extra-vars "ansible_pause_on_start=false" 2>&1 | tee "$temp_file"
  # The -i inventory flag is included in case an inventory file is needed
  # Replace "inventory" with the actual inventory path if needed

  # Extract the variables using awk and grep.  This might need adjustment depending
  # on the ansible output format.  This is a basic example that assumes the
  # registered vars are printed in a consistent format after the task completes.
  awk '/TASK \[.*\]/,/PLAY RECAP/' "$temp_file" | grep -E "registered:.*[[:space:]]([[:graph:]]+)$" | awk -F'registered: ' '{print $2}'|  sed 's/ //g' | tr -d '\r' > "${host}.vars"

  # Clean up the temporary file
  rm "$temp_file"

  echo "Variables saved to ${host}.vars"
done

echo "Finished extracting variables."
```