# This script iterates through a list of packages and checks if they are installed
# using rpm or dpkg, depending on the OS.

# Usage: ./check_packages.sh package1 package2 ...

packages=("$@")

# Determine the package manager (rpm or dpkg)
if command -v rpm &> /dev/null; then
  package_manager="rpm"
elif command -v dpkg &> /dev/null; then
  package_manager="dpkg"
else
  echo "Error: Neither rpm nor dpkg found.  Exiting."
  exit 1
fi

# Iterate through the list of packages
for package in "${packages[@]}"; do
  # Check if the package is installed using the appropriate package manager
  if [[ "$package_manager" == "rpm" ]]; then
    if rpm -q "$package" &> /dev/null; then
      echo "$package is installed (using rpm)."
    else
      echo "$package is NOT installed (using rpm)."
    fi
  elif [[ "$package_manager" == "dpkg" ]]; then
    if dpkg -s "$package" &> /dev/null; then
      echo "$package is installed (using dpkg)."
    else
      echo "$package is NOT installed (using dpkg)."
    fi
  fi
done

# Usage: ./check_packages.sh package1 package2 ...
```