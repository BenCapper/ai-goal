# This script declares a variable TEXT_TO_CHECK_UPPER
# and uses an if statement with regular expressions
# to check if the string contains only uppercase letters.

# Usage: ./check_uppercase.sh

TEXT_TO_CHECK_UPPER="THISISUPPERCASE"

if [[ "$TEXT_TO_CHECK_UPPER" =~ ^[A-Z]+$ ]]; then
  echo "The string '$TEXT_TO_CHECK_UPPER' contains only uppercase letters."
else
  echo "The string '$TEXT_TO_CHECK_UPPER' does not contain only uppercase letters."
fi
```