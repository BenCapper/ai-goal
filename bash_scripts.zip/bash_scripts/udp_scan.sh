# This script demonstrates how to use nmap to perform UDP scans.
# It takes a target host and an optional port range as input.
# If no port range is provided, it scans the top 1000 most common UDP ports.

# Usage: ./udp_scan.sh <target_host> [port_range]

# Check if the target host is provided
if [ -z "$1" ]; then
  echo "Usage: ./udp_scan.sh <target_host> [port_range]"
  exit 1
fi

TARGET_HOST="$1"
PORT_RANGE="$2"

# If no port range is provided, scan the top 1000 UDP ports
if [ -z "$PORT_RANGE" ]; then
  echo "Scanning top 1000 UDP ports on $TARGET_HOST..."
  nmap -sU -T4 -F "$TARGET_HOST"
else
  echo "Scanning UDP ports $PORT_RANGE on $TARGET_HOST..."
  nmap -sU -p "$PORT_RANGE" -T4 "$TARGET_HOST"
fi

echo "Scan complete."
```