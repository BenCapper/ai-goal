# This script manages DHCP leases on a Linux DHCP server using command-line tools.
# It provides functions to list active leases, search for a specific lease,
# and clear a lease based on IP address or MAC address.

# Configuration
DHCP_LEASE_FILE="/var/lib/dhcp/dhcpd.leases" # Path to the DHCP lease file
DHCP_SERVER_INTERFACE="eth0" # The interface DHCP server is bound to.

# Function to list all active DHCP leases
list_leases() {
  echo "--- Active DHCP Leases ---"
  grep "lease" "$DHCP_LEASE_FILE" | grep "binding state active" -B 9 | grep "lease" | awk '{print $2}' | while read ip; do
      mac=$(grep "lease $ip" "$DHCP_LEASE_FILE" -A 10 | grep "hardware ethernet" | awk '{print $3}' | tr -d ';')
      hostname=$(grep "lease $ip" "$DHCP_LEASE_FILE" -A 10 | grep "client-hostname" | awk '{print $2}' | tr -d ';"')
      if [ -z "$hostname" ]; then
          hostname="N/A"
      fi
      echo "IP Address: $ip, MAC Address: $mac, Hostname: $hostname"
  done
}

# Function to search for a DHCP lease by IP address
search_lease_by_ip() {
  local ip_address="$1"
  echo "--- Searching for lease with IP Address: $ip_address ---"
  grep "lease $ip_address" "$DHCP_LEASE_FILE" -A 10 | grep "binding state active"
  if [ $? -eq 0 ]; then
      mac=$(grep "lease $ip_address" "$DHCP_LEASE_FILE" -A 10 | grep "hardware ethernet" | awk '{print $3}' | tr -d ';')
      hostname=$(grep "lease $ip_address" "$DHCP_LEASE_FILE" -A 10 | grep "client-hostname" | awk '{print $2}' | tr -d ';"')
      if [ -z "$hostname" ]; then
          hostname="N/A"
      fi
      echo "IP Address: $ip_address, MAC Address: $mac, Hostname: $hostname"
  else
      echo "No active lease found for IP address: $ip_address"
  fi
}

# Function to search for a DHCP lease by MAC address
search_lease_by_mac() {
  local mac_address="$1"
  echo "--- Searching for lease with MAC Address: $mac_address ---"
  grep "hardware ethernet $mac_address" "$DHCP_LEASE_FILE" -B 5 | grep "lease" | awk '{print $2}' | while read ip; do
        hostname=$(grep "lease $ip" "$DHCP_LEASE_FILE" -A 10 | grep "client-hostname" | awk '{print $2}' | tr -d ';"')
        if [ -z "$hostname" ]; then
                hostname="N/A"
        fi

      echo "IP Address: $ip, MAC Address: $mac_address, Hostname: $hostname"
  done
}

# Function to clear a DHCP lease by IP address (requires DHCP server restart)
clear_lease_by_ip() {
  local ip_address="$1"
  echo "--- Clearing lease with IP Address: $ip_address ---"
  # This doesn't actually clear the lease from the file directly, as that would require
  # more complex parsing and modification.  Instead, it restarts the DHCP server,
  # which will eventually reclaim the IP if it's not in use.
  # A more robust solution would involve editing the dhcpd.leases file directly,
  # but this is beyond the scope of a simple script.
  if ping -c 1 "$ip_address" > /dev/null; then
    echo "Device with IP $ip_address is still reachable. Cannot reliably clear the lease."
    return 1
  fi
  
  systemctl restart isc-dhcp-server.service # Or the appropriate DHCP server service name
  echo "DHCP server restarted. Lease for IP address $ip_address will be cleared when the old lease expires and is not renewed."
}


# Function to clear a DHCP lease by MAC address (requires DHCP server restart)
clear_lease_by_mac() {
    local mac_address="$1"
    echo "--- Clearing lease with MAC Address: $mac_address ---"
    ip_address=$(search_lease_by_mac "$mac_address" | awk '{print $3}' | tr -d ',')

    if [ -z "$ip_address" ]; then
      echo "No active lease found for MAC address: $mac_address"
      return 1
    fi

    clear_lease_by_ip "$ip_address"
}

# Function to display usage instructions
usage() {
  echo "Usage: $0 [options]"
  echo "Options:"
  echo "  -l | --list           List all active DHCP leases."
  echo "  -i <ip_address> | --ip <ip_address>   Search for a lease by IP address."
  echo "  -m <mac_address> | --mac <mac_address> Search for a lease by MAC address."
  echo "  -c <ip_address> | --clear-ip <ip_address> Clear a lease by IP address (requires DHCP server restart)."
  echo "  -M <mac_address> | --clear-mac <mac_address> Clear a lease by MAC address (requires DHCP server restart)."
  echo "  -h | --help           Display this help message."
  exit 1
}

# Parse command-line arguments
while [[ $# -gt 0 ]]; do
  key="$1"
  case $key in
    -l|--list)
      list_leases
      exit 0
      ;;
    -i|--ip)
      ip_address="$2"
      search_lease_by_ip "$ip_address"
      shift # past argument
      shift # past value
      exit 0
      ;;
    -m|--mac)
      mac_address="$2"
      search_lease_by_mac "$mac_address"
      shift # past argument
      shift # past value
      exit 0
      ;;
    -c|--clear-ip)
      ip_address="$2"
      clear_lease_by_ip "$ip_address"
      shift # past argument
      shift # past value
      exit 0
      ;;
    -M|--clear-mac)
      mac_address="$2"
      clear_lease_by_mac "$mac_address"
      shift # past argument
      shift # past value
      exit 0
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)    # unknown option
      echo "Unknown option: $key"
      usage
      exit 1
      ;;
  esac
done

# If no arguments are provided, display usage instructions
usage
```