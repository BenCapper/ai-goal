# This script automates the backup process using rsync and verifies the backup integrity using md5sum.
# It backs up critical system directories and files to a specified backup directory.
# It also generates md5 checksums for verification.

# Configuration
SOURCE_DIRS="/etc /var/log /home" # Directories to back up
BACKUP_DIR="/mnt/backup" # Backup directory
MD5SUM_FILE="$BACKUP_DIR/backup_checksums.md5" # File to store md5 checksums
DATE=$(date +%Y-%m-%d_%H-%M-%S) # Timestamp for backup directory
BACKUP_DIR="$BACKUP_DIR/$DATE" # Add timestamp to backup directory

# Check if rsync is installed
if ! command -v rsync &> /dev/null; then
  echo "rsync is not installed. Please install rsync."
  exit 1
fi

# Check if md5sum is installed
if ! command -v md5sum &> /dev/null; then
  echo "md5sum is not installed. Please install md5sum."
  exit 1
fi

# Create backup directory if it doesn't exist
mkdir -p "$BACKUP_DIR"

# Function to create backup and generate md5 checksums
backup_and_checksum() {
  echo "Starting backup to $BACKUP_DIR"

  # Perform backup using rsync
  rsync -avz "$SOURCE_DIRS" "$BACKUP_DIR"

  # Generate md5 checksums
  find "$BACKUP_DIR" -type f -print0 | xargs -0 md5sum > "$MD5SUM_FILE"

  echo "Backup completed and checksums generated."
}

# Function to verify backup integrity
verify_backup() {
  echo "Verifying backup integrity..."

  # Verify checksums
  md5sum -c "$MD5SUM_FILE"

  if [ $? -eq 0 ]; then
    echo "Backup verification successful!"
  else
    echo "Backup verification failed!"
  fi
}

# Main script execution
backup_and_checksum

verify_backup

# Usage: ./backup_script.sh
```