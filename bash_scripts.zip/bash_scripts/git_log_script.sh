# This script uses git to show the commit history of a specific branch.
# It displays short commit hashes and relative dates, and sorts the output
# by author date in reverse chronological order.

# Set the branch to inspect.  If no branch is specified as an argument to the
# script, use the current branch.
branch="${1:-}"

# Use git log to retrieve the commit history
git log --pretty=format:"%h %ar %s" --date=relative --author-date-order --reverse "$branch"
```