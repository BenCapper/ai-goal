# This script demonstrates how to use ssh with remote port forwarding.
# It forwards a local port to a different port on the remote host.
# This is useful for accessing services running on the remote host
# that are not directly exposed to the internet.

# Define variables for easy modification
LOCAL_PORT=8080       # Local port to listen on
REMOTE_HOST="user@remote_host" # Remote host to connect to
REMOTE_PORT=3000      # Remote port to forward to
REMOTE_ADDRESS="localhost" #The address on the remote host to connect to. Defaults to localhost if unset.

# Construct the ssh command with remote port forwarding
# The -R option specifies remote port forwarding:
# -R [bind_address:]port:host:hostport
#   Binds the local bind_address:port and forwards all connections to host:hostport on the remote side.
#   The bind_address part is optional.
# The -N option tells ssh not to execute a remote command after the connection is established.
# The -f option requests ssh to go to background after authentication

ssh -fN -R "$LOCAL_PORT:$REMOTE_ADDRESS:$REMOTE_PORT" "$REMOTE_HOST"

# Echo a message to indicate that the forwarding is set up
echo "Remote port forwarding set up: Local port $LOCAL_PORT forwarded to $REMOTE_ADDRESS:$REMOTE_PORT on $REMOTE_HOST"

# Example usage
# ./ssh_remote_port_forwarding.sh
```