#
# This script demonstrates how to use the 'route' and 'ip route' commands to manage network tunnels.
# It covers creating, deleting, and listing routes through a hypothetical tunnel interface.
#

# Usage: ./tunnel_management.sh <tunnel_interface> <tunnel_local_ip> <tunnel_remote_ip> <destination_network> <gateway_ip>

# Check if the correct number of arguments are provided
if [ $# -ne 5 ]; then
  echo "Usage: ./tunnel_management.sh <tunnel_interface> <tunnel_local_ip> <tunnel_remote_ip> <destination_network> <gateway_ip>"
  exit 1
fi

TUNNEL_IFACE=$1
TUNNEL_LOCAL_IP=$2
TUNNEL_REMOTE_IP=$3
DEST_NETWORK=$4
GATEWAY_IP=$5

#
# Create a tunnel interface using 'ip tunnel' (assuming it doesn't already exist)
# Note: This part requires root privileges
#
# echo "Creating tunnel interface $TUNNEL_IFACE..."
# ip tunnel add $TUNNEL_IFACE mode ipip local $TUNNEL_LOCAL_IP remote $TUNNEL_REMOTE_IP
# ip link set $TUNNEL_IFACE up
# ip addr add $TUNNEL_LOCAL_IP/32 dev $TUNNEL_IFACE

# Display current routing table before tunnel modification
echo "Current routing table before tunnel:"
route -n

#
# Add a route through the tunnel interface to a destination network using 'ip route'
#
echo "Adding route to $DEST_NETWORK via $TUNNEL_IFACE using ip route..."
ip route add $DEST_NETWORK via $TUNNEL_IFACE

# Display routing table after adding the tunnel route (ip route)
echo "Routing table after adding route using ip route:"
ip route

#
# Add a route through the tunnel interface to a destination network using 'route' (legacy)
#
echo "Adding route to $DEST_NETWORK via $GATEWAY_IP using route..."
route add -net $DEST_NETWORK gw $GATEWAY_IP dev $TUNNEL_IFACE

# Display routing table after adding the tunnel route (route)
echo "Routing table after adding route using route:"
route -n

#
# List routes using 'route'
#
echo "Listing routes using route:"
route -n

#
# List routes using 'ip route'
#
echo "Listing routes using ip route:"
ip route

#
# Delete the route through the tunnel interface (ip route)
#
echo "Deleting route to $DEST_NETWORK via $TUNNEL_IFACE using ip route..."
ip route del $DEST_NETWORK via $TUNNEL_IFACE

#
# Delete the route through the tunnel interface (route)
#
echo "Deleting route to $DEST_NETWORK via $GATEWAY_IP using route..."
route del -net $DEST_NETWORK gw $GATEWAY_IP dev $TUNNEL_IFACE

# Display routing table after deleting the tunnel route
echo "Routing table after deleting routes:"
route -n
ip route

#
# Clean up the tunnel interface (requires root privileges) if it was created earlier (uncomment the following)
#
# echo "Deleting tunnel interface $TUNNEL_IFACE..."
# ip link del $TUNNEL_IFACE

#
#End
#
#file usage: ./tunnel_management.sh <tunnel_interface> <tunnel_local_ip> <tunnel_remote_ip> <destination_network> <gateway_ip>
```