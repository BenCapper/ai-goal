# This script iterates through a sequence of numbers using a for loop.
# It checks if each number is not greater than 3 using an if statement.
# If the condition is met, it prints the number followed by "is not greater than 3".

# Usage: ./number_check.sh

for i in 1 2 3 4 5
do
  if [[ $i -le 3 ]]
  then
    echo "$i is not greater than 3"
  fi
done
```