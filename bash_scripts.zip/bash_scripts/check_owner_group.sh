# This script iterates through a list of files and checks if the owner and group are the same.
# It uses a for loop to iterate through the files and an if statement with -O and -g to check the owner and group.

# Usage: ./check_owner_group.sh file1 file2 file3 ...

# Loop through the provided files.
for F in "$@"; do
  # Check if the owner and group are the same.
  if [[ -O "$F" && -g "$F" ]]; then
    echo "File '$F': Owner and group are the same (Owner)."
  else
    echo "File '$F': Owner and group are NOT the same (Owner)."
  fi
done
```