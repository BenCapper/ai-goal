# This script demonstrates the use of ltrace to trace system calls
# related to process signals. It sends various signals to a target process
# and captures the system calls involved in signal handling using ltrace.

# First, we create a simple C program that sleeps indefinitely.
# This will be our target process.

cat > signal_handler.c <<EOF
#include <stdio.h>
#include <signal.h>
#include <unistd.h>

void signal_handler(int signum) {
    printf("Signal %d received.\n", signum);
}

int main() {
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);
    signal(SIGUSR1, signal_handler);

    printf("Process started. PID: %d\n", getpid());
    while (1) {
        sleep(1);
    }
    return 0;
}
EOF

# Compile the C program
gcc signal_handler.c -o signal_handler

# Start the signal_handler process in the background
./signal_handler &
target_pid=$!

# Wait a short time to ensure the process is running
sleep 1

# Now, use ltrace to trace system calls related to signal handling
# while sending signals to the target process

ltrace -p $target_pid -e signal 2>&1 | tee ltrace_output.txt &
ltrace_pid=$!

# Send some signals to the target process
kill -SIGINT $target_pid
sleep 1
kill -SIGTERM $target_pid
sleep 1
kill -SIGUSR1 $target_pid
sleep 1
kill -SIGKILL $target_pid # This will terminate the target process

# Wait for target process to terminate
wait $target_pid 2>/dev/null

# Kill ltrace, important because it will be waiting for target that might not exist anymore
kill $ltrace_pid 2>/dev/null

# Display the captured ltrace output
echo "Captured ltrace output:"
cat ltrace_output.txt

# Clean up the compiled executable and the ltrace output file
rm signal_handler
rm signal_handler.c
rm ltrace_output.txt

# file usage: bash trace_signals.sh
```