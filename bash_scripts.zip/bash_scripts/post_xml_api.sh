# This script uses curl to send an XML POST request to an API.
# It defines the XML data with specific attributes, a root element,
# and multiple XML namespace prefixes.

# Define the API endpoint
API_ENDPOINT="https://example.com/api/endpoint"

# Define the XML data
XML_DATA='<?xml version="1.0" encoding="UTF-8"?>
<root xmlns:prefix1="http://example.com/namespace1"
      xmlns:prefix2="http://example.com/namespace2"
      attribute1="value1">
  <prefix1:element1 attribute2="value2">
    <prefix2:element2>Data for element 2</prefix2:element2>
  </prefix1:element1>
</root>'

# Use curl to send the POST request
curl -X POST \
  -H "Content-Type: application/xml" \
  -d "$XML_DATA" \
  "$API_ENDPOINT"
```