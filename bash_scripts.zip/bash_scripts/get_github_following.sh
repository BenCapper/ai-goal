# This script fetches the list of users a specified user is following on GitHub
# using the GitHub API and jq to parse the JSON output.

# Usage: ./get_github_following.sh <github_username>

# Check if a username is provided as an argument.
if [ -z "$1" ]; then
  echo "Usage: ./get_github_following.sh <github_username>"
  exit 1
fi

USERNAME="$1"
API_URL="https://api.github.com/users/$USERNAME/following"

# Fetch the list of followed users from the GitHub API.
FOLLOWING=$(curl -s "$API_URL")

# Use jq to extract the login names of the followed users.
FOLLOWING_LIST=$(echo "$FOLLOWING" | jq -r '.[].login')

# Print the list of followed users.
echo "Users followed by $USERNAME:"
echo "$FOLLOWING_LIST"

# Example Usage (commented out):
# ./get_github_following.sh githubusername
```