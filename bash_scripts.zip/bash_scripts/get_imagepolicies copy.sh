# This script retrieves and displays details of ImagePolicies in a specified OpenShift project.
# It extracts the admissionReviewVersions, parameters, selectors, image match criteria, and failurePolicy using oc get imagepolicy.

# Check if the namespace is provided as an argument
if [ -z "$1" ]; then
  echo "Usage: $0 <namespace>"
  exit 1
fi

NAMESPACE="$1"

# Get the ImagePolicies in wide output format
oc get imagepolicy -o wide -n "$NAMESPACE" | awk '
  NR==1 {
    print "NAME\tADMISSIONREVIEWVERSIONS\tPARAMETERS\tSELECTORS\tIMAGES\tFAILUREPOLICY"
  }
  NR>1 {
    name = $1
    admissionReviewVersions = $2
    parameters = $3
    selectors = $4
    images = $5
    failurePolicy = $6

    printf "%s\t%s\t%s\t%s\t%s\t%s\n", name, admissionReviewVersions, parameters, selectors, images, failurePolicy
  }
'
```