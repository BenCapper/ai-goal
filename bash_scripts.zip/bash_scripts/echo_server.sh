# This script creates a simple TCP echo server using netcat.
# It listens on a specified port and echoes back any data it receives.
#
# Usage: ./echo_server.sh <port>

# Check if a port number is provided as an argument
if [ -z "$1" ]; then
  echo "Usage: $0 <port>"
  exit 1
fi

port=$1

# Start the netcat listener in verbose mode and keep the connection open
# -l: listen for incoming connections
# -v: verbose mode
# -k: keep listening after client disconnects
# The while loop ensures the server keeps running indefinitely.
while true; do
  nc -l -v -k -p "$port" | while read line; do
    echo "$line"
  done
done
```