#
# This script fetches the list of open pull requests for a specific GitHub user across all their repositories.
# It requires the GitHub CLI (gh) to be installed and configured with the user's credentials.
# The script takes the GitHub username as an argument.
#
# Usage: ./get_open_prs.sh <github_username>

# Check if the GitHub CLI is installed
if ! command -v gh &> /dev/null
then
  echo "GitHub CLI (gh) is not installed. Please install it before running this script."
  exit 1
fi

# Check if a username is provided
if [ -z "$1" ]; then
  echo "Usage: ./get_open_prs.sh <github_username>"
  exit 1
fi

username="$1"

# Get the list of repositories for the user
repos=$(gh repo list "$username" --limit 1000 --json name --jq -r '.[].name')

# Iterate through the repositories and fetch open pull requests
if [ -n "$repos" ]; then
  for repo in $repos; do
    # Get open pull requests for the current repository
    prs=$(gh pr list --repo "$username/$repo" --state open --json number,title,url --jq -r '.[].(number + " " + .title + " " + .url)')

    if [ -n "$prs" ]; then
      echo "Repository: $username/$repo"
      echo "$prs"
      echo "--------------------"
    fi
  done
else
  echo "No repositories found for user: $username"
fi
```