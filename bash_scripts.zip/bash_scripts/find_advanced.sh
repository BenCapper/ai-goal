#
# This script demonstrates advanced usage of the 'find' utility in bash.
# It includes examples of searching by file type, size, modification time,
# permissions, and executing actions on found files.

# Find regular files larger than 1MB in the current directory and list them with their size.
find . -type f -size +1M -printf "%s %p\n"

# Find directories modified in the last 7 days and list them.
find . -type d -mtime -7 -print

# Find files owned by user 'john' and change the owner to 'jane'.  Requires sudo.
# find . -type f -user john -exec sudo chown jane {} \;

# Find files with permissions 644 and change them to 755. Requires sudo.
# find . -type f -perm 644 -exec sudo chmod 755 {} \;

# Find files ending with ".txt" and print their absolute path.
find . -type f -name "*.txt" -print0 | xargs -0 realpath

# Find empty directories and remove them.
find . -type d -empty -print -delete

# Find files that have not been accessed in 30 days and create an archive
# (requires tar).
# find . -type f -atime +30 -print0 | tar -czvf archive.tar.gz --null -T -

#Usage: ./find_advanced.sh
```