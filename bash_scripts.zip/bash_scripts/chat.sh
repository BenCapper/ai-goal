# This script implements a simple chat server and client using netcat.
# It allows multiple users to connect and exchange messages in real-time.

# Server function
server() {
  while true; do
    nc -l -p "$1" | while read -r line; do
      echo "$(date +%T): $line"
    done
  done
}

# Client function
client() {
  while true; do
    read -r -p "Enter your message: " message
    echo "$message" | nc "$1" "$2"
  done
}

# Check if running as server or client
if [ "$1" == "server" ]; then
  # Start the server
  server "$2"
elif [ "$1" == "client" ]; then
  # Start the client
  client "$2" "$3"
else
  echo "Usage: $0 server <port>"
  echo "       $0 client <server_ip> <port>"
  exit 1
fi

# Usage: ./chat.sh server <port>
#        ./chat.sh client <server_ip> <port>
```