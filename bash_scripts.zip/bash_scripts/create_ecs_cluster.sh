# This script creates a new ECS cluster using the AWS CLI.

# Usage: ./create_ecs_cluster.sh <cluster_name>

# Check if cluster name is provided
if [ -z "$1" ]; then
  echo "Error: Cluster name is required."
  echo "Usage: ./create_ecs_cluster.sh <cluster_name>"
  exit 1
fi

CLUSTER_NAME="$1"

# Create the ECS cluster
aws ecs create-cluster \
  --cluster-name "$CLUSTER_NAME"
```