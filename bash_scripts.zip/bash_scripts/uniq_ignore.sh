# This script uses uniq to compare lines ignoring a specified number of leading and trailing characters, and ignoring case.

# Set the number of leading characters to ignore.
LEADING_CHARS=0

# Set the number of trailing characters to ignore.
TRAILING_CHARS=0

# Set the input file (optional, can be piped in).
INPUT_FILE=""

# Function to print usage instructions.
usage() {
  echo "Usage: $0 [-l <leading_chars>] [-t <trailing_chars>] [<input_file>]"
  echo "  -l <leading_chars>  Number of leading characters to ignore."
  echo "  -t <trailing_chars>  Number of trailing characters to ignore."
  echo "  <input_file>         Input file. If not specified, reads from stdin."
  exit 1
}


# Parse command line options.
while getopts "l:t:" opt; do
  case "$opt" in
    l)
      LEADING_CHARS="$OPTARG"
      ;;
    t)
      TRAILING_CHARS="$OPTARG"
      ;;
    \?)
      echo "Invalid option: -$OPTARG" >&2
      usage
      ;;
    :)
      echo "Option -$OPTARG requires an argument." >&2
      usage
      ;;
  esac
done

shift $((OPTIND-1))

# Check if an input file is specified.
if [ $# -eq 1 ]; then
  INPUT_FILE="$1"
elif [ $# -gt 1 ]; then
  usage
fi



# Process the input.
if [ -n "$INPUT_FILE" ]; then
  # Read from file
  if [ ! -r "$INPUT_FILE" ]; then
    echo "Error: Cannot read file '$INPUT_FILE'." >&2
    exit 1
  fi

  while IFS= read -r line; do
    # Convert to lowercase.
    line_lower=$(echo "$line" | tr '[:upper:]' '[:lower:]')

    # Ignore leading and trailing characters.
    if [ $LEADING_CHARS -gt 0 ]; then
      line_lower=$(echo "$line_lower" | cut -c $((LEADING_CHARS+1))-)
    fi
    if [ $TRAILING_CHARS -gt 0 ]; then
      line_length=$(echo -n "$line_lower" | wc -c)
      if [ $line_length -gt $TRAILING_CHARS ]; then
          line_lower=$(echo "$line_lower" | cut -c -$((line_length - TRAILING_CHARS)))
      else
          line_lower="" # Avoid errors for very short lines
      fi

    fi
    echo "$line_lower"
  done < "$INPUT_FILE" | uniq -i

else
  # Read from stdin
  while IFS= read -r line; do
    # Convert to lowercase.
    line_lower=$(echo "$line" | tr '[:upper:]' '[:lower:]')

    # Ignore leading and trailing characters.
    if [ $LEADING_CHARS -gt 0 ]; then
      line_lower=$(echo "$line_lower" | cut -c $((LEADING_CHARS+1))-)
    fi
    if [ $TRAILING_CHARS -gt 0 ]; then
      line_length=$(echo -n "$line_lower" | wc -c)
      if [ $line_length -gt $TRAILING_CHARS ]; then
          line_lower=$(echo "$line_lower" | cut -c -$((line_length - TRAILING_CHARS)))
      else
          line_lower="" # Avoid errors for very short lines
      fi
    fi
    echo "$line_lower"
  done | uniq -i
fi
```