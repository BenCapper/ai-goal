# This script removes a specific at job given its job ID.

# Check if a job ID is provided as an argument.
if [ $# -ne 1 ]; then
  echo "Usage: $0 <job_id>"
  exit 1
fi

# Store the job ID.
JOB_ID="$1"

# Remove the at job using atrm.
atrm "$JOB_ID"

# Check the exit status of atrm to see if the command was successful.
if [ $? -eq 0 ]; then
  echo "Job $JOB_ID removed successfully."
else
  echo "Failed to remove job $JOB_ID."
  exit 1
fi

exit 0
```