# This script monitors the CPU temperature of individual cores.
# It requires the 'sensors' command, which is part of the 'lm-sensors' package.
# The script outputs the temperature of each core every few seconds.

# Check if the 'sensors' command is available.
if ! command -v sensors &> /dev/null; then
  echo "Error: 'sensors' command not found. Please install the 'lm-sensors' package."
  exit 1
fi

# Function to get the CPU temperature for a given core.
get_core_temp() {
  core="$1"
  # Adjust the grep pattern according to your sensors output. Common patterns:
  # Core $core:        +45.0°C  (high = +80.0°C, crit = +90.0°C)
  # Tdie:          +40.0°C
  # Package id 0:  +42.0°C
  temp=$(sensors | grep "Core $core:" | awk '{print $4}' | tr -d '+°C')

  # If the output is Package id 0 or similar format
  if [ -z "$temp" ]; then
      temp=$(sensors | grep "Package id $core:" | awk '{print $4}' | tr -d '+°C')
  fi

  if [ -z "$temp" ]; then
      temp=$(sensors | grep "Tdie:" | grep "$core" | awk '{print $2}' | tr -d '+°C')
  fi

  echo "$temp"
}

# Main loop
while true; do
  clear
  echo "CPU Core Temperatures:"

  # Determine the number of cores (This assumes cores are numbered sequentially starting from 0.)
  num_cores=0
  while true; do
    temp=$(get_core_temp "$num_cores")
    if [ -z "$temp" ]; then
      break
    fi
    num_cores=$((num_cores + 1))
  done

  # Display temperatures for each core
  for i in $(seq 0 $(($num_cores - 1))); do
    temp=$(get_core_temp "$i")
    if [ -n "$temp" ]; then
      echo "Core $i: $temp °C"
    else
      echo "Core $i: N/A"
    fi
  done

  sleep 5 # Update every 5 seconds
done
```