# This script creates a simple HTTP server using netcat (nc) and basic bash scripting.
# It serves files from the current directory and supports custom error pages.

# Usage: ./simple_http_server.sh [port] [error_page]

PORT=${1:-8080} # Default port 8080
ERROR_PAGE=${2:-error.html} # Default error page error.html

# Function to handle HTTP requests
handle_request() {
  local request
  local method path version
  local file_path
  local status_code
  local content_type

  # Read the first line of the request (method, path, version)
  IFS=' ' read -r method path version <&3

  # Check if the method is GET
  if [[ "$method" != "GET" ]]; then
    status_code="405 Method Not Allowed"
    content_type="text/html"
    body="<html><body><h1>405 Method Not Allowed</h1><p>Only GET requests are supported.</p></body></html>"
  else
    # Sanitize path - remove any leading/trailing slashes and prevent directory traversal
    path=$(echo "$path" | sed -e 's/^\///' -e 's/\/\.\.\///g')

    # Construct the full file path
    file_path="./$path"

    # Check if the file exists and is a regular file
    if [[ -f "$file_path" ]]; then
      status_code="200 OK"
      # Determine content type based on file extension
      case "$file_path" in
        *.html) content_type="text/html" ;;
        *.txt)  content_type="text/plain" ;;
        *.jpg|*.jpeg) content_type="image/jpeg" ;;
        *.png) content_type="image/png" ;;
        *.gif) content_type="image/gif" ;;
        *)     content_type="application/octet-stream" ;;  # Default binary type
      esac
      body=$(cat "$file_path")
    else
      # File not found, serve the error page
      if [[ -f "$ERROR_PAGE" ]]; then
        status_code="404 Not Found"
        content_type="text/html"
        body=$(cat "$ERROR_PAGE")
      else
        status_code="404 Not Found"
        content_type="text/html"
        body="<html><body><h1>404 Not Found</h1><p>The requested resource was not found.</p></body></html>"
      fi
    fi
  fi

  # Construct the HTTP response
  response="HTTP/1.1 $status_code\r\n"
  response+="$(date)\r\n"
  response+="Server: Simple Bash Server\r\n"
  response+="Content-Type: $content_type\r\n"
  response+="Content-Length: ${#body}\r\n"
  response+="Connection: close\r\n"
  response+="\r\n"
  response+="$body"

  # Send the response back to the client
  echo -n "$response"
}

# Main loop to listen for connections
while true; do
  nc -l -p "$PORT" 3<&0 | handle_request
done

# Usage: ./simple_http_server.sh [port] [error_page]
```