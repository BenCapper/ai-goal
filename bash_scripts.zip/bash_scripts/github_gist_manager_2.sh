# This script fetches a user's GitHub gists, sorts them by update date,
# provides details, downloads them locally, creates a summary report,
# and checks for updates since the last run.

# Usage: ./github_gist_manager.sh <github_username> <local_directory>

# Configuration
USERNAME="$1"
LOCAL_DIR="$2"
STATE_FILE="gist_state.txt"

# Check if username and local directory are provided
if [ -z "$USERNAME" ] || [ -z "$LOCAL_DIR" ]; then
  echo "Error: Please provide a GitHub username and a local directory."
  echo "Usage: ./github_gist_manager.sh <github_username> <local_directory>"
  exit 1
fi

# Create local directory if it doesn't exist
mkdir -p "$LOCAL_DIR"

# Function to fetch gists for a user
fetch_gists() {
  curl -s "https://api.github.com/users/$USERNAME/gists"
}

# Function to sort gists by updated_at date
sort_gists() {
  jq -s 'sort_by(.updated_at)'
}

# Function to extract gist details
extract_gist_details() {
  jq -r '.[] | {
    id: .id,
    description: .description,
    public: .public,
    updated_at: .updated_at,
    html_url: .html_url,
    files: (.files | keys | length),
    size: (.files | .[] | .size | add),
    language: (.files | .[] | .language),
    file_names: (.files | keys)
  }'
}

# Function to download a gist
download_gist() {
  local gist_id="$1"
  local file_names="$2"

  echo "Downloading gist: $gist_id"

  for file_name in $(echo "$file_names" | jq -r '.[]'); do
    local raw_url=$(curl -s "https://api.github.com/gists/$gist_id" | jq -r ".files.\"$file_name\".raw_url")
    if [ -n "$raw_url" ]; then
      curl -s "$raw_url" -o "$LOCAL_DIR/$gist_id-$file_name"
      echo "Downloaded: $LOCAL_DIR/$gist_id-$file_name"
    else
      echo "Error: Could not retrieve raw URL for file: $file_name in gist: $gist_id"
    fi
  done
}

# Function to generate the summary report
generate_summary_report() {
  echo "Gist Summary Report:"
  jq -r '.[] | "URL: " + .html_url + ", Description: " + (.description // "No description")' gist_data.json
}

# Function to check for updates
check_for_updates() {
  local new_gists=()
  local updated_gists=()

  # Create state file if it doesn't exist
  if [ ! -f "$STATE_FILE" ]; then
    touch "$STATE_FILE"
  fi

  # Load existing state
  if [ -s "$STATE_FILE" ]; then
    readarray -t old_state < "$STATE_FILE"
  else
    old_state=()
  fi
  
  for gist in $(jq -c '.[]' gist_data.json); do
      local gist_id=$(echo "$gist" | jq -r .id)
      local updated_at=$(echo "$gist" | jq -r .updated_at)
      
      local found=0
      for line in "${old_state[@]}"; do
          local old_gist_id=$(echo "$line" | cut -d' ' -f1)
          local old_updated_at=$(echo "$line" | cut -d' ' -f2)
          
          if [ "$gist_id" = "$old_gist_id" ]; then
              found=1
              if [ "$updated_at" != "$old_updated_at" ]; then
                  updated_gists+=("$gist")
                  echo "Gist $gist_id has been updated."
              fi
              break
          fi
      done
      
      if [ "$found" -eq 0 ]; then
          new_gists+=("$gist")
          echo "New gist found: $gist_id"
      fi
  done

  # Download new and updated gists
  for gist in "${new_gists[@]}"; do
    local gist_id=$(echo "$gist" | jq -r .id)
    local file_names=$(echo "$gist" | jq -r .file_names)
    download_gist "$gist_id" "$file_names"
  done

  for gist in "${updated_gists[@]}"; do
    local gist_id=$(echo "$gist" | jq -r .id)
    local file_names=$(echo "$gist" | jq -r .file_names)
    download_gist "$gist_id" "$file_names"
  done

  # Update state file
  > "$STATE_FILE" # Clear the file
  jq -r '.[] | .id + " " + .updated_at' gist_data.json >> "$STATE_FILE"
}

# Main execution flow
gists=$(fetch_gists)

# Check if the API request was successful
if [[ "$gists" == *"\"message\":\"Not Found\""* ]]; then
    echo "Error: User '$USERNAME' not found on GitHub or has no public gists."
    exit 1
fi

# Save all gist data to a file for processing.
echo "$gists" | sort_gists | extract_gist_details > gist_data.json

# Check for updates and download gists
check_for_updates

# Generate summary report
generate_summary_report

# Clean up temporary file
rm gist_data.json

echo "Gist management complete."
```