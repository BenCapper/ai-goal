# This script takes a list of filenames as input
# and calculates the SHA-384 hash of each file.

# Check if any filenames were provided
if [ $# -eq 0 ]; then
  echo "Usage: $0 <file1> <file2> ..."
  exit 1
fi

# Loop through the provided filenames
for file in "$@"; do
  # Check if the file exists
  if [ ! -f "$file" ]; then
    echo "Error: File '$file' not found."
    continue  # Skip to the next file
  fi

  # Calculate the SHA-384 hash using openssl
  sha384_hash=$(openssl dgst -sha384 "$file" | awk '{print $2}')

  # Print the filename and its SHA-384 hash
  echo "SHA384 ($file) = $sha384_hash"
done

exit 0
```