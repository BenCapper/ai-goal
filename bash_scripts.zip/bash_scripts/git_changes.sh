# This script uses git to show the changes introduced by a range of commits,
# including the author, date, commit hash, and the number of added and deleted
# lines for each change.

# Check if the commit range is provided as an argument
if [ $# -ne 1 ]; then
  echo "Usage: $0 <commit_range>"
  echo "Example: $0 main..develop"
  exit 1
fi

commit_range=$1

# Iterate through the commits in the specified range
git log --pretty=format:"%h %an %ad" --shortstat "$commit_range" | \
while read -r line; do
  # Extract commit hash, author, and date
  commit_hash=$(echo "$line" | awk '{print $1}')
  author=$(echo "$line" | awk '{print $2}')
  date=$(echo "$line" | awk '{print $3, $4, $5}') # Capture date format

  # Print commit information
  echo "Commit: $commit_hash"
  echo "Author: $author"
  echo "Date: $date"

  # Read the next line containing the shortstat information
  read -r shortstat_line

  # Extract added and deleted lines
  added_lines=$(echo "$shortstat_line" | grep -oP '\d+(?= insertion)')
  deleted_lines=$(echo "$shortstat_line" | grep -oP '\d+(?= deletion)')

  # Handle cases where there are no insertions or deletions
  if [ -z "$added_lines" ]; then
    added_lines=0
  fi

  if [ -z "$deleted_lines" ]; then
    deleted_lines=0
  fi

  # Print added and deleted lines information
  echo "Added lines: $added_lines"
  echo "Deleted lines: $deleted_lines"
  echo "---------------------------------"
done
```