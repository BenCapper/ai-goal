# This script takes a list of CVE IDs as input and retrieves information about them
# from a vulnerability database using the NIST National Vulnerability Database (NVD) API.
# It requires curl and jq to be installed.

# Function to retrieve CVE details from the NVD API
get_cve_details() {
  local cve_id=$1
  local api_url="https://services.nvd.nist.gov/rest/json/cves/2.0?cveId=$cve_id"

  # Check if API_KEY exists as an environment variable
  if [ -z "$API_KEY" ]; then
    echo "Error: API_KEY environment variable not set. Please set it before running the script."
    exit 1
  fi

  # Call the NVD API using curl
  local response=$(curl -s -H "apiKey:$API_KEY" "$api_url")

  # Check if the API request was successful
  if [[ "$response" == *"HTTP Too Many Requests"* ]]; then
        echo "Error: Rate limit exceeded.  Please wait before making more requests or increase the delay."
        return 1
  fi

  # Extract relevant information using jq
  local description=$(echo "$response" | jq -r '.vulnerabilities[0].cve.descriptions[0].value')
  local cvssv3_baseScore=$(echo "$response" | jq -r '.vulnerabilities[0].cve.metrics.cvssMetricV31[0].cvssData.baseScore')
  local cvssv3_severity=$(echo "$response" | jq -r '.vulnerabilities[0].cve.metrics.cvssMetricV31[0].cvssData.severity')
  local published=$(echo "$response" | jq -r '.vulnerabilities[0].cve.published')
  local modified=$(echo "$response" | jq -r '.vulnerabilities[0].cve.lastModified')

  # Print the information
  echo "CVE ID: $cve_id"
  echo "Description: $description"
  echo "CVSS v3.1 Base Score: $cvssv3_baseScore"
  echo "CVSS v3.1 Severity: $cvssv3_severity"
  echo "Published: $published"
  echo "Last Modified: $modified"
  echo "------------------------------------"
}

# Check if any CVE IDs were provided as arguments
if [ $# -eq 0 ]; then
  echo "Usage: $0 CVE_ID1 CVE_ID2 ..."
  exit 1
fi

# Iterate through the provided CVE IDs
for cve_id in "$@"; do
  get_cve_details "$cve_id"
done

exit 0
```