# This script executes an Ansible playbook and checks the number of unreachable hosts.
# It fails the script if the number of unreachable hosts exceeds a threshold.

#!/bin/bash

# Set variables
PLAYBOOK="your_playbook.yml"  # Replace with your playbook name
MAX_UNREACHABLE=0          # Maximum allowed unreachable hosts

# Execute Ansible playbook and capture output
OUTPUT=$(ansible-playbook "$PLAYBOOK" 2>&1)

# Check the exit code of ansible-playbook
EXIT_CODE=$?

# Check if the playbook failed due to a general error
if [ $EXIT_CODE -ne 0 ]; then
  echo "Ansible playbook failed with exit code: $EXIT_CODE"
  echo "$OUTPUT"
  exit 1
fi

# Extract the number of unreachable hosts from the output
UNREACHABLE=$(echo "$OUTPUT" | grep "unreachable=" | awk '{print $4}' | cut -d '=' -f 2)

# Check if unreachable count is available
if [ -z "$UNREACHABLE" ]; then
  UNREACHABLE=0
fi

# Check if the number of unreachable hosts exceeds the threshold
if [ "$UNREACHABLE" -gt "$MAX_UNREACHABLE" ]; then
  echo "ERROR: Number of unreachable hosts ($UNREACHABLE) exceeds the maximum allowed ($MAX_UNREACHABLE)."
  echo "$OUTPUT"
  exit 1
else
  echo "Playbook executed successfully. Unreachable hosts: $UNREACHABLE"
  exit 0
fi
```