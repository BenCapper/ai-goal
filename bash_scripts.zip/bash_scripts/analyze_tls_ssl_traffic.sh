# This script demonstrates how to use Wireshark to analyze TLS/SSL traffic.
# It captures traffic and then applies a display filter to focus on TLS/SSL.
# It also shows how to decrypt TLS traffic if you have the necessary keys.

# Prerequisites:
# 1. Wireshark must be installed (sudo apt-get install wireshark or similar).
# 2. You might need to configure Wireshark to run as a non-root user to capture traffic.
# 3. You might need the SSLKEYLOGFILE environment variable set to decrypt traffic.

# Capture traffic on a specific interface (e.g., eth0)
# and apply a display filter to show only TLS/SSL traffic.

# Note: Replace 'eth0' with the appropriate interface name for your system.

# Capture traffic and display it directly in Wireshark.
# This is the basic method.  You'll then use Wireshark's GUI to analyze the traffic.
tshark -i eth0 -f "tcp port 443"

# Optionally, write the captured traffic to a file for later analysis.
# tshark -i eth0 -f "tcp port 443" -w capture.pcap

# Decrypt TLS traffic if you have the SSL keys.
# First, ensure that the SSLKEYLOGFILE environment variable is set.
# For example:
# export SSLKEYLOGFILE=/tmp/sslkeys.log

# Then, tell Wireshark to use the keylog file:
# Edit -> Preferences -> Protocols -> TLS -> (Pre)-Master-Secret log filename

# Alternatively, use tshark with the keylog file:
# tshark -o tls.keylog_file:/tmp/sslkeys.log -r capture.pcap

# Other useful display filters:
# tls.handshake.type == 1  (Client Hello)
# tls.handshake.type == 2  (Server Hello)
# tls.handshake.type == 11 (Certificate)
# tls.alert_message.desc == 40 (Handshake Failure)


# File Usage:
# chmod +x analyze_tls_ssl_traffic.sh
# ./analyze_tls_ssl_traffic.sh
```