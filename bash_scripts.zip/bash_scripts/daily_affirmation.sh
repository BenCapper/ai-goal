# This script generates a random daily affirmation related to writing
# maintainable code.  It emphasizes the importance of clear, readable,
# and well-documented code for long-term project success.

affirmations=(
  "Write code as if the next person maintaining it is a violent psychopath who knows where you live."
  "Maintainable code is an act of kindness to your future self and your colleagues."
  "Clarity is the key: write code that is easy to understand and reason about."
  "Strive for simplicity: complex code is harder to maintain and debug."
  "Documentation is your friend: well-documented code saves time and frustration."
  "Refactor relentlessly: keep your codebase clean and organized."
  "Write tests: ensure your code works as expected and is easy to modify."
  "Favor readability over cleverness: the goal is to understand, not to impress."
  "Consider the future: write code that can be easily adapted to changing requirements."
  "Invest in maintainability: it pays off in the long run."
  "Make your intentions clear: Use descriptive names for variables, functions, and classes."
  "Consistent style: Following a consistent coding style improves readability and reduces errors."
  "Embrace modularity: Break down large tasks into smaller, reusable components."
)

# Get a random index within the array bounds.
index=$(( RANDOM % ${#affirmations[@]} ))

# Print the randomly selected affirmation.
echo "${affirmations[$index]}"
```