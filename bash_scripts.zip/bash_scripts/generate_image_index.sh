# This script generates a simple HTML index page for a directory of images.
# It lists all image files in the current directory and creates links to display them.

# Usage: ./generate_image_index.sh

# Set the HTML file name
HTML_FILE="index.html"

# Start the HTML document
echo "<!DOCTYPE html>" > "$HTML_FILE"
echo "<html>" >> "$HTML_FILE"
echo "<head>" >> "$HTML_FILE"
echo "<title>Image Index</title>" >> "$HTML_FILE"
echo "</head>" >> "$HTML_FILE"
echo "<body>" >> "$HTML_FILE"
echo "<h1>Image Index</h1>" >> "$HTML_FILE"

# List all image files in the current directory
for image in *.{jpg,jpeg,png,gif}; do
  if [ -f "$image" ]; then
    echo "<a href=\"$image\"><img src=\"$image\" alt=\"$image\" width=\"200\"></a>" >> "$HTML_FILE"
    echo "<br>" >> "$HTML_FILE"
  fi
done

# End the HTML document
echo "</body>" >> "$HTML_FILE"
echo "</html>" >> "$HTML_FILE"

echo "HTML index page created: $HTML_FILE"
```