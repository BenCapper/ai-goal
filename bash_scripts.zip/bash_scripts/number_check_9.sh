# This script iterates through a sequence of numbers using a for loop.
# It checks if each number is not equal to 8 using an if statement.
# If the condition is met, it prints the number followed by "is not equal to 8".

# Usage: ./number_check.sh

for i in {1..10}; do
  if [[ "$i" -ne 8 ]]; then
    echo "$i is not equal to 8"
  fi
done
```