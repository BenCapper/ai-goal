# This script demonstrates the use of the sed utility with the 'n' command
# to suppress default output and selectively print lines.
# The 'n' command reads the next line of input, replacing the current line
# in the pattern space. By default, sed prints every line. The '-n' option
# suppresses this default behavior.  Combined with 'p' command, we can print
# only the lines we want.

# Create a sample input file
cat > input.txt <<EOF
Line 1
Line 2
Line 3
Line 4
Line 5
EOF

# Print every other line using 'n' and 'p'
sed -n 'n;p' input.txt

# Cleanup
rm input.txt

# Usage: ./sed_n_command.sh
```