# This script checks if a given package is installed using different package managers.
# It iterates through yum, apt-get, and dnf, and uses the appropriate command to check installation.

# Usage: ./check_package.sh <package_name>

# Declare the package name variable
PACKAGE_NAME=$1

# Check if package name is provided
if [ -z "$PACKAGE_NAME" ]; then
  echo "Error: Please provide a package name as an argument."
  echo "Usage: ./check_package.sh <package_name>"
  exit 1
fi

# Iterate through package managers
for PKG_MGR in yum apt-get dnf; do
  echo "Checking for package '$PACKAGE_NAME' using '$PKG_MGR'..."

  if [[ "$PKG_MGR" == "yum" ]]; then
    # Check if the package is installed using yum
    if yum list installed "$PACKAGE_NAME" &> /dev/null; then
      echo "Package '$PACKAGE_NAME' is installed via yum."
    else
      echo "Package '$PACKAGE_NAME' is NOT installed via yum."
    fi
  elif [[ "$PKG_MGR" == "apt-get" ]]; then
    # Check if the package is installed using apt-get
    if dpkg -s "$PACKAGE_NAME" &> /dev/null; then
      echo "Package '$PACKAGE_NAME' is installed via apt-get."
    else
      echo "Package '$PACKAGE_NAME' is NOT installed via apt-get."
    fi
  elif [[ "$PKG_MGR" == "dnf" ]]; then
    # Check if the package is installed using dnf
    if dnf list installed "$PACKAGE_NAME" &> /dev/null; then
      echo "Package '$PACKAGE_NAME' is installed via dnf."
    else
      echo "Package '$PACKAGE_NAME' is NOT installed via dnf."
    fi
  else
    echo "Unsupported package manager: $PKG_MGR"
  fi
done
```