# This script checks if two input numbers and their concatenation are lucky numbers.
# A lucky number contains only the digits 4 and 7.

# Function to check if a number is a lucky number
is_lucky() {
  local num=$1
  if [[ "$num" =~ ^[47]+$ ]]; then
    return 0 # True
  else
    return 1 # False
  fi
}

# Read two numbers from the user
read -p "Enter the first number: " N1_LUCKY_CHK
read -p "Enter the second number: " N2_LUCKY_CHK

# Check if the inputs are valid numbers
if ! [[ "$N1_LUCKY_CHK" =~ ^[0-9]+$ ]] || ! [[ "$N2_LUCKY_CHK" =~ ^[0-9]+$ ]]; then
  echo "Error: Please enter valid numerical strings."
  exit 1
fi

# Check if both numbers are lucky and if their concatenation is lucky
if is_lucky "$N1_LUCKY_CHK" && is_lucky "$N2_LUCKY_CHK" && is_lucky "$N1_LUCKY_CHK$N2_LUCKY_CHK"; then
  echo "Both numbers and their concatenation are lucky numbers."
else
  echo "At least one of the numbers or their concatenation is not a lucky number."
fi

# Usage: ./lucky_number_checker.sh
```