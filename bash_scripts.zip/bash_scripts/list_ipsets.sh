# This script lists all IP sets using firewall-cmd.
# It retrieves the names of all IP sets configured in firewalld.

# firewall-cmd --get-ipset-names
ipset_names=$(firewall-cmd --get-ipset-names)

# Check if any IP sets were found.
if [ -n "$ipset_names" ]; then
  # Print the IP set names.
  echo "$ipset_names"
else
  echo "No IP sets found."
fi

# Usage: ./list_ipsets.sh
```