# This script registers a new ECS task definition using the AWS CLI.
# It assumes that you have the AWS CLI installed and configured.
# It takes the task definition JSON file as an argument.
# usage: ./register_ecs_task_definition.sh task_definition.json

# Check if the task definition file is provided as an argument.
if [ $# -ne 1 ]; then
  echo "Usage: ./register_ecs_task_definition.sh <task_definition_file.json>"
  exit 1
fi

TASK_DEFINITION_FILE="$1"

# Check if the task definition file exists.
if [ ! -f "$TASK_DEFINITION_FILE" ]; then
  echo "Error: Task definition file '$TASK_DEFINITION_FILE' not found."
  exit 1
fi

# Register the task definition using the AWS CLI.
echo "Registering task definition from '$TASK_DEFINITION_FILE'..."
aws ecs register-task-definition --cli-input-json file://"$TASK_DEFINITION_FILE"

# Check the exit code of the AWS CLI command.
if [ $? -ne 0 ]; then
  echo "Error: Failed to register task definition."
  exit 1
else
  echo "Task definition registered successfully."
fi

exit 0
```