# This script reads a log file line by line.
# It checks if each line contains the word "error".
# If a line contains the word "error", it prints the line to the standard output.

# Usage: ./error_log_filter.sh logfile.log

LOG_FILE="$1"

if [ -z "$LOG_FILE" ]; then
  echo "Error: Please provide a log file as an argument."
  exit 1
fi

if [ ! -f "$LOG_FILE" ]; then
  echo "Error: Log file '$LOG_FILE' not found."
  exit 1
fi

while IFS= read -r line; do
  if grep -q "error" <<< "$line"; then
    echo "$line"
  fi
done < "$LOG_FILE"

# ./error_log_filter.sh mylog.log
```