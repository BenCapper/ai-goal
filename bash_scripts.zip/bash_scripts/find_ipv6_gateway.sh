# This script iterates through the output of `ip -6 route show`,
# stores each line in the IPV6_ROUTE_INFO variable, and then
# uses awk with an if statement to find the default IPv6 gateway.

# Usage: ./find_ipv6_gateway.sh

IPV6_ROUTE_INFO=$(ip -6 route show)

for line in $IPV6_ROUTE_INFO; do
  if [[ "$line" == "default" ]]; then
    NEXT_HOP=$(echo "$IPV6_ROUTE_INFO" | awk '$1 == "default" {print $3}')
    echo "Default IPv6 Gateway: $NEXT_HOP"
    exit 0
  fi
done

echo "No default IPv6 gateway found."
exit 1
```