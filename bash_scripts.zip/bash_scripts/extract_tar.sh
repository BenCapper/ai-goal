# This script extracts a tar archive to a specified directory.
# It takes two arguments:
# 1. The path to the tar archive.
# 2. The directory where the files should be extracted.

# Check if the correct number of arguments is provided
if [ $# -ne 2 ]; then
  echo "Usage: $0 <tar_archive> <extraction_directory>"
  exit 1
fi

# Assign arguments to variables
tar_archive="$1"
extraction_directory="$2"

# Check if the tar archive exists
if [ ! -f "$tar_archive" ]; then
  echo "Error: Tar archive '$tar_archive' not found."
  exit 1
fi

# Check if the extraction directory exists
if [ ! -d "$extraction_directory" ]; then
  echo "Error: Extraction directory '$extraction_directory' not found."
  exit 1
fi

# Extract the tar archive to the specified directory
tar -xf "$tar_archive" -C "$extraction_directory"

# Check the exit status of the tar command
if [ $? -eq 0 ]; then
  echo "Successfully extracted '$tar_archive' to '$extraction_directory'."
else
  echo "Error: Failed to extract '$tar_archive' to '$extraction_directory'."
  exit 1
fi

exit 0
```