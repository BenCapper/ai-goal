# This script retrieves details of a specific GitLab runner using the GitLab API.
# It requires the GitLab runner ID and a personal access token with API access.

# Usage: ./get_gitlab_runner.sh <runner_id> <gitlab_url> <private_token>

# Set variables
RUNNER_ID=$1
GITLAB_URL=$2
PRIVATE_TOKEN=$3

# Check if the required arguments are provided
if [ -z "$RUNNER_ID" ] || [ -z "$GITLAB_URL" ] || [ -z "$PRIVATE_TOKEN" ]; then
  echo "Usage: ./get_gitlab_runner.sh <runner_id> <gitlab_url> <private_token>"
  exit 1
fi

# Construct the API endpoint URL
API_ENDPOINT="$GITLAB_URL/api/v4/runners/$RUNNER_ID"

# Make the API request
RESPONSE=$(curl --header "PRIVATE-TOKEN: $PRIVATE_TOKEN" "$API_ENDPOINT")

# Check if the request was successful
if [ $? -eq 0 ]; then
  # Print the runner details
  echo "$RESPONSE"
else
  echo "Error: Failed to retrieve runner details."
  exit 1
fi
```