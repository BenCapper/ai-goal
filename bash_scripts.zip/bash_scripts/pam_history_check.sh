# This script analyzes the system's PAM configuration files in /etc/pam.d/
# to determine if password history enforcement is enabled and configured.
# It searches for pam_unix.so or pam_pwquality.so modules with specific options
# related to remember or password history.

# Usage: ./pam_history_check.sh

# Define the directory containing PAM configuration files
PAM_DIR="/etc/pam.d"

# Function to check a PAM configuration file for password history settings
check_pam_file() {
  local file="$1"

  echo "Checking file: $file"

  # Check for pam_unix.so with the 'remember' option
  if grep -q "pam_unix.so.*remember=[1-9][0-9]*" "$file"; then
    echo "  - pam_unix.so: Password history enforcement found (remember option)."
    grep "pam_unix.so.*remember=[1-9][0-9]*" "$file"
  fi

  # Check for pam_pwquality.so with the 'remember' option
  if grep -q "pam_pwquality.so.*remember=[1-9][0-9]*" "$file"; then
      echo "  - pam_pwquality.so: Password history enforcement found (remember option)."
      grep "pam_pwquality.so.*remember=[1-9][0-9]*" "$file"
  fi

  #Check for pam_pwquality.so with the 'enforce_for_root' option
  if grep -q "pam_pwquality.so.*enforce_for_root" "$file"; then
      echo "  - pam_pwquality.so: enforce_for_root flag found."
      grep "pam_pwquality.so.*enforce_for_root" "$file"
  fi

  #If no history enforcement is set
  if ! grep -q "pam_unix.so.*remember=[1-9][0-9]*" "$file" && ! grep -q "pam_pwquality.so.*remember=[1-9][0-9]*" "$file"; then
    echo "  - No password history enforcement found."
  fi

  echo ""
}

# Loop through each file in the PAM configuration directory
for file in "$PAM_DIR"/*; do
  if [ -f "$file" ]; then
    check_pam_file "$file"
  fi
done

echo "Analysis complete."
```