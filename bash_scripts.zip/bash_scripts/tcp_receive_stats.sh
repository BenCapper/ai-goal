# This script retrieves TCP receive statistics using either netstat or ss commands.
# It attempts to use 'netstat -s | grep "TCP segments received"' first.
# If 'netstat' fails (exits with a non-zero status), it falls back to using 'ss -s | grep "TCP"'.
# The output is then piped to awk to extract the 4th field (TCP segments received value).

# Usage: ./tcp_receive_stats.sh

if netstat -s | grep "TCP segments received" > /dev/null 2>&1; then
  netstat -s | grep "TCP segments received" | awk '{print $4}'
else
  ss -s | grep "TCP" | awk '{print $1}'
fi
```