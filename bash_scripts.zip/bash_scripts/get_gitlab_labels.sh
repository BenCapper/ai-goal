# This script uses the GitLab API to list all labels for a given project.
# It requires the project ID and a personal access token with API access.

# Usage: ./get_gitlab_labels.sh <project_id> <private_token>

# Check if the correct number of arguments is provided
if [ $# -ne 2 ]; then
  echo "Usage: ./get_gitlab_labels.sh <project_id> <private_token>"
  exit 1
fi

# Assign arguments to variables
PROJECT_ID="$1"
PRIVATE_TOKEN="$2"

# GitLab API endpoint for listing project labels
API_ENDPOINT="https://gitlab.com/api/v4/projects/$PROJECT_ID/labels"

# Function to fetch and parse the labels
get_labels() {
  curl --header "PRIVATE-TOKEN: $PRIVATE_TOKEN" "$API_ENDPOINT" | jq -r '.[].name'
}

# Call the function and print the labels
get_labels

# example usage: ./get_gitlab_labels.sh 12345 my_private_token
```