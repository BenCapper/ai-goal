# This script simulates a basic dice rolling program.
# It allows the user to specify the number of dice to roll
# and the number of sides each die has.

# Usage: ./dice_roller.sh <number_of_dice> <number_of_sides>

# Function to roll a single die with a given number of sides
roll_die() {
  local sides=$1
  echo $((RANDOM % sides + 1))
}

# Main script logic
if [ $# -ne 2 ]; then
  echo "Usage: ./dice_roller.sh <number_of_dice> <number_of_sides>"
  exit 1
fi

num_dice=$1
num_sides=$2

if ! [[ "$num_dice" =~ ^[0-9]+$ ]] || ! [[ "$num_sides" =~ ^[0-9]+$ ]]; then
  echo "Error: Number of dice and number of sides must be positive integers."
  exit 1
fi

if [ "$num_dice" -le 0 ] || [ "$num_sides" -le 0 ]; then
  echo "Error: Number of dice and number of sides must be greater than 0."
  exit 1
fi

echo "Rolling $num_dice dice with $num_sides sides each:"

total=0
for i in $(seq 1 $num_dice); do
  result=$(roll_die $num_sides)
  echo "Die $i: $result"
  total=$((total + result))
done

echo "Total: $total"
```