# This script uses curl to interact with an API that requires a specific Pragma header.
# It sends a GET request to the specified API endpoint with the required Pragma header.
# It then prints the response from the API to standard output.

#!/bin/bash

# Set the API endpoint URL
API_URL="https://example.com/api/resource"

# Set the Pragma header value
PRAGMA_VALUE="no-cache"

# Send the request using curl with the Pragma header
RESPONSE=$(curl -s -H "Pragma: $PRAGMA_VALUE" "$API_URL")

# Check if the curl command was successful.
if [ $? -ne 0 ]; then
  echo "Error: curl command failed." >&2
  exit 1
fi


# Print the response to standard output
echo "$RESPONSE"

exit 0
```