# This script takes two numerical strings as input, calculates the sum of their proper divisors,
# and checks if they are amicable numbers.

# Function to calculate the sum of proper divisors of a number
sum_of_proper_divisors() {
  local num=$1
  local sum=1

  for ((i=2; i<=num/2; i++)); do
    if (( num % i == 0 )); then
      sum=$((sum + i))
    fi
  done
  echo $sum
}

# Read the two numbers from command line arguments
NUM_A_AMICABLE=$1
NUM_B_AMICABLE=$2

# Check if both numbers are provided
if [ -z "$NUM_A_AMICABLE" ] || [ -z "$NUM_B_AMICABLE" ]; then
  echo "Error: Please provide two numbers as arguments."
  exit 1
fi

# Check if the inputs are valid integers
if ! [[ "$NUM_A_AMICABLE" =~ ^[0-9]+$ ]] || ! [[ "$NUM_B_AMICABLE" =~ ^[0-9]+$ ]]; then
  echo "Error: Both inputs must be integers."
  exit 1
fi

# Calculate the sum of proper divisors for each number
SUM_A=$(sum_of_proper_divisors "$NUM_A_AMICABLE")
SUM_B=$(sum_of_proper_divisors "$NUM_B_AMICABLE")

# Check if the numbers are amicable
if (( NUM_A_AMICABLE == SUM_B )) && (( NUM_B_AMICABLE == SUM_A )) && (( NUM_A_AMICABLE != NUM_B_AMICABLE )); then
  echo "$NUM_A_AMICABLE and $NUM_B_AMICABLE are amicable numbers."
else
  echo "$NUM_A_AMICABLE and $NUM_B_AMICABLE are not amicable numbers."
fi

# Usage: ./amicable_numbers.sh <number1> <number2>
```