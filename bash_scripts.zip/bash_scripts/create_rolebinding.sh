# This script creates a new role binding with specific subjects and a specific role name in a specific namespace.
# It also adds multiple annotations and labels with specific values and sets a specific user name and group name in the subjects.

#!/bin/bash

# Define variables
BINDING_NAME="my-role-binding"
ROLE_NAME="my-role"
NAMESPACE="my-namespace"
USER_NAME="testuser"
GROUP_NAME="testgroup"
ANNOTATION_KEY1="annotation.key1"
ANNOTATION_VALUE1="annotationvalue1"
ANNOTATION_KEY2="annotation.key2"
ANNOTATION_VALUE2="annotationvalue2"
LABEL_KEY1="label.key1"
LABEL_VALUE1="labelvalue1"
LABEL_KEY2="label.key2"
LABEL_VALUE2="labelvalue2"

# Create the role binding
oc create rolebinding "$BINDING_NAME" --role="$ROLE_NAME" --namespace="$NAMESPACE" --user="$USER_NAME" --group="$GROUP_NAME"

# Annotate the role binding
oc annotate rolebinding "$BINDING_NAME" "$ANNOTATION_KEY1"="$ANNOTATION_VALUE1" "$ANNOTATION_KEY2"="$ANNOTATION_VALUE2" --namespace="$NAMESPACE" --overwrite

# Label the role binding
oc label rolebinding "$BINDING_NAME" "$LABEL_KEY1"="$LABEL_VALUE1" "$LABEL_KEY2"="$LABEL_VALUE2" --namespace="$NAMESPACE" --overwrite

echo "Role binding '$BINDING_NAME' created, annotated, and labeled in namespace '$NAMESPACE'."
```