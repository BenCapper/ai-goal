# This script sets the system time to a specific date and time.
# It requires root privileges to execute.

# Set the desired date and time
DATE="2025-05-06"
TIME="10:00:00"
DATETIME="$DATE $TIME"

# Set the system time using the date command
# The --set option requires root privileges
sudo date --set "$DATETIME"

# Optional: Synchronize the hardware clock with the system clock
sudo hwclock --systohc

echo "System time set to: $DATETIME"
```