# This script automates the process of creating a Git bundle containing a specific branch and its history.
# It includes merge commits, verifies the integrity of the bundle, and signs it with a specified GPG key.
# It also adds a custom comment to the signature.

# Usage: ./create_signed_git_bundle.sh <branch_name> <bundle_name> <gpg_key_id> "<comment>"

# Check if the correct number of arguments are provided
if [ $# -ne 4 ]; then
  echo "Usage: ./create_signed_git_bundle.sh <branch_name> <bundle_name> <gpg_key_id> \"<comment>\""
  exit 1
fi

BRANCH_NAME="$1"
BUNDLE_NAME="$2"
GPG_KEY_ID="$3"
COMMENT="$4"

# Create the Git bundle, including all refs needed for the specified branch
echo "Creating Git bundle for branch: $BRANCH_NAME"
git bundle create "$BUNDLE_NAME" "$BRANCH_NAME" --all

# Verify the integrity of the bundle
echo "Verifying the integrity of the Git bundle..."
git bundle verify "$BUNDLE_NAME"

if [ $? -ne 0 ]; then
  echo "Error: Git bundle verification failed."
  rm -f "$BUNDLE_NAME"
  exit 1
fi

# Sign the Git bundle with the specified GPG key and comment
echo "Signing the Git bundle with GPG key ID: $GPG_KEY_ID"
gpg --armor --detach-sig --default-key "$GPG_KEY_ID" --comment "$COMMENT" "$BUNDLE_NAME"

if [ $? -ne 0 ]; then
  echo "Error: GPG signing failed."
  rm -f "$BUNDLE_NAME"
  exit 1
fi

echo "Git bundle created and signed successfully."
echo "Bundle: $BUNDLE_NAME"
echo "Signature: $BUNDLE_NAME.asc"
```