# This script takes a list of animal names as input and retrieves their classification information from a zoological database.
# It utilizes the Animal Diversity Web API (ADW) to fetch the classification details.
#
# Usage: ./animal_classification.sh animal1 animal2 animal3 ...

# Function to get animal classification from ADW API
get_animal_classification() {
  animal_name="$1"
  
  # Use curl to fetch data from the ADW API.  Adjust url to prevent errors.
  api_url="https://animaldiversity.org/api/2/hierarchy/classification?format=json&animal=${animal_name}"

  # Attempt to fetch the data up to 3 times, with a delay between retries.
  for i in {1..3}; do
    data=$(curl -s "$api_url")
    if [[ $? -eq 0 ]]; then
      break  # Exit the loop if the curl command was successful
    else
      echo "Attempt $i failed. Retrying in 2 seconds..."
      sleep 2
    fi
  done
  
  # Check if curl was successful in retrieving data.
  if [[ $? -ne 0 ]]; then
    echo "Error: Failed to retrieve data for $animal_name after multiple attempts."
    return 1  # Indicate failure
  fi

  # Parse the JSON output and extract the classification.  Handle null results properly.
  classification=$(echo "$data" | jq -r '.[0] // "" | .classification // "" | .[] | .rank + ": " + .name')

  # Check if classification is empty.  If so, the Animal name was probably invalid.
  if [[ -z "$classification" ]]; then
      echo "Classification not found for: $animal_name.  Possible spelling error or invalid animal name."
      return 1 # Indicate failure
  fi
  
  echo "Classification for $animal_name:"
  echo "$classification"
  return 0
}

# Main script execution
if [[ $# -eq 0 ]]; then
  echo "Usage: ./animal_classification.sh animal1 animal2 animal3 ..."
  exit 1
fi

for animal in "$@"; do
  get_animal_classification "$animal"
  echo "" # Add a newline for readability between animals
done

exit 0
```