# This script checks if a TCP process is listening on the loopback interface (127.0.0.1 or ::1) on a specified port.

# Declare the port to check.
PORT_TO_CHECK_TCP_LISTEN_LOCAL_ONLY=8080

# Check if a process is listening on the loopback interface using netstat.
if netstat -ant | grep -q "tcp.*127.0.0.1:$PORT_TO_CHECK_TCP_LISTEN_LOCAL_ONLY.*LISTEN"; then
  echo "TCP process is listening on 127.0.0.1:$PORT_TO_CHECK_TCP_LISTEN_LOCAL_ONLY"
# Check if a process is listening on the IPv6 loopback interface using ss.
elif ss -ant | grep -q "tcp.*\[::1]:$PORT_TO_CHECK_TCP_LISTEN_LOCAL_ONLY.*LISTEN"; then
  echo "TCP process is listening on [::1]:$PORT_TO_CHECK_TCP_LISTEN_LOCAL_ONLY"
else
  echo "No TCP process is listening on the loopback interface (127.0.0.1 or ::1) on port $PORT_TO_CHECK_TCP_LISTEN_LOCAL_ONLY"
fi

# Usage: ./check_loopback_port.sh
```