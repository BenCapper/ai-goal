# This script uses df -h to display disk space usage,
# then filters out the header line,
# and finally sorts the remaining lines by size in reverse numerical order.

# df -h: Display disk space usage in human-readable format
# grep -v "^Filesystem": Exclude lines starting with "Filesystem" (the header)
# sort -k 3 -nr: Sort numerically in reverse order using the 3rd column (size)

df -h | grep -v "^Filesystem" | sort -k 3 -nr

# Usage: ./sort_partitions.sh
```