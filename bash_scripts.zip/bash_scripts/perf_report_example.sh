# This script demonstrates how to use the 'perf report' command
# to analyze performance data recorded using 'perf record'.
# It provides examples of generating different types of reports,
# including reports showing hotspots, symbol information, and call graphs.

# First, assuming you have a perf.data file from a previous perf record execution.
# If not, record some data first:
# perf record -g ./your_program

# Example 1: Generate a basic report showing the most time-consuming functions.
perf report

# Example 2: Generate a report showing symbols, use --stdio to see output in terminal
perf report --stdio

# Example 3: Generate a report with call graph information (requires -g option during perf record).
# This helps identify which functions call the most time-consuming functions.
perf report --call-graph graph,0.5

# Example 4: Generate a report and specify the input perf.data file.
# Useful if you have multiple perf.data files.
perf report -i perf.data

# Example 5: Generate a report and specify the output file.
perf report -o report.txt

# Example 6: Generate a report filtering by process id.
# perf report -p <pid>

# Example 7: Generate a report filtering by comm name.
# perf report -c <comm>

# Example 8: Generate a report with source line annotation.
# perf report --stdio --source

# Example 9: Show information about a specific event.
# perf report --event cycles

# Example 10: Analyze a remote recording file.
# perf report -i /path/to/perf.data.remote --vmlinux /path/to/vmlinux

# Example 11: Generate a report for specific dso
# perf report --dso your_dso_name

# Example 12: Generate a report for specific symbol
# perf report --symbol your_symbol_name

# Note: 'perf report' offers many more options.  Consult the 'perf report --help'
# or 'man perf-report' for complete documentation.

# Usage: ./perf_report_example.sh
```