# This script takes a file as input and uses uniq to display only the unique lines in the file.
# It assumes the input file is sorted.

# Check if a file is provided as an argument
if [ $# -eq 0 ]; then
  echo "Usage: $0 <file>"
  exit 1
fi

# Get the filename from the command-line argument
filename=$1

# Check if the file exists
if [ ! -f "$filename" ]; then
  echo "Error: File '$filename' not found."
  exit 1
fi

# Use uniq to display the unique lines in the file
uniq "$filename"
```