# This script automates the creation and configuration of a network bridge
# with a specified STP priority.  It verifies the required packages are installed,
# creates the bridge interface, adds interfaces to it, sets the STP priority,
# and brings the bridge interface up.

# Usage: sudo ./bridge_setup.sh <bridge_name> <interface1> <interface2> ... <stp_priority>
# Example: sudo ./bridge_setup.sh br0 eth0 wlan0 4096

# Check if the user has root privileges
if [[ $EUID -ne 0 ]]; then
  echo "This script must be run as root."
  exit 1
fi

# Function to check if a command exists
command_exists() {
  command -v "$1" >/dev/null 2>&1
}

# Check if bridge-utils is installed
if ! command_exists brctl; then
  echo "bridge-utils is not installed.  Attempting to install..."
  apt-get update
  apt-get install -y bridge-utils
  if ! command_exists brctl; then
    echo "Failed to install bridge-utils.  Please install it manually."
    exit 1
  fi
  echo "bridge-utils installed successfully."
fi

# Check number of arguments
if [[ $# -lt 4 ]]; then
  echo "Usage: sudo ./bridge_setup.sh <bridge_name> <interface1> <interface2> ... <stp_priority>"
  echo "Example: sudo ./bridge_setup.sh br0 eth0 wlan0 4096"
  exit 1
fi

BRIDGE_NAME=$1
shift
STP_PRIORITY=${!#} # Last argument is STP priority
shift # remove stp_priority from arguments.  We can use the other arguments as the list of interfaces.

# Check if the bridge already exists
if ip link show "$BRIDGE_NAME" > /dev/null 2>&1; then
  echo "Bridge $BRIDGE_NAME already exists."
  exit 1
fi

# Create the bridge interface
brctl addbr "$BRIDGE_NAME"

# Add interfaces to the bridge
for interface in "$@"; do
  ip link set dev "$interface" down
  brctl addif "$BRIDGE_NAME" "$interface"
  ip link set dev "$interface" up
done

# Set STP priority
brctl stp "$BRIDGE_NAME" on
brctl setpriority "$BRIDGE_NAME" "$STP_PRIORITY"

# Bring up the bridge interface
ip link set dev "$BRIDGE_NAME" up

# Configure IP address (Optional - DHCP is assumed here)
# dhclient "$BRIDGE_NAME"

echo "Bridge $BRIDGE_NAME created and configured successfully."
echo "Interfaces added: $@"
echo "STP Priority set to: $STP_PRIORITY"
echo "You may need to configure IP addressing for the bridge interface (e.g., using DHCP)."
```